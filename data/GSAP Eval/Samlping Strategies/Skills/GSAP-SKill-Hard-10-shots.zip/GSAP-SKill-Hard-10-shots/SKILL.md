---
name: gsap-ner-extractor-clean-6-label-Hard-sampling-10-shots
description: >
  Extract named entities from scientific CS/ML publications using a strict 6-label GSAP-style
  scheme optimized for reproducible evaluation. The only valid labels are:
  MLModel, ModelArchitecture, Method, Task, Dataset, and DataSource.
  The extractor processes a plain-text paper paragraph by paragraph, computes character-level
  start/end offsets, and outputs one final annotation set. This version removes hidden labels,
  reduces nesting ambiguity, and prioritizes boundary consistency for exact-match and partial-match
  evaluation.
---

# GSAP-NER Extractor — Clean 6-Label Version

This skill extracts named entities from full-text scientific papers using **exactly six labels**:

- `MLModel`
- `ModelArchitecture`
- `Method`
- `Task`
- `Dataset`
- `DataSource`

No other labels are allowed at extraction time or in the output.

---

## 0) Scope and Objective

The goal is to produce a **single, evaluation-ready annotation set** with:

- valid character offsets
- consistent span boundaries
- no hidden categories
- no cross-label ambiguity when a simpler decision rule is possible

This skill is designed for NER evaluation under:

- **Exact match**: start, end, and label must match exactly
- **Partial match**: character overlap with the same label

Because evaluation is sensitive to span boundaries, this skill favors **simple, repeatable span rules** over rich nested annotation.

---

## 1) Valid Labels Only

The **only** valid labels are:

1. `MLModel`
2. `ModelArchitecture`
3. `Method`
4. `Task`
5. `Dataset`
6. `DataSource`

### Forbidden labels
Do **not** invent, use, or reason with extra labels such as:

- `MLModelGeneric`
- `DatasetGeneric`
- `Metric`
- `Tool`
- `Library`
- `Loss`
- `Hyperparameter`

If a mention does not clearly belong to one of the six labels, **do not annotate it**.

---

## 2) Core Principles

### A. Prefer precision over over-tagging
Annotate only when the mention is clearly one of the six labels.

### B. One span, one label
Assign exactly one label to each annotated span.

### C. No nesting
To reduce ambiguity and improve reproducibility, **nested annotations are not allowed**.

Example:
- `GloVe embeddings` → annotate only **one span**
- Do **not** annotate both `GloVe` and `GloVe embeddings`

### D. Minimal complete span
Annotate the shortest span that uniquely expresses the labeled entity.

### E. Do not annotate generic mentions
Only annotate **named or conventionally recognized entity mentions**.
Do not annotate vague references such as:
- `the model`
- `the dataset`
- `this approach`
- `our method`
- `the architecture`

---

## 3) Input Files

| File | Role |
|---|---|
| `<paper>.txt` | Full-text paper used for annotation |
| `references/entity_definitions.md` | Clean 6-label decision guide |
| `references/icl_demos_paragraph_6label.jsonl` | Paragraph-level ICL demonstration bank |

This skill depends only on the clean 6-label definitions and the 6-label ICL demo bank.


---

---

## 4) ICL Demonstration Retrieval

Use the 10-shots demonstration file provided in the `references/icl_sentence_demos_6label` folder as the in-context demonstration bank.

For each input sentence:

1. identify likely technical keywords and likely target labels from the current paragraph
2. use the provided 10 hard-example demonstrations directly without similarity-based retrieval
3. prefer demonstrations that improve coverage of weak and ambiguous labels:
4. use the selected demonstrations as annotation guidance before extracting entities from the current paragraph
5. do **not** copy demo offsets or entity IDs
6. compute offsets only from the current input text

The demonstration contexts are approximate sentence-window contexts derived from training JSONL.
Use them as label and span-shape guidance, not as exact paragraph templates.
---

## 5) Paragraph Segmentation

Read the full `.txt` file as a single raw string.

**Do not normalize whitespace.**
Offsets must match the raw text exactly.

Use paragraph segmentation:

```python
import re
paragraphs = re.split(r'\n{2,}', raw_text)
```

Track each paragraph’s absolute start offset in the source file.

Skip:
- paragraphs shorter than 20 characters
- paragraphs with no alphabetic characters
- short figure/table captions
- the `References` section and everything after it

---

## 6) Extraction Procedure

Process one paragraph at a time.

For each paragraph:

1. Read the paragraph exactly as written.
2. Apply the clean 6-label definitions.
3. Identify valid entity mentions.
4. Record:
   - `para_idx`
   - `label`
   - `entity_string`
   - `local_start`
   - `local_end`
   - `abs_start`
   - `abs_end`

Output spans must satisfy:

```python
paragraph[local_start:local_end] == entity_string
raw_text[abs_start:abs_end] == entity_string
abs_start = para_start + local_start
abs_end = para_start + local_end
```

Use **exclusive end offsets**.

---

## 7) Span Boundary Rules

These rules are mandatory.

### Rule 1: Exclude leading determiners
Do not include:
- `the`
- `a`
- `an`
- `this`
- `that`
- `our`

Example:
- `the BERT model` → annotate `BERT`, not `the BERT model`

### Rule 2: Exclude generic head nouns when the name alone is sufficient
Do not include generic words such as:
- `model`
- `architecture`
- `method`
- `dataset`
- `corpus`
- `task`
- `system`

Examples:
- `SQuAD dataset` → `SQuAD`
- `BERT model` → `BERT`
- `Transformer architecture` → `Transformer`

### Rule 3: Include modifiers only when they are part of the canonical name
Include modifiers only if removing them changes the entity identity.

Examples:
- `ResNet-50` → include full span
- `BERT Base` → include full span
- `English Wikipedia` → usually **do not annotate** unless it clearly names a specific data source in context

### Rule 4: Hyphenated and versioned names stay together
Examples:
- `RoBERTa-Large`
- `GPT-3`
- `CIFAR-10`
- `T5-base`

### Rule 5: Acronym and full name are separate spans if both appear
Example:
- `Social Bias Inference Corpus (SBIC)`
  - annotate `Social Bias Inference Corpus`
  - annotate `SBIC`

Do not merge them into one long span.

### Rule 6: No nested spans
If a long phrase and an inner phrase are both plausible, choose the one required by the label rules and annotate only that one.

### Rule 7: Exclude surrounding punctuation
Do not include parentheses, commas, quotes, or trailing punctuation unless part of the canonical name.

---

## 8) Label Decision Rules

Use the following order when a mention seems ambiguous:

### 8.1 MLModel
Use `MLModel` when the mention refers to a **specific named model instance or model family used as a concrete system in experiments**.

Typical cases:
- `BERT`
- `mBERT`
- `XLM-R`
- `GPT-3`
- `ResNet-50`
- `RoBERTa-Large`

Use `MLModel` when the paper treats the mention as a model being trained, fine-tuned, compared, evaluated, or used as a baseline.

Examples:
- `we fine-tune BERT`
- `XLM-R outperforms mBERT`
- `ResNet-50 is used as the encoder`

### 8.2 ModelArchitecture
Use `ModelArchitecture` when the mention refers to a **design type, structural family, or architectural blueprint**, not a concrete experimental model instance.

Typical cases:
- `Transformer`
- `CNN`
- `LSTM`
- `BiLSTM`
- `attention layer`

Examples:
- `a Transformer architecture`
- `CNN-based encoder`
- `LSTM layers`

### 8.3 Method
Use `Method` for a **named training strategy, algorithmic technique, learning paradigm, representation method, or optimization method** that is not better labeled as model, architecture, task, dataset, or source.

Typical cases:
- `fine-tuning`
- `zero-shot learning`
- `active learning`
- `backpropagation`
- `word embeddings`
- `contrastive learning`

Do **not** use `Method` for:
- pure architectural names (`Transformer`, `CNN`)
- task names (`machine translation`)
- generic phrases (`our approach`, `the proposed method`)

### 8.4 Task
Use `Task` for a **named machine learning or NLP problem**.

Typical cases:
- `named entity recognition`
- `NER`
- `question answering`
- `machine translation`
- `text classification`
- `summarization`

Do **not** annotate broad field names unless they function as recognized task mentions in context.
Avoid over-tagging very broad terms like `NLP` unless the annotation policy for the dataset explicitly treats them as tasks.

### 8.5 Dataset
Use `Dataset` for a **named, stable, reusable dataset or benchmark artifact**.

Typical cases:
- `SQuAD`
- `GLUE`
- `XNLI`
- `MLQA`
- `CIFAR-10`
- `SearchQA`
- `J!Archive` when clearly referenced as a dataset artifact

Use `Dataset` when the mention refers to a fixed collection used for training, validation, or evaluation.

### 8.6 DataSource
Use `DataSource` for a **named origin of data that is live, open-ended, or not presented as a fixed released dataset**.

Typical cases:
- `Wikipedia`
- `Twitter`
- `Reddit`
- `Common Crawl`

Use `DataSource` when the paper refers to the origin/platform rather than to a frozen dataset version.

Example:
- `we collect posts from Twitter` → `Twitter` = `DataSource`

But:
- `the Twitter Sentiment Dataset` → label as `Dataset` if it is a named released dataset

---

## 9) Hard Disambiguation Rules

These rules override weaker intuitions.

### Rule A: MLModel vs ModelArchitecture
Ask:
> Is the mention used as a system/resource in experiments, or as a design type?

- experimental system/resource → `MLModel`
- design type / blueprint → `ModelArchitecture`

Examples:
- `BERT achieves...` → `MLModel`
- `Transformer-based encoder` → `ModelArchitecture`

### Rule B: ModelArchitecture vs Method
- structural component or design family → `ModelArchitecture`
- training or algorithmic procedure → `Method`

Examples:
- `Transformer` → `ModelArchitecture`
- `fine-tuning` → `Method`

### Rule C: Task vs Method
- problem to solve → `Task`
- technique used to solve it → `Method`

Examples:
- `machine translation` → `Task`
- `zero-shot learning` → `Method`

### Rule D: Dataset vs DataSource
- fixed named artifact → `Dataset`
- live or general origin → `DataSource`

Examples:
- `CIFAR-10` → `Dataset`
- `Twitter` → `DataSource`
- `Wikipedia dump from October 2022` → `Dataset`
- `Wikipedia` → `DataSource`

---

## 10) What Not to Annotate

Do not annotate:

- generic references: `the model`, `the task`, `the dataset`
- author-created vague phrases: `our approach`, `proposed framework`
- metrics: `F1`, `accuracy`, `BLEU`
- losses and hyperparameters unless they clearly function as named methods under the target policy
- software libraries and tools: `PyTorch`, `TensorFlow`, `scikit-learn`
- hardware: `GPU`, `TPU`
- section titles or captions unless they contain real entity mentions in sentence context

---

## 11) Output Format

Produce a single **CSV file** directly, formatted like the gold-truth file.

### Required filename
Use:

```text
final_annotations.csv
```

### Required columns and order

The CSV must contain **exactly** these columns in this order:

```text
doc_id,local_entity_id,text,start_char,end_char,ner_label
```

### Column definitions

- `doc_id`: document identifier for the current paper
- `local_entity_id`: sequential entity ID within the document, starting from `1`
- `text`: exact entity string copied from the raw source text
- `start_char`: absolute character start offset in the full raw document
- `end_char`: absolute character end offset in the full raw document
- `ner_label`: one of the 6 allowed labels

### Label constraint

`ner_label` must be one of:

- `MLModel`
- `ModelArchitecture`
- `Method`
- `Task`
- `Dataset`
- `DataSource`

### Offset convention

- `start_char` is inclusive
- `end_char` is exclusive
- the substring must satisfy:

```python
raw_text[start_char:end_char] == text
```

### ID rules

- `local_entity_id` must be assigned sequentially within the document:
  - `1`, `2`, `3`, ...
- IDs must be unique within one document
- sort rows by `start_char` ascending before assigning `local_entity_id`

### CSV example

```csv
doc_id,local_entity_id,text,start_char,end_char,ner_label
paper_001,1,BERT,412,416,MLModel
paper_001,2,machine translation,890,909,Task
paper_001,3,SQuAD,1204,1209,Dataset
paper_001,4,Twitter,1550,1557,DataSource
```

### Output requirements

Before returning the CSV:

1. ensure rows are sorted by `start_char`
2. ensure `local_entity_id` is sequential after sorting
3. ensure every `text` exactly matches the raw text substring
4. ensure only the 6 allowed labels appear
5. ensure no nested spans are present
6. ensure the file is valid CSV with a header row

## 12) Quality Checklist

Before returning annotations, verify:

1. Every label is one of the 6 allowed labels.
2. Every span matches the raw text exactly.
3. No determiners or generic head nouns were unnecessarily included.
4. No nested spans exist.
5. `MLModel` and `ModelArchitecture` were separated using the experimental-system vs blueprint rule.
6. `Dataset` and `DataSource` were separated using the fixed-artifact vs live-origin rule.
7. Borderline cases were skipped rather than weakly guessed.
8. The final deliverable is a CSV file with columns exactly: `doc_id,local_entity_id,text,start_char,end_char,ner_label`.

---

## 13) Quick Examples

| Mention in context | Label |
|---|---|
| `BERT outperforms prior baselines` | `MLModel` |
| `a Transformer encoder` | `ModelArchitecture` |
| `fine-tuning improves performance` | `Method` |
| `named entity recognition` | `Task` |
| `SQuAD` | `Dataset` |
| `Twitter` in `collected from Twitter` | `DataSource` |

This version is intentionally conservative and evaluation-oriented.
When uncertain, skip the mention rather than forcing a label.
