\# Annotation Span Rules — GSAP-NER



Reference: GSAP-NER Annotation Guideline v1.2, ACL RD-TEC Guideline §3.3



\---



\## 1. Articles and Determiners



\*\*General rule\*\*: Do NOT include articles ("a", "the", "an") in named entity spans.



\*\*Exception — Generic mentions only\*\*: For generic mentions (MLModelGeneric, DatasetGeneric, Method), articles ARE included when they are part of the natural generic phrase.

\- ✅ `a large-scale, diverse dataset` → include "a" (DatasetGeneric)

\- ✅ `the model` → include "the" (MLModelGeneric)

\- ❌ `the SQuAD` → annotate only `SQuAD` (Dataset)



\*\*Rationale\*\*: The article may be necessary to guard the semantical meaning of a generic entity.



\---



\## 2. Abbreviations



When a full name and its abbreviation appear together as "Full Name (ABBR)":

\- Annotate \*\*both\*\* spans separately with the same label.

\- Example: "Social Bias Inference Corpus (SBIC)" → annotate `Social Bias Inference Corpus` AND `SBIC` as two separate Dataset spans.



\*\*Term-abbreviation sequence\*\*: Follow ACL RD-TEC Guideline §3.3 "Term-abbreviation sequence".



\*\*Term broken by abbreviations\*\*: Follow ACL RD-TEC Guideline §3.3 "Term broken by abbreviations".



\---



\## 3. Modifiers



\### Adjective Modifiers

Check whether removing the adjective changes the meaning:

\- "\*\*multilingual\*\* BERT (mBERT)" → keep "multilingual" (changes meaning — it's a different model variant)

\- "\*\*well-known\*\* CommonCrawl" → drop "well-known" (evaluative, doesn't change identity)



\*\*Generic mentions\*\*: Always include adjective modifiers.

\- ✅ `improved QA-pair models` (keep "improved")



\### Noun Modifiers Breaking a Span

If a noun phrase is broken by modifiers, annotate the whole span:

\- "a large-scale, diverse dataset" → annotate the full string (modifiers "large-scale" and "diverse" are inside the span)



\---



\## 4. Generic Nouns



Generic nouns ("dataset", "model", "corpus", "method") are included in generic mentions but NOT in named entity spans.



\- `SQuAD dataset` → annotate only `SQuAD` (Dataset)

\- `the SQuAD v1.1 dataset` → annotate only `SQuAD v1.1` (Dataset)

\- `a large-scale, diverse dataset` → annotate full string (DatasetGeneric)



\---



\## 5. Plurals



Plural mentions of proper names are treated as \*\*generic\*\* entities, not as named entities.



\- `BERT models` → MLModelGeneric (not MLModel)

\- `the image datasets` → DatasetGeneric (not Dataset)

\- `the ResNets` → MLModelGeneric (+ nested ModelArchitecture: `ResNets`)



\*\*Exception\*\*: Plural named entities that refer to a specific collection may be annotated as Dataset when they form a proper name (e.g., "CommonCrawls" as a named dataset collection).



\---



\## 6. Conjunctions and Prepositions



Follow ACL RD-TEC Guideline §3.3 "Conjunctions and prepositions".



For conjunctions connecting two named entities ("BERT and XLNet"), annotate each span separately:

\- `BERT` (MLModel)

\- `XLNet` (MLModel)

Do NOT annotate "BERT and XLNet" as a single span.



\---



\## 7. Nesting Rules



Nested annotations are explicitly allowed in GSAP-NER. Two main patterns:



\*\*Pattern A: Named entity inside a Generic\*\*

\- "our \*\*BERT\*\*-based model" → outer: `our BERT-based model` (MLModelGeneric), inner: `BERT` (ModelArchitecture)

\- "an execution-centric table pre-training approach" for TAPEX → outer: full phrase (MLModelGeneric), TAPEX annotated separately where it appears as MLModel



\*\*Pattern B: Double annotation for type + instance\*\*

\- "the \*\*ResNets\*\* we train a \*\*ResNet-50\*\*" → `ResNets` = ModelArchitecture AND MLModelGeneric; `ResNet-50` = MLModel



\*\*Pattern C: Benchmark entities double-tagged Dataset + Task\*\*

\- Some datasets serve as task benchmarks. Annotate as both `Dataset` and `Task` where appropriate (e.g., XNLI when referred to as a benchmark task).



\*\*Stacking limit\*\*: Keep annotations flat where possible — do not stack more than 2 levels deep.



\---



\## 8. Scope of Relations



Relations (e.g., `appliedOn`, `coreference`, `isPartOf`) are limited to \*\*one paragraph\*\*. Do not create cross-paragraph relations.



\---



\## 9. Coreferences



Generic mentions that co-refer to a named entity mentioned earlier (or later) in the same paragraph should be linked via a `coreference` relation to the nearest named mention.



\- "our model … \*\*it\*\* outperforms" → if "it" refers to the model, tag as MLModelGeneric + coreference link

\- Link to the \*\*last or next\*\* named mention in the paragraph



\---



\## 10. Exclusions



\- \*\*Do NOT annotate the References section\*\* and everything after it.

\- \*\*Corrupt paragraphs\*\* (figure/table text extracted from PDF, non-sentence fragments): mark the entire paragraph as `SKIPPED`. Do not annotate individual spans within it.

\- \*\*Descriptive task processes\*\*: "removing the next sentence prediction objective" is NOT a Task entity.



\---



\## 11. Nesting and Conflicts (Reconciliation Guide)



Use this during Step 4 (comparison) to auto-resolve label conflicts:



| Conflict | Resolution |

|---|---|

| MLModel vs ModelArchitecture (same span) | Check context: executable resource → MLModel; type/structural → ModelArchitecture |

| MLModelGeneric vs ModelArchitecture (general type mention) | Double-annotate BOTH |

| Dataset vs DatasetGeneric (same span) | Named/proper → Dataset; informal → DatasetGeneric |

| Dataset vs DataSource | Has fixed timestamp or is a named corpus → Dataset; live platform → DataSource |

| Method vs ModelArchitecture | Has multiple algorithmic steps → Method; purely structural → ModelArchitecture |

| Task vs Dataset (benchmark) | If it names a benchmark used as a task → annotate both |



\*\*Conservative default for boundary disagreements\*\*: Accept the shorter span unless the trimmed characters are adjective modifiers that change meaning (see §3).

