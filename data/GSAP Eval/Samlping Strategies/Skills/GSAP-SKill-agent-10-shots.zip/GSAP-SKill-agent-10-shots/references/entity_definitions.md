# Entity Definitions — Clean 6-Label GSAP-NER Version

This guide defines a **strict 6-label annotation scheme** for scientific ML/NLP papers.

The only valid labels are:

1. `MLModel`
2. `ModelArchitecture`
3. `Method`
4. `Task`
5. `Dataset`
6. `DataSource`

The purpose of this version is to improve annotation consistency for **exact-match** and **partial-match** evaluation.

---

## Global Rules

### 1) No extra labels
Do not use hidden or auxiliary labels.

### 2) No nesting
Annotate only one span per mention.
Do not create inner and outer spans for the same phrase.

### 3) Minimal complete span
Select the shortest span that uniquely identifies the entity.

### 4) Skip borderline mentions
If a mention is too generic or cannot be assigned confidently to one of the 6 labels, do not annotate it.

### 5) Exclude generic head words
Unless the head noun is part of the official name, exclude words such as:
- model
- architecture
- method
- approach
- dataset
- corpus
- task
- system

Examples:
- `BERT model` → annotate `BERT`
- `SQuAD dataset` → annotate `SQuAD`

---

## 1. MLModel

### Definition
A **named model** used as a concrete experimental system, baseline, pretrained model, or executable model family in the paper.

### Use this label when
The mention behaves like a model being:
- trained
- fine-tuned
- evaluated
- compared
- used as a baseline
- plugged into a pipeline

### Positive examples
- `BERT`
- `mBERT`
- `XLM-R`
- `GPT-3`
- `ResNet-50`
- `RoBERTa-Large`
- `T5-base`

### Negative examples
- `the model`
- `Transformer` when referring to the general design
- `CNN` when referring to the general architecture

### Boundary rule
Use only the canonical name.

Examples:
- `the BERT model` → `BERT`
- `pretrained RoBERTa-Large encoder` → `RoBERTa-Large`

### Decision test
Ask:
> Is this mention treated as a model system/resource in the experiment?

If yes, use `MLModel`.

---

## 2. ModelArchitecture

### Definition
A named architectural family, structural pattern, or architectural component used to describe the design of a system, rather than a concrete named model instance.

### Use this label when
The mention refers to:
- a general architecture family
- a structural model type
- an architectural layer or component
- a short architecture phrase naming a component

### Positive examples
- `Transformer`
- `CNN`
- `RNN`
- `LSTM`
- `BiLSTM`
- `GRU`
- `self-attention`
- `attention layer`
- `feed-forward network`
- `encoder-decoder architecture`
- `CNN encoder`
- `LSTM decoder`
- `BiLSTM layer`

### Negative examples
- `BERT` when used as an evaluated model
- `RoBERTa-Large`
- `fine-tuning`
- `machine translation`

### Boundary rule
Annotate the shortest technical phrase that still clearly denotes the architecture concept.

Examples:
- `Transformer-based encoder` → `Transformer`
- `CNN encoder` → `CNN encoder`
- `deep BiLSTM layer for tagging` → `BiLSTM layer`

### Recall note
When a short phrase such as `CNN encoder` or `BiLSTM layer` names an architectural component in a standard way, annotate it rather than reducing everything to the bare head word or skipping it.

### Decision test
Ask:
> Is this describing the design or a structural component of the model, rather than a concrete named model used as a system?

If yes, use `ModelArchitecture`.


---

## 3. Method

### Definition
A named technical procedure, learning strategy, training paradigm, representation technique, inference strategy, or optimization procedure that is used to build, train, adapt, or run a model.

### Use this label when
The mention refers to a recognized ML/NLP technique such as:
- a learning paradigm
- a training strategy
- an inference strategy
- a representation technique
- an optimization method

### Positive examples
- `fine-tuning`
- `pre-training`
- `zero-shot learning`
- `few-shot learning`
- `self-supervised learning`
- `contrastive learning`
- `knowledge distillation`
- `beam search`
- `backpropagation`
- `word embeddings`
- `label smoothing`
- `Adam optimizer`
- `stochastic gradient descent`

### Negative examples
- `machine translation` → Task
- `Transformer` → ModelArchitecture
- `BERT` → MLModel
- `our method`
- `proposed approach`

### Boundary rule
Keep only the standard method name.
Do not extend into long goal or application phrases.

Examples:
- `fine-tuning on the source task` → `fine-tuning`
- `contrastive learning for retrieval` → `contrastive learning`
- `Adam optimizer with warmup` → `Adam optimizer`

### Recall note
If a phrase is a standard ML/NLP technique and is not better classified as Task, ModelArchitecture, MLModel, Dataset, or DataSource, annotate it as `Method` instead of skipping it.

### Decision test
Ask:
> Is this a technique or procedure used to solve/train/run the system rather than the problem being solved?

If yes, use `Method`.

---

## 4. Task

### Definition
A named machine learning, NLP, speech, or vision problem that a system is designed to solve.

### Use this label when
The mention names a benchmarkable or recognizable prediction/generation/classification/recognition/retrieval problem.

### Positive examples
- `named entity recognition`
- `NER`
- `question answering`
- `machine translation`
- `text classification`
- `sentiment analysis`
- `speech recognition`
- `dependency parsing`
- `part-of-speech tagging`
- `summarization`

### Negative examples
- `fine-tuning` → Method
- `Transformer encoder` → ModelArchitecture
- `NLP` when used only as a field label
- `the downstream task`

### Boundary rule
Annotate the core task name only.

Examples:
- `cross-lingual named entity recognition` → `named entity recognition`
- `document-level sentiment analysis` → `sentiment analysis`
- `neural machine translation task` → `machine translation`

### Recall note
If a mention clearly contains a standard task expression, annotate the task expression even when the surrounding phrase contains modifiers.

### Decision test
Ask:
> Is this the problem being solved by the system?

If yes, use `Task`.

---

## 5. Dataset

### Definition
A named, stable, reusable dataset, benchmark, corpus release, or frozen data artifact used for training, validation, or evaluation.

### Use this label when
The mention refers to a fixed resource that could in principle be reused by others as the same artifact.

### Positive examples
- `SQuAD`
- `GLUE`
- `XNLI`
- `MLQA`
- `CIFAR-10`
- `CIFAR-100`
- `SearchQA`
- `SBIC`
- `Social Bias Inference Corpus`
- `Wikipedia dump from October 2022`

### Negative examples
- `Twitter` when it refers to the platform
- `Wikipedia` when it refers to the general source
- `the dataset`
- `training corpus` without a name

### Boundary rule
Do not include generic suffixes unless they are part of the official name.

Examples:
- `SQuAD dataset` → `SQuAD`
- `Social Bias Inference Corpus` → full name kept because `Corpus` is part of the proper name

### Acronym rule
If full name and acronym both appear, annotate them separately.

Example:
- `Social Bias Inference Corpus (SBIC)`
  - `Social Bias Inference Corpus`
  - `SBIC`

### Decision test
Ask:
> Is this a fixed named artifact rather than a live source?

If yes, use `Dataset`.

---

## 6. DataSource

### Definition
A named source or origin of raw data that is live, evolving, open-ended, or not presented as a fixed released dataset.

### Use this label when
The mention refers to a platform, website, repository, or stream from which data is collected, scraped, or sampled.

### Positive examples
- `Wikipedia`
- `Twitter`
- `Reddit`
- `Common Crawl`
- `YouTube`

### Negative examples
- `SQuAD`
- `Wikipedia dump from October 2022`
- `Twitter Sentiment Dataset`

### Boundary rule
Annotate only the source name.

Examples:
- `posts collected from Twitter` → `Twitter`
- `text extracted from Wikipedia` → `Wikipedia`

### Decision test
Ask:
> Is this the origin of the data, rather than a frozen named dataset?

If yes, use `DataSource`.

---

## Hard Distinctions

### MLModel vs ModelArchitecture
- concrete named system used in experiments → `MLModel`
- design family or architecture component → `ModelArchitecture`

Examples:
- `we fine-tune BERT` → `MLModel`
- `a Transformer encoder` → `ModelArchitecture`
- `BiLSTM layer` → `ModelArchitecture`

### Method vs Task
- problem to solve → `Task`
- technique or procedure used to solve/train/run the model → `Method`

Examples:
- `machine translation` → `Task`
- `zero-shot learning` → `Method`
- `beam search` → `Method`

### Method vs ModelArchitecture
- structural design/component → `ModelArchitecture`
- algorithmic/training/inference procedure → `Method`

Examples:
- `self-attention` → `ModelArchitecture`
- `knowledge distillation` → `Method`

### Dataset vs DataSource
- fixed named artifact → `Dataset`
- live or general origin → `DataSource`

Examples:
- `CIFAR-10` → `Dataset`
- `Twitter` → `DataSource`

---

## Borderline Mentions to Skip

Skip these unless context makes the label unambiguous:

- `our model`
- `the proposed framework`
- `baseline system`
- `classification` when it is too generic
- `NLP`
- `language model` without a specific name
- `embedding` by itself
- `optimizer` by itself

---

## Compact Decision Table

| Mention type | Label |
|---|---|
| concrete named model in experiments | `MLModel` |
| named architectural design or component | `ModelArchitecture` |
| named technique or learning strategy | `Method` |
| named prediction/generation problem | `Task` |
| named stable benchmark/corpus/dataset | `Dataset` |
| named live data origin/platform | `DataSource` |

---

## Final Annotation Advice

When two labels seem possible, choose the one supported by the **function of the mention in context**.
When the function is still unclear, skip the mention.

This scheme is intentionally conservative so that exact-match evaluation becomes more reliable.
