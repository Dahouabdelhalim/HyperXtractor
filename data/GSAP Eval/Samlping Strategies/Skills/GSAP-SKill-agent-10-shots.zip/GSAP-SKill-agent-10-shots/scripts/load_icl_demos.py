#!/usr/bin/env python3
"""
load_icl_demos.py
=================
Parse the in-context learning demonstrations CSV and output a structured
JSON that the agent uses when building annotation prompts.

Adapted for Train_Entities.csv format:
  - start_char -> start
  - end_char   -> end
  - ner_label  -> label
  - text       -> entity_string
  (no context column; context set to empty string)

Usage:
  python load_icl_demos.py --csv Train_Entities.csv [--out icl_demos.json] [--max-per-label 5]
"""

import argparse
import csv
import json
import sys
from collections import defaultdict
from pathlib import Path

VALID_LABELS = {
    "MLModel", "ModelArchitecture",
    "Method", "Task",
    "Dataset", "DataSource"
}

REQUIRED_COLS = {"start_char", "end_char", "ner_label", "text"}


def load_csv(path: str) -> list[dict]:
    rows = []
    with open(path, newline="", encoding="utf-8") as f:
        reader = csv.DictReader(f)
        if not reader.fieldnames:
            sys.exit(f"[ERROR] CSV file appears empty: {path}")

        missing = REQUIRED_COLS - set(reader.fieldnames)
        if missing:
            sys.exit(f"[ERROR] CSV is missing required columns: {missing}\n"
                     f"Found columns: {list(reader.fieldnames)}")

        for i, row in enumerate(reader, start=2):
            label = row.get("ner_label", "").strip()
            if label not in VALID_LABELS:
                print(f"[WARN] Row {i}: unknown label {label!r} — skipped")
                continue
            try:
                start = int(row["start_char"])
                end = int(row["end_char"])
            except ValueError:
                print(f"[WARN] Row {i}: non-integer start_char/end_char — skipped")
                continue
            if end <= start:
                print(f"[WARN] Row {i}: end_char <= start_char — skipped")
                continue

            rows.append({
                "label": label,
                "entity_string": row["text"].strip(),
                "start": start,
                "end": end,
                "context": "",   # no context column in this CSV
            })

    return rows


def build_demo_blocks(rows: list[dict], max_per_label: int = 5) -> dict:
    """
    Group demonstrations by label and format them as prompt-ready text blocks.
    Returns:
        {
          "by_label": { "MLModel": [...], ... },
          "prompt_blocks": { "MLModel": "<formatted text>", ... },
          "stats": { "MLModel": 3, ... }
        }
    """
    by_label = defaultdict(list)
    for row in rows:
        by_label[row["label"]].append(row)

    prompt_blocks = {}
    stats = {}
    for label in VALID_LABELS:
        demos = by_label.get(label, [])[:max_per_label]
        stats[label] = len(demos)
        if not demos:
            prompt_blocks[label] = f"[No demonstrations available for {label}]"
            continue

        lines = [f"--- {label} EXAMPLES ---"]
        for d in demos:
            ctx = d["context"] if d["context"] else "(context not available)"
            lines.append(
                f'Context: "{ctx}"\n'
                f'Entity : "{d["entity_string"]}"  (chars {d["start"]}–{d["end"]})\n'
                f'Label  : {label}'
            )
        prompt_blocks[label] = "\n\n".join(lines)

    return {
        "by_label": {k: v for k, v in by_label.items()},
        "prompt_blocks": prompt_blocks,
        "stats": stats,
    }


def print_summary(result: dict) -> None:
    print("\n=== ICL Demonstration Summary ===")
    for label in VALID_LABELS:
        count = result["stats"].get(label, 0)
        bar = "█" * count
        print(f"  {label:<22} {count:>3}  {bar}")
    total = sum(result["stats"].values())
    print(f"\n  Total demonstrations loaded: {total}")


def main():
    parser = argparse.ArgumentParser(description="Load GSAP-NER ICL demonstration CSV")
    parser.add_argument("--csv", required=True, help="Path to demonstrations CSV file")
    parser.add_argument("--out", default="icl_demos.json", help="Output JSON path")
    parser.add_argument("--max-per-label", type=int, default=5,
                        help="Maximum demonstrations per label (default: 5)")
    args = parser.parse_args()

    rows = load_csv(args.csv)
    if not rows:
        sys.exit("[ERROR] No valid rows loaded from CSV.")

    result = build_demo_blocks(rows, args.max_per_label)
    print_summary(result)

    Path(args.out).write_text(
        json.dumps(result, indent=2, ensure_ascii=False), encoding="utf-8"
    )
    print(f"\n[OK] Demonstrations saved to {args.out}")


if __name__ == "__main__":
    main()