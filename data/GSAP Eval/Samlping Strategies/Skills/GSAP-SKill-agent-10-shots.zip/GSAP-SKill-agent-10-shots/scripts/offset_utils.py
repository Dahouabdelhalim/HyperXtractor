#!/usr/bin/env python3
"""
GSAP-NER Offset Utility
=======================
A deterministic helper for paragraph segmentation, offset calculation,
annotation verification, and iteration diffing.

Usage:
  python offset_utils.py --segment  --txt paper.txt
  python offset_utils.py --verify   --txt paper.txt --annotations file.json
  python offset_utils.py --recompute --txt paper.txt --annotations file.json [--out fixed.json]
  python offset_utils.py --diff     --iter1 iteration_1.json --iter2 iteration_2.json [--out diff.json]
"""

import argparse
import json
import re
import sys
from pathlib import Path


# ---------------------------------------------------------------------------
# I/O helpers
# ---------------------------------------------------------------------------

def read_txt(path: str) -> str:
    """Read the raw paper text exactly as stored — no normalisation."""
    return Path(path).read_text(encoding="utf-8")


def read_json(path: str) -> dict:
    return json.loads(Path(path).read_text(encoding="utf-8"))


def write_json(data, path: str) -> None:
    Path(path).write_text(json.dumps(data, indent=2, ensure_ascii=False), encoding="utf-8")
    print(f"[OK] Written to {path}")


# ---------------------------------------------------------------------------
# Paragraph segmentation
# ---------------------------------------------------------------------------

PARA_SEP = re.compile(r'\n{2,}')

# Heuristics for skipping paragraphs
SKIP_HEURISTICS = [
    lambda p: len(p.strip()) < 20,
    lambda p: not any(c.isalpha() for c in p),
    lambda p: re.match(r'^\s*(Figure|Table|Fig\.?)\s+\d+', p, re.IGNORECASE) and len(p) < 200,
]

REFERENCES_PATTERN = re.compile(
    r'^\s*(References|Bibliography|Works\s+Cited)\s*$',
    re.IGNORECASE | re.MULTILINE,
)


def should_skip(para: str) -> bool:
    return any(h(para) for h in SKIP_HEURISTICS)


def find_references_cutoff(text: str) -> int:
    """Return the char index where the References section starts, or len(text)."""
    m = REFERENCES_PATTERN.search(text)
    return m.start() if m else len(text)


def segment_paragraphs(text: str) -> list[dict]:
    """
    Split text into paragraphs and record absolute offsets.

    Returns a list of dicts:
        {
          "para_idx": int,
          "abs_start": int,
          "abs_end": int,       # exclusive, points past the last char of the para
          "text": str,
          "skipped": bool,
          "skip_reason": str | None
        }
    """
    cutoff = find_references_cutoff(text)
    # Work only on the pre-references portion
    body = text[:cutoff]

    paragraphs = []
    para_idx = 0
    pos = 0

    for match in PARA_SEP.finditer(body):
        sep_start = match.start()
        para_text = body[pos:sep_start]
        sep_end = match.end()

        skip = should_skip(para_text)
        reason = None
        if skip:
            for h in SKIP_HEURISTICS:
                if h(para_text):
                    reason = h.__doc__ or "heuristic"
                    break

        paragraphs.append({
            "para_idx": para_idx,
            "abs_start": pos,
            "abs_end": sep_start,   # exclusive end of paragraph text
            "text": para_text,
            "skipped": skip,
            "skip_reason": reason,
        })
        para_idx += 1
        pos = sep_end

    # Last paragraph (no trailing separator)
    if pos < len(body):
        para_text = body[pos:]
        skip = should_skip(para_text)
        paragraphs.append({
            "para_idx": para_idx,
            "abs_start": pos,
            "abs_end": pos + len(para_text),
            "text": para_text,
            "skipped": skip,
            "skip_reason": None,
        })

    return paragraphs


# ---------------------------------------------------------------------------
# Verification
# ---------------------------------------------------------------------------

def verify_annotations(text: str, annotations: list[dict]) -> list[dict]:
    """
    Check that raw_text[abs_start:abs_end] == entity_string for every annotation.

    Returns a list of error dicts for any mismatches.
    """
    errors = []
    for ann in annotations:
        s = ann.get("abs_start")
        e = ann.get("abs_end")
        expected = ann.get("entity_string", "")
        if s is None or e is None:
            errors.append({**ann, "error": "missing abs_start or abs_end"})
            continue
        actual = text[s:e]
        if actual != expected:
            errors.append({
                **ann,
                "error": "offset_mismatch",
                "actual_slice": actual,
                "expected": expected,
            })
    return errors


# ---------------------------------------------------------------------------
# Recompute offsets
# ---------------------------------------------------------------------------

def recompute_offsets(text: str, annotations: list[dict]) -> list[dict]:
    """
    For annotations with bad or missing offsets, try to locate entity_string
    in the paragraph context and recompute abs_start / abs_end.

    Strategy:
      1. If para_idx + para_start are known, search within that paragraph first.
      2. Fall back to searching the whole text.
      3. If multiple occurrences, prefer the one closest to abs_start (if provided).
    """
    paragraphs = segment_paragraphs(text)
    para_map = {p["para_idx"]: p for p in paragraphs}

    fixed = []
    for ann in annotations:
        entity = ann.get("entity_string", "")
        if not entity:
            fixed.append({**ann, "recompute_status": "no_entity_string"})
            continue

        # Already correct?
        s, e = ann.get("abs_start"), ann.get("abs_end")
        if s is not None and e is not None and text[s:e] == entity:
            fixed.append({**ann, "recompute_status": "ok"})
            continue

        # Try within declared paragraph first
        candidates = []
        para_idx = ann.get("para_idx")
        if para_idx is not None and para_idx in para_map:
            para = para_map[para_idx]
            search_text = para["text"]
            base = para["abs_start"]
            start_in_para = 0
            while True:
                idx = search_text.find(entity, start_in_para)
                if idx == -1:
                    break
                candidates.append((base + idx, base + idx + len(entity), "para"))
                start_in_para = idx + 1

        # Fall back to full text
        if not candidates:
            start_in_text = 0
            while True:
                idx = text.find(entity, start_in_text)
                if idx == -1:
                    break
                candidates.append((idx, idx + len(entity), "fulltext"))
                start_in_text = idx + 1

        if not candidates:
            fixed.append({**ann, "recompute_status": "not_found"})
            continue

        if len(candidates) == 1:
            new_s, new_e, scope = candidates[0]
        else:
            # Pick closest to original abs_start if available
            if s is not None:
                candidates.sort(key=lambda c: abs(c[0] - s))
            new_s, new_e, scope = candidates[0]

        fixed.append({
            **ann,
            "abs_start": new_s,
            "abs_end": new_e,
            "recompute_status": f"fixed_via_{scope}",
            "recompute_candidates": len(candidates),
        })

    return fixed


# ---------------------------------------------------------------------------
# Diff / reconciliation
# ---------------------------------------------------------------------------

def ann_key(ann: dict) -> tuple:
    """Canonical key for deduplication: (label, abs_start, abs_end)."""
    return (ann.get("label"), ann.get("abs_start"), ann.get("abs_end"))


def span_overlaps(a: dict, b: dict) -> bool:
    """True if two annotations have overlapping character spans."""
    return a.get("abs_start", -1) < b.get("abs_end", -1) and \
           b.get("abs_start", -1) < a.get("abs_end", -1)


def diff_iterations(iter1: list[dict], iter2: list[dict]) -> dict:
    """
    Compare two iteration annotation lists and produce a reconciliation report.

    Returns:
        {
          "confirmed": [...],       # exact match (label + spans)
          "conflicts": [...],       # same spans, different label
          "boundary_review": [...], # overlapping spans, close but not exact
          "only_iter1": [...],
          "only_iter2": [...],
        }
    """
    keys1 = {ann_key(a): a for a in iter1}
    keys2 = {ann_key(a): a for a in iter2}

    confirmed = []
    conflicts = []
    boundary_review = []
    only1 = []
    only2 = []

    all_keys = set(keys1.keys()) | set(keys2.keys())

    for key in all_keys:
        in1 = key in keys1
        in2 = key in keys2

        if in1 and in2:
            confirmed.append({
                **keys1[key],
                "status": "confirmed",
                "confidence": "high",
                "in_iter1": True,
                "in_iter2": True,
            })
        elif in1:
            a1 = keys1[key]
            # Check for overlapping span with different label or boundaries in iter2
            overlapping = [a2 for a2 in iter2 if span_overlaps(a1, a2)]
            if overlapping:
                a2 = overlapping[0]
                span_diff = abs(a1.get("abs_start", 0) - a2.get("abs_start", 0)) + \
                            abs(a1.get("abs_end", 0) - a2.get("abs_end", 0))
                if a1.get("label") != a2.get("label") and span_diff == 0:
                    conflicts.append({
                        "iter1": a1,
                        "iter2": a2,
                        "status": "conflict",
                        "conflict_type": "label_mismatch",
                    })
                elif span_diff <= 10:
                    boundary_review.append({
                        "iter1": a1,
                        "iter2": a2,
                        "status": "boundary_review",
                        "span_diff_chars": span_diff,
                    })
                else:
                    only1.append({**a1, "status": "single_pass", "confidence": "medium", "in_iter1": True, "in_iter2": False})
            else:
                only1.append({**a1, "status": "single_pass", "confidence": "medium", "in_iter1": True, "in_iter2": False})
        else:
            a2 = keys2[key]
            overlapping = [a1 for a1 in iter1 if span_overlaps(a2, a1)]
            if not overlapping:
                only2.append({**a2, "status": "single_pass", "confidence": "medium", "in_iter1": False, "in_iter2": True})

    return {
        "confirmed": confirmed,
        "conflicts": conflicts,
        "boundary_review": boundary_review,
        "only_iter1": only1,
        "only_iter2": only2,
    }


def build_final_annotations(diff: dict) -> list[dict]:
    """
    Auto-resolve where possible and return a flat list ready for final_annotations.json.
    """
    final = []
    eid = 1

    for ann in diff["confirmed"]:
        final.append({**ann, "id": f"e{eid:04d}"})
        eid += 1

    for item in diff["boundary_review"]:
        # Accept the shorter span (conservative default per annotation rules §11)
        a1, a2 = item["iter1"], item["iter2"]
        span1 = a1.get("abs_end", 0) - a1.get("abs_start", 0)
        span2 = a2.get("abs_end", 0) - a2.get("abs_start", 0)
        chosen = a1 if span1 <= span2 else a2
        final.append({
            **chosen,
            "id": f"e{eid:04d}",
            "status": "boundary_review_resolved",
            "confidence": "medium",
            "review_note": f"Boundary disagreement of {item['span_diff_chars']} chars; shorter span chosen",
            "in_iter1": True,
            "in_iter2": True,
        })
        eid += 1

    for item in diff["conflicts"]:
        # Flag for human review — include both candidates
        final.append({
            **item["iter1"],
            "id": f"e{eid:04d}",
            "status": "conflict",
            "confidence": "low",
            "review_note": f"Label conflict: iter1={item['iter1'].get('label')} vs iter2={item['iter2'].get('label')}",
            "iter2_label": item["iter2"].get("label"),
            "in_iter1": True,
            "in_iter2": True,
        })
        eid += 1

    for ann in diff["only_iter1"] + diff["only_iter2"]:
        final.append({**ann, "id": f"e{eid:04d}", "review_note": "Found in only one iteration"})
        eid += 1

    return final


# ---------------------------------------------------------------------------
# Reporting
# ---------------------------------------------------------------------------

def print_segment_report(paragraphs: list[dict]) -> None:
    total = len(paragraphs)
    skipped = sum(1 for p in paragraphs if p["skipped"])
    print(f"\n=== Paragraph Segmentation Report ===")
    print(f"Total paragraphs : {total}")
    print(f"Skipped          : {skipped}")
    print(f"To annotate      : {total - skipped}\n")
    print(f"{'IDX':>4}  {'START':>7}  {'END':>7}  {'SKIP':>5}  PREVIEW")
    print("-" * 70)
    for p in paragraphs:
        preview = p["text"][:50].replace("\n", " ")
        skip_flag = "SKIP" if p["skipped"] else "    "
        print(f"{p['para_idx']:>4}  {p['abs_start']:>7}  {p['abs_end']:>7}  {skip_flag}  {preview!r}")


def print_verify_report(errors: list[dict]) -> None:
    if not errors:
        print("\n[✓] All offsets verified — no mismatches found.")
        return
    print(f"\n[!] {len(errors)} offset error(s) found:\n")
    for e in errors:
        print(f"  id={e.get('id','?')}  label={e.get('label','?')}")
        print(f"  entity_string : {e.get('entity_string','')!r}")
        print(f"  actual_slice  : {e.get('actual_slice','')!r}")
        print(f"  abs_start={e.get('abs_start')}  abs_end={e.get('abs_end')}")
        print()


def print_diff_summary(diff: dict) -> None:
    print("\n=== Iteration Comparison Summary ===")
    print(f"  Confirmed (both agree)     : {len(diff['confirmed'])}")
    print(f"  Label conflicts            : {len(diff['conflicts'])}")
    print(f"  Boundary disagreements     : {len(diff['boundary_review'])}")
    print(f"  Only in Iteration 1        : {len(diff['only_iter1'])}")
    print(f"  Only in Iteration 2        : {len(diff['only_iter2'])}")
    total = (len(diff['confirmed']) + len(diff['conflicts']) +
             len(diff['boundary_review']) + len(diff['only_iter1']) + len(diff['only_iter2']))
    print(f"  Total unique candidates    : {total}")


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------

def main():
    parser = argparse.ArgumentParser(description="GSAP-NER Offset Utility")
    mode = parser.add_mutually_exclusive_group(required=True)
    mode.add_argument("--segment",   action="store_true", help="Segment .txt into paragraphs with offsets")
    mode.add_argument("--verify",    action="store_true", help="Verify annotation offsets against raw text")
    mode.add_argument("--recompute", action="store_true", help="Recompute broken offsets")
    mode.add_argument("--diff",      action="store_true", help="Compare two iteration JSON files")

    parser.add_argument("--txt",  help="Path to raw .txt paper file")
    parser.add_argument("--annotations", help="Path to annotation JSON file")
    parser.add_argument("--iter1", help="Path to iteration 1 JSON (for --diff)")
    parser.add_argument("--iter2", help="Path to iteration 2 JSON (for --diff)")
    parser.add_argument("--out",  help="Output path for recomputed/diff JSON")

    args = parser.parse_args()

    # --segment
    if args.segment:
        if not args.txt:
            sys.exit("--segment requires --txt")
        text = read_txt(args.txt)
        paragraphs = segment_paragraphs(text)
        print_segment_report(paragraphs)
        if args.out:
            write_json(paragraphs, args.out)
        return

    # --verify
    if args.verify:
        if not args.txt or not args.annotations:
            sys.exit("--verify requires --txt and --annotations")
        text = read_txt(args.txt)
        data = read_json(args.annotations)
        anns = data if isinstance(data, list) else data.get("entities", [])
        errors = verify_annotations(text, anns)
        print_verify_report(errors)
        if args.out and errors:
            write_json(errors, args.out)
        return

    # --recompute
    if args.recompute:
        if not args.txt or not args.annotations:
            sys.exit("--recompute requires --txt and --annotations")
        text = read_txt(args.txt)
        data = read_json(args.annotations)
        anns = data if isinstance(data, list) else data.get("entities", [])
        fixed = recompute_offsets(text, anns)
        errors = verify_annotations(text, fixed)
        print_verify_report(errors)
        out_path = args.out or args.annotations.replace(".json", "_recomputed.json")
        write_json({"entities": fixed}, out_path)
        return

    # --diff
    if args.diff:
        if not args.iter1 or not args.iter2:
            sys.exit("--diff requires --iter1 and --iter2")
        data1 = read_json(args.iter1)
        data2 = read_json(args.iter2)
        anns1 = data1 if isinstance(data1, list) else data1.get("entities", [])
        anns2 = data2 if isinstance(data2, list) else data2.get("entities", [])
        diff = diff_iterations(anns1, anns2)
        print_diff_summary(diff)
        final = build_final_annotations(diff)
        out_path = args.out or "final_annotations.json"
        write_json({"entities": final, "diff_summary": {
            "confirmed": len(diff["confirmed"]),
            "conflicts": len(diff["conflicts"]),
            "boundary_review": len(diff["boundary_review"]),
            "only_iter1": len(diff["only_iter1"]),
            "only_iter2": len(diff["only_iter2"]),
        }}, out_path)
        return


if __name__ == "__main__":
    main()