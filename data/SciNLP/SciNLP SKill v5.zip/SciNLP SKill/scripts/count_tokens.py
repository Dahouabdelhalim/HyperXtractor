#!/usr/bin/env python3
"""
count_tokens.py
===============
Compute token statistics for one tokenized document expected by the
SciNLP NER extractor skill.

Input file format
-----------------
A JSON file with the schema:

    {
      "doc_id": "P19-1001",
      "sentences": [
        ["In", "this", "paper", ",", "we", "fine-tune", "BERT", "on", "SQuAD", "."],
        ["The", "model", "achieves", "92.1", "F1", "on", "the", "test", "set", "."]
      ]
    }

What it computes
----------------
* `n_sentences`         — number of sentences
* `n_tokens`            — total tokens after flattening all sentences
* `n_alpha_tokens`      — tokens containing at least one alphabetic character
                          (useful when filtering out punctuation noise)
* `mean_sent_len`       — average tokens per sentence
* `max_sent_len`        — longest sentence (in tokens)
* `min_sent_len`        — shortest sentence (in tokens)
* `sentence_offsets`    — start index of each sentence in the flat token list

It can either print the result to stdout or write it to a JSON file with
`--out`.

It is also importable: `compute_stats(doc_dict) -> dict`.

Usage
-----
    python count_tokens.py --doc path/to/document.json
    python count_tokens.py --doc path/to/document.json --out stats.json
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path


# ---------------------------------------------------------------------------
# Core
# ---------------------------------------------------------------------------

def compute_stats(doc: dict) -> dict:
    """Compute token statistics for one tokenized document."""
    if not isinstance(doc, dict):
        raise TypeError("Document must be a dict.")

    sentences = doc.get("sentences")
    if not isinstance(sentences, list):
        raise ValueError("Document is missing a 'sentences' list.")

    for i, s in enumerate(sentences):
        if not isinstance(s, list):
            raise ValueError(f"sentences[{i}] is not a list of tokens.")
        for j, t in enumerate(s):
            if not isinstance(t, str):
                raise ValueError(f"sentences[{i}][{j}] is not a string token.")

    flat_tokens: list[str] = []
    sentence_offsets: list[int] = []
    sent_lens: list[int] = []

    for sent in sentences:
        sentence_offsets.append(len(flat_tokens))
        flat_tokens.extend(sent)
        sent_lens.append(len(sent))

    n_sentences = len(sentences)
    n_tokens = len(flat_tokens)
    n_alpha = sum(1 for t in flat_tokens if any(c.isalpha() for c in t))

    mean_len = (n_tokens / n_sentences) if n_sentences else 0.0
    max_len = max(sent_lens) if sent_lens else 0
    min_len = min(sent_lens) if sent_lens else 0

    return {
        "doc_id": doc.get("doc_id"),
        "n_sentences": n_sentences,
        "n_tokens": n_tokens,
        "n_alpha_tokens": n_alpha,
        "mean_sent_len": round(mean_len, 2),
        "max_sent_len": max_len,
        "min_sent_len": min_len,
        "sentence_offsets": sentence_offsets,
    }


def print_report(stats: dict) -> None:
    print(f"doc_id          : {stats.get('doc_id')}")
    print(f"n_sentences     : {stats['n_sentences']}")
    print(f"n_tokens        : {stats['n_tokens']}")
    print(f"n_alpha_tokens  : {stats['n_alpha_tokens']}")
    print(f"mean_sent_len   : {stats['mean_sent_len']}")
    print(f"max_sent_len    : {stats['max_sent_len']}")
    print(f"min_sent_len    : {stats['min_sent_len']}")


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------

def main() -> int:
    p = argparse.ArgumentParser(description="Count tokens for a SciNLP NER input document.")
    p.add_argument("--doc", required=True, help="Path to the input JSON document.")
    p.add_argument("--out", help="Optional path to write a stats JSON.")
    p.add_argument("--no-offsets", action="store_true",
                   help="Omit the sentence_offsets array from the JSON output.")
    args = p.parse_args()

    try:
        doc = json.loads(Path(args.doc).read_text(encoding="utf-8"))
    except FileNotFoundError:
        sys.exit(f"[ERROR] File not found: {args.doc}")
    except json.JSONDecodeError as exc:
        sys.exit(f"[ERROR] Invalid JSON in {args.doc}: {exc}")

    try:
        stats = compute_stats(doc)
    except (TypeError, ValueError) as exc:
        sys.exit(f"[ERROR] {exc}")

    print_report(stats)

    if args.out:
        out_stats = dict(stats)
        if args.no_offsets:
            out_stats.pop("sentence_offsets", None)
        Path(args.out).write_text(
            json.dumps(out_stats, indent=2, ensure_ascii=False),
            encoding="utf-8",
        )
        print(f"\n[OK] Wrote {args.out}")

    return 0


if __name__ == "__main__":
    sys.exit(main())
