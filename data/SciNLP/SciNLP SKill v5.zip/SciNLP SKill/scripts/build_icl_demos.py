#!/usr/bin/env python3
"""
build_icl_demos.py
==================
Build an in-context learning (ICL) demonstration bank for the SciNLP NER
extractor skill.

Inputs
------
1. `--docs`  : a JSONL file where each line is one tokenized document with the
   schema used by the skill:
       {"doc_id": "...", "sentences": [[tok, tok, ...], [tok, tok, ...], ...]}

2. `--gold`  : a JSONL file where each line is one gold entity annotation in
   the schema produced by the skill:
       {"doc_id": "...", "sent_idx": 0, "text": "BERT",
        "token_start": 6, "token_end": 7,
        "local_token_start": 6, "local_token_end": 7,
        "label": "Model"}

Output
------
A JSON file (default: `icl_demos.json`) containing both a flat demo list and
demos grouped by label, with a balanced selection of up to `--max-per-label`
demos per label. Each demo carries:

    {
      "label":         "Model",
      "entity_string": "BERT",
      "token_start":   6,      # global, over flattened doc tokens
      "token_end":     7,
      "local_token_start": 6,  # within the sentence
      "local_token_end":   7,
      "context_tokens":  [...] # window around the entity, with the entity
                                # itself marked by [E] and [/E] sentinels
    }

Usage
-----
    python build_icl_demos.py \
        --docs train_docs.jsonl \
        --gold train_entities.jsonl \
        --out icl_demos.json \
        --max-per-label 10 \
        --context-window 8

The `--context-window` argument controls how many tokens before/after the
entity span are included in the context window (default: 8).
"""

from __future__ import annotations

import argparse
import json
import random
import sys
from collections import defaultdict
from pathlib import Path

VALID_LABELS = {"Task", "Model", "Dataset", "Metric"}


# ---------------------------------------------------------------------------
# I/O helpers
# ---------------------------------------------------------------------------

def read_jsonl(path: str) -> list[dict]:
    rows = []
    with open(path, "r", encoding="utf-8") as f:
        for i, line in enumerate(f, start=1):
            line = line.strip()
            if not line:
                continue
            try:
                rows.append(json.loads(line))
            except json.JSONDecodeError as exc:
                print(f"[WARN] {path} line {i}: bad JSON — {exc}", file=sys.stderr)
    return rows


def write_json(data, path: str) -> None:
    Path(path).write_text(json.dumps(data, indent=2, ensure_ascii=False),
                          encoding="utf-8")
    print(f"[OK] Wrote {path}")


# ---------------------------------------------------------------------------
# Core logic
# ---------------------------------------------------------------------------

def index_docs(docs: list[dict]) -> dict[str, dict]:
    """Return {doc_id: {"sentences": [...], "flat": [...], "sent_offsets": [...]}}."""
    out = {}
    for d in docs:
        doc_id = d.get("doc_id")
        sents = d.get("sentences")
        if not doc_id or not isinstance(sents, list):
            continue
        flat = []
        offsets = []
        for s in sents:
            offsets.append(len(flat))
            flat.extend(s)
        out[doc_id] = {
            "sentences": sents,
            "flat": flat,
            "sent_offsets": offsets,
        }
    return out


def build_context_window(sent_tokens: list[str],
                         local_start: int,
                         local_end: int,
                         window: int) -> list[str]:
    """Return a window of tokens around the entity with [E] / [/E] markers."""
    left = max(0, local_start - window)
    right = min(len(sent_tokens), local_end + window)

    pre = sent_tokens[left:local_start]
    span = sent_tokens[local_start:local_end]
    post = sent_tokens[local_end:right]

    return pre + ["[E]"] + span + ["[/E]"] + post


def verify_entity(doc: dict, ent: dict) -> tuple[bool, str]:
    """Sanity-check that the gold entity actually aligns with the document."""
    sent_idx = ent.get("sent_idx")
    ts = ent.get("token_start")
    te = ent.get("token_end")
    lts = ent.get("local_token_start")
    lte = ent.get("local_token_end")
    text = ent.get("text", "")

    if sent_idx is None or not (0 <= sent_idx < len(doc["sentences"])):
        return False, f"bad sent_idx {sent_idx}"
    if ts is None or te is None or lts is None or lte is None:
        return False, "missing offsets"
    if te <= ts or lte <= lts:
        return False, "non-positive span"

    sent = doc["sentences"][sent_idx]
    if lte > len(sent):
        return False, "local_token_end out of range"

    flat_slice = doc["flat"][ts:te]
    local_slice = sent[lts:lte]
    if flat_slice != local_slice:
        return False, "flat/local slice mismatch"

    expected = " ".join(local_slice)
    if text and text != expected:
        return False, f"text mismatch: {text!r} vs {expected!r}"

    s_off = doc["sent_offsets"][sent_idx]
    if ts != s_off + lts or te != s_off + lte:
        return False, "global/local offset mismatch"

    return True, "ok"


def build_demos(docs_by_id: dict[str, dict],
                gold: list[dict],
                context_window: int) -> list[dict]:
    demos = []
    skipped = 0
    for ent in gold:
        label = ent.get("label")
        if label not in VALID_LABELS:
            skipped += 1
            continue
        doc_id = ent.get("doc_id")
        doc = docs_by_id.get(doc_id)
        if not doc:
            skipped += 1
            continue

        ok, reason = verify_entity(doc, ent)
        if not ok:
            skipped += 1
            continue

        sent_idx = ent["sent_idx"]
        lts = ent["local_token_start"]
        lte = ent["local_token_end"]

        demos.append({
            "doc_id": doc_id,
            "sent_idx": sent_idx,
            "label": label,
            "entity_string": ent.get("text", " ".join(doc["sentences"][sent_idx][lts:lte])),
            "token_start": ent["token_start"],
            "token_end": ent["token_end"],
            "local_token_start": lts,
            "local_token_end": lte,
            "context_tokens": build_context_window(
                doc["sentences"][sent_idx], lts, lte, context_window
            ),
        })

    if skipped:
        print(f"[INFO] Skipped {skipped} gold rows that failed validation.",
              file=sys.stderr)
    return demos


def balance_by_label(demos: list[dict],
                     max_per_label: int,
                     seed: int) -> dict[str, list[dict]]:
    rng = random.Random(seed)
    by_label = defaultdict(list)
    for d in demos:
        by_label[d["label"]].append(d)

    balanced = {}
    for label in VALID_LABELS:
        bucket = by_label.get(label, [])
        rng.shuffle(bucket)
        balanced[label] = bucket[:max_per_label]
    return balanced


def render_prompt_blocks(balanced: dict[str, list[dict]]) -> dict[str, str]:
    blocks = {}
    for label, items in balanced.items():
        if not items:
            blocks[label] = f"[No demonstrations available for {label}]"
            continue
        lines = [f"--- {label} EXAMPLES ---"]
        for d in items:
            ctx = " ".join(d["context_tokens"])
            lines.append(
                f'Context : "{ctx}"\n'
                f'Entity  : "{d["entity_string"]}" '
                f'(local tokens {d["local_token_start"]}–{d["local_token_end"]})\n'
                f'Label   : {label}'
            )
        blocks[label] = "\n\n".join(lines)
    return blocks


def print_summary(balanced: dict[str, list[dict]]) -> None:
    print("\n=== ICL Demonstration Summary ===")
    total = 0
    for label in sorted(VALID_LABELS):
        n = len(balanced.get(label, []))
        total += n
        bar = "█" * n
        print(f"  {label:<8} {n:>4}  {bar}")
    print(f"\n  Total selected: {total}")


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------

def main() -> int:
    p = argparse.ArgumentParser(description="Build SciNLP ICL demonstration bank.")
    p.add_argument("--docs", required=True, help="Path to tokenized docs JSONL.")
    p.add_argument("--gold", required=True, help="Path to gold entity JSONL.")
    p.add_argument("--out", default="icl_demos.json", help="Output JSON path.")
    p.add_argument("--max-per-label", type=int, default=10,
                   help="Max demos per label (default: 10).")
    p.add_argument("--context-window", type=int, default=8,
                   help="Token window on each side of the entity (default: 8).")
    p.add_argument("--seed", type=int, default=13,
                   help="Random seed for sampling (default: 13).")
    args = p.parse_args()

    docs = read_jsonl(args.docs)
    gold = read_jsonl(args.gold)

    if not docs:
        sys.exit(f"[ERROR] No documents loaded from {args.docs}")
    if not gold:
        sys.exit(f"[ERROR] No gold rows loaded from {args.gold}")

    docs_by_id = index_docs(docs)
    demos = build_demos(docs_by_id, gold, args.context_window)
    if not demos:
        sys.exit("[ERROR] No valid demonstrations could be built.")

    balanced = balance_by_label(demos, args.max_per_label, args.seed)
    print_summary(balanced)

    output = {
        "by_label": balanced,
        "prompt_blocks": render_prompt_blocks(balanced),
        "stats": {label: len(items) for label, items in balanced.items()},
        "config": {
            "max_per_label": args.max_per_label,
            "context_window": args.context_window,
            "seed": args.seed,
        },
    }
    write_json(output, args.out)
    return 0


if __name__ == "__main__":
    sys.exit(main())
