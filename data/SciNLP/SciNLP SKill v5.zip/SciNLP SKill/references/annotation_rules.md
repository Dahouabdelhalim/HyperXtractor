# Annotation Span Rules — SciNLP (Token-Offset Edition)

These rules govern how to choose **token spans** when annotating an input
document under the SciNLP 4-label scheme (`Task`, `Method`, `Dataset`,
`Metric`). They are derived from the SciNLP annotation guideline (Duan et al.,
2026, Appendix A) and adapted for token-level offsets.

All references to "token" mean an element of the pre-tokenized sentence list
in the input JSON file. The skill never re-tokenizes the text.

---

## 1. Articles and Determiners

**General rule:** Do NOT include articles or determiners as the first token
of a span. The following are excluded when they appear at the leading
position:

- `a`, `an`, `the`
- `this`, `that`, `these`, `those`
- `our`, `their`, `its`
- `some`, `any`

Examples (tokens shown as a list, target span tokens marked with `[…]`):

- `the FB15K dataset` → annotate `[FB15K]` only.
- `the SQuAD v1.1 dataset` → annotate `[SQuAD v1.1]`.
- `our BERT model` → annotate `[BERT]`.
- `this algorithm` → do not annotate (anaphoric).

Rationale: SciNLP §A.2.2 explicitly excludes grammatical determiners from
entity spans, except in deliberate comparisons where modifiers matter for
disambiguation. This skill chooses the conservative path: never include them
in the *first* token position.

---

## 2. Abbreviations

When the source contains `Full Name ( ABBR )`, annotate **two separate
spans** with the same label.

Examples:

- `Support Vector Machine ( SVM )` →
  - `Support Vector Machine` (`Method`)
  - `SVM` (`Method`)
- `Social Bias Inference Corpus ( SBIC )` →
  - `Social Bias Inference Corpus` (`Dataset`)
  - `SBIC` (`Dataset`)

The parentheses tokens themselves are **not** part of either span.

Sub-rule: if the abbreviation later appears alone in the document, annotate
that later occurrence as a separate span as well — there is no cross-mention
deduplication in the output (every textual occurrence becomes its own entity
row).

---

## 3. Modifiers

### 3.1 Adjective modifiers

Ask: *does removing the adjective change the identity of the entity?*

- Yes → keep the modifier inside the span.
- No → drop the modifier.

Examples:

- `multilingual BERT` → keep `multilingual` (`multilingual BERT` is a
  different variant from `BERT` alone).
- `modified Kneser-Ney` → keep `modified` (it changes identity).
- `novel BERT-based model` → drop `novel` (evaluative, not identity-changing).
  Resulting span: `BERT-based model` or simply `BERT`, depending on which
  reading better matches the source.

### 3.2 Noun modifiers inside a span

If the canonical name is broken by hyphens, slashes, or internal modifiers
(`BERT-base-uncased`, `T5-base`, `RoBERTa-Large`), annotate the entire
hyphenated phrase as one span — whether the tokenizer kept it as one token
or split it into several.

### 3.3 Trailing scoring or comparative modifiers

Drop trailing comparative words that are not part of the name:

- `BLEU score` → `BLEU`
- `F1 score` → `F1`
- `the accuracy of the Method` → `accuracy`

---

## 4. Generic Head Nouns

Generic nouns (`dataset`, `model`, `corpus`, `method`, `algorithm`, `system`,
`approach`, `framework`, `task`) are **not** included in named entity spans
UNLESS the generic noun is part of the canonical, recognised name of the
entity as the paper uses it.

- `SQuAD dataset` → `SQuAD`
- `the BERT model` → `BERT`
- `Brown Corpus` → keep `Corpus` (part of the canonical name)
- `Penn Treebank` → keep `Treebank` (part of the canonical name)
- `Kneser-Ney language model` → keep `language model` if that is how the
  paper consistently refers to the entity (suffix retention exception, SciNLP
  §A.2.2).
- `SVM algorithm` (as literally written) → keep `algorithm` per SciNLP
  §A.2.2; `SVM` alone (no suffix in source) → annotate `SVM` only.

When uncertain between dropping and keeping the suffix, **drop it** — the
bare name is the safer choice for exact-match evaluation.

---

## 5. Plurals

Bare plural mentions of proper names (`BERT models`, `the ResNets`,
`the image datasets`) are typically generic and are **not annotated** in this
skill, mirroring SciNLP's treatment of plural mentions as generic.

Exception: a plural that names a specific collection or release (e.g.
`CommonCrawls` as a named dataset family) may be annotated as `Dataset`. Apply
this exception only when the plural is clearly a proper name.

---

## 6. Conjunctions and Coordination

For coordinated phrases connecting two named entities, annotate each as a
separate span. Do not annotate the coordinated phrase as one span.

Examples (token lists):

- `BERT and XLNet` → `[BERT]` (`Method`), `[XLNet]` (`Method`).
- `BERT or GPT-2` → `[BERT]`, `[GPT-2]`.
- `Precision , Recall , and F1` → `[Precision]`, `[Recall]`, `[F1]` (all
  `Metric`).
- `BLEU and ROUGE scores` → `[BLEU]`, `[ROUGE]`.

The connector tokens (`and`, `or`, commas) are **not** part of any span.

Coordination with shared modifier:

- `pretrained BERT and GPT-2` → `[BERT]`, `[GPT-2]` (drop the shared modifier
  unless it changes identity).

---

## 7. Nesting

The SciNLP gold corpus permits some nested annotations. **This skill produces
flat (non-nested) output.** When two candidate spans nest, choose exactly one
by the following priority:

1. The span that matches the canonical name of the entity (minimal complete
   name).
2. If both candidates are canonical, prefer the one whose label is most
   strongly supported by the surrounding context.
3. If still tied, prefer the shorter span.

Examples:

- `BERT-based model` → annotate `BERT` (canonical name) rather than the
  whole phrase.
- `the latent variable hierarchical recurrent encoder-decoder architecture
  VHRED` → annotate `VHRED` (the canonical name) rather than the long
  descriptive phrase.

No two output spans may satisfy
`a.token_start <= b.token_start and b.token_end <= a.token_end` unless they
are identical.

---

## 8. Sentence Boundaries

Spans must not cross sentence boundaries. The input file already specifies
sentences as a list of token lists; respect those boundaries exactly. If a
candidate entity appears split across two adjacent sentences (rare; usually a
tokenization artifact), do not annotate it — pick a different mention if
available, or skip.

---

## 9. Punctuation Tokens

Do not include the following tokens at the boundaries of a span:

- `,`, `.`, `;`, `:`, `!`, `?`
- `(`, `)`, `[`, `]`, `{`, `}`
- `"`, `'`, ``…``, `` ` ``

Internal punctuation that is part of the canonical name (e.g. `BERT-base`,
`L-BFGS`) is kept inside the span.

---

## 10. Coreference and Anaphora

Anaphoric and generic mentions are **never annotated** in this skill, even
when they clearly refer to a named entity introduced earlier:

- `it`, `this`, `that`, `the model`, `the system`, `this approach`, `our
  method` — all skipped.

Only annotate **factual, content-bearing mentions** of named entities (SciNLP
§A.2.2). If you need to discuss the entity later in the document, that
discussion will pick up the entity only when its name actually appears.

---

## 11. Negation and Hypothetical Mentions

Do not annotate entities that the paper says are *not* used or are *not*
applicable. Following SciNLP §A.3.2, negative relationships are not
annotated, and by extension entities only mentioned to be excluded are
borderline. The skill's rule:

- Annotate the entity when it is positively referenced (used, evaluated,
  compared, named as a baseline, named as a benchmark, or named as a
  metric).
- Skip the entity when the only mention is a negation (`we do not use BERT`,
  `unlike GPT-3`).

Apply this rule strictly only for clear negations; ordinary comparisons such
as `BERT outperforms GPT-2` keep both spans.

---

## 12. References and Non-Content Sentences

The skill skips:

- Sentences that fall in the References / Bibliography / Works Cited
  section. The references cutoff is detected by scanning for a sentence whose
  lowercased joined tokens equal one of `references`, `bibliography`, or
  `works cited`.
- Figure / Table caption stubs of fewer than 8 tokens beginning with
  `Figure`, `Table`, or `Fig.` followed by a number.
- Sentences with fewer than 3 alphabetic tokens.

Skipped sentences still contribute their tokens to the flat token sequence so
that global token offsets remain stable across the document.

---

## 13. Conflict Resolution (Single-Pass and Multi-Pass)

If the extractor runs more than one pass over the document and produces
candidate spans that disagree, apply this priority:

| Conflict | Resolution |
|---|---|
| Same `(token_start, token_end)`, different labels | Re-apply Section 9 of `SKILL.md` (Label Decision Rules). If still tied, prefer `Model` > `Dataset` > `Task` > `Metric`. |
| Same label, different boundaries (overlap) | Keep the canonical-name span. If both are canonical, keep the shorter span. |
| Nested same-label spans | Keep the inner (more specific) span. |
| Nested different-label spans | Pick the span whose label is more strongly supported by context; drop the other entirely. |
| Conflict between an acronym and its expansion in the same sentence | Keep both (this is the acronym pair rule, not a conflict). |

After applying these rules, the final output must satisfy all checks listed
in `SKILL.md` Section 14.

---

## 14. Cross-Sentence Consistency

Each occurrence of a named entity in the document is annotated independently.
There is no requirement that the same name carry the same label across the
document — but if the surface form is identical and the surrounding context
is similar, the same label is strongly expected. Inconsistent labels for the
same surface form across sentences is a quality-control flag; review such
cases before finalising.
