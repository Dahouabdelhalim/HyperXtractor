# Entity Definitions — SciNLP 4-Label Scheme

This guide defines the **strict 4-label annotation scheme** of the SciNLP
benchmark (Duan et al., 2026) for scientific entity extraction in NLP
publications.

The only valid labels are:

1. `Task`
2. `Method`
3. `Dataset`
4. `Metric`

This file is the authoritative label guide for the `scinlp-ner-extractor`
skill. All operational rules (sentence segmentation, output schema, token
offsets) live in `SKILL.md`; this file defines **what counts as an entity of
each type**.

---

## Global Rules

### 1) No extra labels
Do not invent or use labels beyond the four above. In particular do not use:

- `Method` — algorithms and named procedures fall under `Method` only when
  they are specific named instances (e.g. `Adam`, `SVM`).
- `ModelArchitecture` — named architectures (`Transformer`, `LSTM`, `BiLSTM`,
  `CNN`) are labelled `Method` under SciNLP.
- `DataSource` — `Wikipedia`, `Twitter`, `Reddit`, etc. are not annotated as a
  separate type. They are annotated only when they appear as part of a clearly
  named dataset release (e.g. `Wikipedia dump 2022`), and in that case the
  label is `Dataset`.
- `Tool`, `Library`, `Loss`, `Hyperparameter`.

### 2) No nesting in the output
The SciNLP paper itself permits some nesting in its gold corpus, but this
skill **flattens** to one label per span. Choose the span and the label that
matches the function of the mention in context.

### 3) Minimal complete span
Select the shortest token span that uniquely identifies the entity.

### 4) Skip borderline mentions
If a mention is too generic or cannot be assigned confidently to one of the
four labels, do not annotate it.


Examples:

- `the BERT model` → annotate `BERT` only.
- `the SQuAD dataset` → annotate `SQuAD` only.

### 6) Suffix retention exception
Following SciNLP §A.2.2, when an entity is *written* with an algorithm-style
suffix as part of how the paper actually refers to it, the suffix is kept:

- `SVM algorithm` (literally written that way in the source) → keep the suffix.
- `Brown Corpus`, `Penn Treebank`, `IWSLT 2009 dialog task data set` — keep
  the full multi-token name because the head noun is part of the canonical
  identifier.

Apply this exception sparingly. The default remains the bare name.

### 7) Plurals
Bare plurals of named entities are normally **not** annotated under this skill
(`BERT models`, `the ResNets`, `the image datasets`). They are too generic.
Annotate only the singular named form when it appears elsewhere.

### 8) Conjunctions
Do not annotate a coordinated phrase as a single span. Split into separate
spans:

- `BERT and GPT-2` → `BERT` (`Method`) + `GPT-2` (`Method`).
- `Precision and Recall` → `Precision` (`Metric`) + `Recall` (`Metric`).

### 9) Acronym pairs
`Full Name (ABBR)` produces two spans with the same label.

- `Support Vector Machine (SVM)` → `Support Vector Machine` (`Method`) and
  `SVM` (`Method`).
- `Social Bias Inference Corpus (SBIC)` → `Social Bias Inference Corpus`
  (`Dataset`) and `SBIC` (`Dataset`).

---

## 1. Task

### Definition
A named machine learning, NLP, speech, or vision **problem** that a system is
designed to solve. From SciNLP §A.2.1: "A task constitutes an objective
requiring operational resolution through systematic processes."

### Use this label when
The mention names a benchmarkable or recognisable
prediction/generation/classification/retrieval/recognition problem.

### Positive examples
- `named entity recognition`, `NER`
- `question answering`, `QA`
- `machine translation`
- `text classification`
- `sentiment analysis`
- `summarization`
- `dependency parsing`
- `part-of-speech tagging`
- `automatic keywords extraction`
- `text generation`
- `text indexation`
- `conversation generation`

### Negative examples
- `the downstream task` (anaphoric)
- `NLP` (field label, not a task)
- `classification` alone, when used as a generic category
- `our task` (anaphoric)

### Boundary rule
Annotate the core task name. Trim leading modifiers when they are not part of
the canonical task name.

Examples:
- `cross-lingual named entity recognition` → `named entity recognition`
- `document-level sentiment analysis` → `sentiment analysis`
- `neural machine translation task` → `machine translation`

### Decision test
Ask: *is this the problem being solved by the system?* If yes → `Task`.

---

## 2. Method

### Definition
A specific algorithm, architecture, or named Method entity used or referenced
as a system in the paper. From SciNLP §A.2.1: "Method entities refer to
specific algorithms or Method architectures explicitly mentioned in scientific
literature or technical documentation, designed to solve computational tasks."

### Use this label when
The mention is a named system or named algorithm being trained, fine-tuned,
evaluated, compared, used as a baseline, or referenced as a building block.

### Positive examples
- pretrained language models: `BERT`, `RoBERTa`, `GPT`, `GPT-2`, `GPT-3`,
  `T5`, `XLM-R`, `mBERT`
- general architectures used by name: `Transformer`, `LSTM`, `BiLSTM`,
  `BiLSTM layer`, `CNN`, `RNN`, `GRU`, `encoder-decoder`, `attention`,
  `self-attention`, `Seq2Seq`, `VHRED`, `HRAN`
- classical algorithms: `SVM`, `KNN`, `LDA`, `Decision Trees`, `Skip-gram`,
  `Boltzmann machine`
- optimizers used by name: `Adam`, `L-BFGS`, `SGD`
- named systems / baselines: `PURE`, `PL-Marker`, `HGERE`, `CorefNet`,
  `ReDR`, `CopyNet`, `RPART`, `CART`
- vision models: `ResNet-50`, `VGG-16`

### Negative examples
- `the Method` (anaphoric)
- `our Method` (anaphoric)
- `baseline system` (generic)
- `deep learning` (broad category)
- `machine learning` (broad category)

### Boundary rule
Annotate the canonical name only, except when the literal source phrase
includes a suffix word that is part of how the paper refers to the system.

Examples:
- `pretrained RoBERTa-Large encoder` → `RoBERTa-Large`
- `SVM algorithm` (as written) → `SVM algorithm`
- `bounded L-BFGS (Behm et al., 2009) algorithm` →
  `L-BFGS (Behm et al., 2009) algorithm`
- `Kneser-Ney language model` → `Kneser-Ney language model` (the head is part
  of the canonical name as used in the paper)
- `modified Kneser-Ney` → `modified Kneser-Ney` (the adjective changes
  identity)
- `Jelinek-Mercer baselines` → `Jelinek-Mercer`

### Decision test
Ask: *is this mention treated as a Method/algorithm/system in the work?* If
yes → `Method`.

---

## 3. Dataset

### Definition
A named, stable, reusable data resource used for training, validation, or
evaluation. From SciNLP §A.2.1: "Dataset entities represent structured data
resources explicitly used or referenced in scientific research for training,
evaluation, or analysis."

### Use this label when
The mention refers to a named data resource — a benchmark, a corpus, a
released dataset, or a clearly-named data partition.

### Positive examples
- benchmarks: `SQuAD`, `GLUE`, `XNLI`, `MLQA`, `CoQA`, `NewsQA`, `SearchQA`,
  `CIFAR-10`, `CIFAR-100`, `Persona-Chat`, `FB15K`, `IMDB`, `RCV1`,
  `20-newsgroups`, `20NG`
- linguistic resources: `Brown Corpus`, `Penn Treebank`, `WordNet`, `DSO corpus`
- versioned releases: `IWSLT 2009 dialog task data set`, `Wikipedia dump 2022`
- named collections: `Social Bias Inference Corpus`, `SBIC`

### Negative examples
- `the dataset` (anaphoric)
- `training corpus` (generic, no name)
- `Twitter` alone (live source, not a frozen dataset under this scheme)
- `Wikipedia` alone (live source, not a frozen dataset under this scheme)

### Boundary rule
Drop generic suffixes when they are not part of the name; keep them when they
are part of the canonical identifier.

- `SQuAD dataset` → `SQuAD`
- `the FB15K dataset` → `FB15K`
- `Penn Treebank` → keep full span (`Treebank` is part of the name)
- `Brown Corpus` → keep full span (`Corpus` is part of the name)

### Acronym pair rule
`Full Name (ABBR)` → two separate spans with the same label.

### Decision test
Ask: *is this a named data artifact rather than a vague reference?* If yes →
`Dataset`.

---

## 4. Metric

### Definition
A named quantitative measure used to evaluate the performance of models,
algorithms, or experimental results. From SciNLP §A.2.1: "Metric entities
denote quantitative measures used to evaluate the performance of models,
algorithms, or experimental results in scientific research."

### Use this label when
The mention names a recognised evaluation measure.

### Positive examples
- `Accuracy`
- `Precision`, `Recall`
- `F1`, `F1-score`, `F-score`
- `BLEU`, `BLEU-4`
- `ROUGE`, `ROUGE-L`
- `METEOR`
- `Kappa`, `Cohen's kappa`
- `perplexity`
- `error rate`
- `mean average precision`, `mAP`

### SciNLP edge cases
SciNLP Table 6 row 5 labels `active learning` and `countmerging` as `Metrics`
in the context of a discussion of evaluative procedures. This is a corpus
quirk rather than a general rule. Under this skill:

- prefer `Method` for named algorithms (`Adam`, `SVM`, `Skip-gram`).
- use `Metric` only for quantitative or evaluative measures.
- if a paper explicitly frames a procedure as the evaluative axis being
  discussed (e.g. "we measure quality via X"), `Metric` is permissible for X
  when X has no clearer label.

### Negative examples
- `the metric` (anaphoric)
- `evaluation` (generic)
- `score` alone (generic)
- `performance` (generic)

### Boundary rule
Annotate just the metric name. Drop scoring suffixes when redundant.

- `BLEU score` → `BLEU`
- `F1 score` → `F1` (or `F1-score` if written as a hyphenated single token)
- `the accuracy of the Method` → `accuracy`

### Decision test
Ask: *is this a quantitative measure used to assess a system?* If yes →
`Metric`.

---

## Hard Distinctions

### Method vs Task
- A system → `Method`.
- A problem → `Task`.

Examples:
- `we fine-tune BERT` → `Method`.
- `we work on machine translation` → `Task`.

### Method vs Metric
- A named algorithm/architecture/optimizer → `Method`.
- A quantitative measure → `Metric`.

Examples:
- `Adam` → `Method`.
- `F1-score` → `Metric`.

### Dataset vs Task
SciNLP allows benchmark names to be annotated as both `Dataset` and `Task`.
This skill avoids double-tagging. Choose by function:

- `evaluated on SQuAD` → `Dataset`.
- `the SQuAD task` → `Task`.
- if unclear → `Dataset` (more conservative).

### Dataset vs Method
- Trained/evaluated *with* the entity → `Dataset`.
- Trained/evaluated *as a system* → `Method`.

Examples:
- `we pretrain on Wikipedia dump 2022` → `Dataset`.
- `we evaluate BERT` → `Method`.

### Live source vs Dataset
Under SciNLP, live sources (`Twitter`, `Wikipedia`, `Reddit`) are not
annotated as a separate type. Annotate them only when they appear as part of
a named dataset release, in which case the label is `Dataset`.

---

---

## Compact Decision Table

| Mention type | Label |
|---|---|
| named ML/NLP problem | `Task` |
| named algorithm, architecture, optimizer, or system | `Method` |
| named benchmark / corpus / released dataset | `Dataset` |
| named quantitative evaluation measure | `Metric` |

---

## Final Annotation Advice

When two labels seem possible, choose the one supported by the **function of
the mention in context**. When the function is still unclear, skip the
mention. This scheme is intentionally conservative so that exact-match
evaluation becomes more reliable.
