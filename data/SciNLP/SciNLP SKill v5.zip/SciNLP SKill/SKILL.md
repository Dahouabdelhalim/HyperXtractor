---
name: scinlp-ner-extractor-token-offsets-maximum-recall
description: >
  Extract named entities from full-text NLP scientific publications using the
  SciNLP 4-label scheme (Task, Method, Dataset, Metric). Input is a JSON file
  containing tokenized sentences for ONE document. Output is final_annotations.csv
  with token-level offsets over the flattened document-level token sequence.
  The extractor runs in MAXIMUM-RECALL mode: extract all possible valid entity
  mentions, including repeated occurrences, variants, abbreviations, full names,
  names in titles/captions/tables, and all plausible mentions fitting the four
  labels. Do not remove, clean, normalize, deduplicate, merge, or suppress entity
  mentions. Tokens must be used exactly as provided. Offsets are inclusive:
  start_token is the first token and end_token is the last token. For one-token
  entities, start_token == end_token. For multi-token entities:
  end_token = start_token + number_of_tokens_in_span - 1.
---

# SciNLP NER Extractor — Maximum-Recall Token-Offset Edition

## 1) Allowed Labels

Use exactly these labels:

- `Task`
- `Method`
- `Dataset`
- `Metric`

No other labels are allowed.

Map named algorithms, architectures, optimizers, systems, and baselines to
`Method`. Map evaluation measures to `Metric`. Map reusable benchmarks/corpora to
`Dataset`. Map concrete NLP/ML problems to `Task`.

---

## 2) Maximum-Recall Rule

Extract a huge number of possible valid entities.

Do:

- extract every valid or plausible mention that fits the four labels
- keep repeated occurrences
- keep full names and abbreviations separately
- keep variants separately
- keep case variants separately
- keep versioned names separately
- keep task, Method, dataset, and metric mentions from all document sections
- annotate mentions in titles, abstracts, tables, captions, body text, and appendices when present in the tokenized input

Do not:

- deduplicate
- normalize
- clean
- canonicalize
- merge equivalent entities
- remove repeated strings
- remove later occurrences
- rewrite entity text
- lowercase or uppercase text
- remove punctuation inside the selected span
- suppress entities because they already appeared before

Every valid textual occurrence must become its own CSV row.

---

## 3) Input Format

Input JSON:

```json
{
  "doc_id": "P19-1001",
  "sentences": [
    ["In", "this", "paper", ",", "we", "fine-tune", "BERT", "on", "SQuAD", "."],
    ["The", "model", "achieves", "92.1", "F1", "."]
  ]
}
```

Required keys:

- `doc_id`
- `sentences`

Use tokens exactly as provided.

Do not re-tokenize, split, merge, normalize, strip, repair, or clean tokens.

---

## 4) Token Offset Convention

Offsets are computed over the flattened document-level token sequence.

Given:

```python
sentences = [
    ["In", "this", "paper", ",", "we", "fine-tune", "BERT", "on", "SQuAD", "."],
    ["The", "model", "achieves", "92.1", "F1", "."]
]
```

Flattened tokens:

```python
flat_tokens = [
    "In", "this", "paper", ",", "we", "fine-tune", "BERT", "on", "SQuAD", ".",
    "The", "model", "achieves", "92.1", "F1", "."
]
```

Global indices:

```text
0 In
1 this
2 paper
3 ,
4 we
5 fine-tune
6 BERT
7 on
8 SQuAD
9 .
10 The
11 model
12 achieves
13 92.1
14 F1
15 .
```

Rules:

- `start_token` is inclusive.
- `end_token` is inclusive.
- For one-token entities: `start_token == end_token`.
- For multi-token entities: `end_token = start_token + number_of_tokens_in_span - 1`.
- Offsets never reset at sentence boundaries.

For sentence `i`:

```python
sentence_start_offset[i] = sum(len(sentences[j]) for j in range(i))
```

For an entity in sentence `i`:

```python
token_start = sentence_start_offset[i] + local_token_start
token_end   = sentence_start_offset[i] + local_token_end
```

Validation:

```python
text == " ".join(flat_tokens[start_token:end_token + 1])
```

---

## 5) Extraction Procedure

For each sentence in order:

1. Compute its document-level `sentence_start_offset`.
2. Read tokens exactly as provided.
3. Identify all possible valid `Task`, `Model`, `Dataset`, and `Metric` mentions.
4. Do not stop at the first match.
5. Do not skip repeated mentions.
6. Do not skip variants or abbreviations.
7. For each mention, compute inclusive global offsets.
8. Preserve exact entity text using:

```python
text = " ".join(sentence_tokens[local_token_start:local_token_end + 1])
```

Internal fields:

```text
doc_id
sent_idx
label
text
local_token_start
local_token_end
start_token
end_token
```

Final CSV emits only:

```text
doc_key,local_entity_id,text,start_token,end_token,ner_label
```

---

### ICL Demonstration Retrieval

A demonstration bank can be built from a gold-annotated training file in:

references/ICL_demonstrations.json

using:

scripts/build_icl_demos.py

It outputs a JSON file where each demo carries:

label
entity_string
token_start
token_end
a short context window of tokens around the span

For each input document, before extracting:

Identify likely target labels from the document's overall topic.
Retrieve 5 demonstrations from the bank, balanced across labels and
prioritising the labels most relevant to the current document.
Use the retrieved demonstrations as label and span-shape guidance.
Never copy demonstration offsets or IDs into the output.
Compute all offsets only from the current input file.
Demonstration offsets are guidance only.
Final offsets must be recalculated from the current document's flattened
token sequence.
Demonstrations must not restrict extraction coverage.
If the demonstrations show only a few examples, still extract all possible
valid mentions from the current document.

----

## 6) Label Rules

### Method

Use `Method` for named algorithms, architectures, optimizers, model families,
systems, and baselines.

Examples:

```text
BERT, GPT, GPT-2, RoBERTa, T5, mT5, XLM-R, Transformer, LSTM, BiLSTM, CNN,
RNN, CRF, HMM, SVM, KNN, Decision Trees, Random Forest, LDA, Skip-gram,
Adam, L-BFGS, PURE, PL-Marker, HGERE, CorefNet, ReDR
```

### Task

Use `Task` for concrete NLP/ML problems.

Examples:

```text
named entity recognition, NER, question answering, QA, machine translation,
MT, text classification, sentiment analysis, summarization, dependency parsing,
part-of-speech tagging, POS tagging, relation extraction, coreference resolution,
entity linking, natural language inference, NLI, information extraction,
sequence labeling, slot filling, intent detection
```

### Dataset

Use `Dataset` for named reusable datasets, corpora, and benchmarks.

Examples:

```text
SQuAD, SQuAD 2.0, GLUE, SuperGLUE, XNLI, MLQA, CoQA, NewsQA, Persona-Chat,
Brown Corpus, Penn Treebank, WordNet, DSO corpus, IWSLT 2009 dialog task data set,
FB15K, CoNLL-2003, OntoNotes, WMT14, WMT16, MultiNLI, SNLI, MS MARCO,
Natural Questions, HotpotQA, WikiText, WikiText-103, Wikipedia dump 2022
```

Do not annotate live sources like `Wikipedia`, `Twitter`, or `Reddit` unless
they are part of a named dataset/release.

### Metric

Use `Metric` for evaluation measures and scores.

Examples:

```text
Accuracy, Precision, Recall, F1, F1-score, micro-F1, macro-F1, BLEU, BLEU-4,
ROUGE, ROUGE-L, METEOR, Kappa, Cohen's kappa, perplexity, PPL, Exact Match,
EM, Mean Reciprocal Rank, MRR, Hits@1, Hits@10, AUC, AUROC, F-score,
error rate, word error rate, WER, character error rate, CER
```

---

## 7) Boundary Rules

- Exclude leading determiners when clearly outside the entity:
  `the BERT model` → `BERT`.
- Keep suffixes when part of the named expression:
  `SVM algorithm`, `Brown Corpus`, `Penn Treebank corpus`.
- Keep hyphenated/versioned names:
  `GPT-3`, `BLEU-4`, `BERT-base`, `XLM-R`.
- If tokenizer split a versioned name, annotate the full multi-token span:
  `["XLM", "-", "R"]` → `XLM - R`.
- Full name and acronym are separate spans:
  `named entity recognition ( NER )` → `named entity recognition` and `NER`.
- Split conjunctions:
  `BERT and GPT-2` → `BERT`, `GPT-2`.
- Exclude surrounding punctuation unless integral to the name.
- Do not create nested spans unless the text explicitly provides separate valid mentions.

---

## 8) Disambiguation Rules

- System trained/used/evaluated → `Method`.
- Problem solved → `Task`.
- Reusable data resource → `Dataset`.
- Evaluation measure → `Metric`.
- If `SQuAD` is used as data → `Dataset`.
- If `SQuAD task` clearly refers to the problem → `Task`.
- If unclear between Dataset and Task, prefer `Dataset`.
- Annotate metric names, not numeric values alone.

---

## 9) What Not to Annotate

Do not annotate items clearly outside the four-label schema:

- generic mentions: `the model`, `the task`, `the dataset`, `our method`
- vague phrases: `our approach`, `proposed framework`, `our system`
- broad fields when not concrete tasks: `AI`, `NLP`, `machine learning`, `deep learning`
- hardware: `GPU`, `TPU`, `CPU`
- libraries unless evaluated as systems: `PyTorch`, `TensorFlow`, `scikit-learn`
- hyperparameters: `learning rate`, `batch size`, `dropout`, `epochs`
- losses unless used as evaluation metrics
- authors, institutions, venues, citations alone
- numeric values alone

---

## 10) Output CSV

Create:

```text
final_annotations.csv
```

Columns exactly:

```text
doc_key,local_entity_id,text,start_token,end_token,ner_label
```

Rules:

- UTF-8
- comma-separated
- header required
- one entity per row
- no blank rows
- standard CSV quoting
- preserve repeated mentions
- preserve exact text
- sort by `start_token`, then `end_token`
- assign `local_entity_id` after sorting, starting from 1

Example:

```csv
doc_key,local_entity_id,text,start_token,end_token,ner_label
P19-1001,1,BERT,6,6,Method
P19-1001,2,SQuAD,8,8,Dataset
P19-1001,3,F1,14,14,Metric
P19-1001,4,named entity recognition,22,24,Task
P19-1001,5,CoNLL-2003,26,26,Dataset
```

---

## 11) Companion JSON

Create:

```text
annotation_stats.json
```

Format:

```json
{
  "doc_key": "...",
  "n_sentences": 312,
  "n_tokens": 8421,
  "n_entities": 187,
  "by_label": {
    "Task": 41,
    "Method": 78,
    "Dataset": 44,
    "Metric": 24
  }
}
```

---

## 12) Validation Checklist

Before finalizing:

1. Only `Task`, `Method`, `Dataset`, `Metric` appear.
2. Entity text is not cleaned or normalized.
3. Repeated mentions are preserved.
4. Variants and abbreviations are preserved.
5. Offsets are global document-level offsets.
6. Offsets never reset per sentence.
7. `start_token` and `end_token` are inclusive.
8. One-token entity: `start_token == end_token`.
9. Multi-token entity: `end_token = start_token + span_length - 1`.
10. Every row satisfies:

```python
text == " ".join(flat_tokens[start_token:end_token + 1])
```

11. No duplicate identical triple:

```text
(start_token, end_token, ner_label)
```

12. Final annotation set should be large when the document contains many valid mentions.

---

## 13) Final Agent Instruction

You are a maximum-recall SciNLP NER extractor.

Do not summarize. Do not clean. Do not deduplicate. Do not normalize.

For the given tokenized document:

1. Flatten all sentences into one document-level token sequence.
2. Extract every possible valid `Task`, `Method`, `Dataset`, and `Metric`.
3. Keep all repeated occurrences, variants, abbreviations, and full names.
4. Compute inclusive global token offsets.
5. Return `final_annotations.csv`.
6. Return `annotation_stats.json`.

The final annotation file should contain as many valid entity rows as possible.
