---
name: repo2json-contrib-extractor-13-04-2026
description: "Extract ALL contribution-related entities defined by the ML-workflow ontology from ML/AI software repositories into STRICT JSON-LD. Includes character/line offsets, file-path provenance, prefix/suffix context, and full attribute extraction across scientific, methodological, implementation, execution, and provenance entities."
---

# repo-contrib-extractor

Expert information-extraction system for ML/AI software repositories. This skill extracts all entities and fields defined in the comprehensive schema that are part of a repository's core contribution. All extracted information is formatted into strict JSON-LD with character-level precision and file-path provenance tracking.

## Runtime Inputs (Mandatory)

Before proceeding, you MUST obtain the following from the user:
1. **REPO_URL**: The public GitHub (or equivalent) repository URL.
2. **SCHEMA_TEXT**: A plain-text schema and extraction policy. The canonical Mermaid class diagram is stored in references/schema_mermaid.md.

## Entity Scope

Extract **all ontology entities defined in SCHEMA_TEXT** when evidence for them is present in the repository. Do not restrict extraction to code-specific entities. The ontology scope includes:

| Entity Type | Description | Primary Repository Sources |
|---|---|---|
| Study | Scientific study or investigation | README, documentation, metadata |
| Experiment | Experimental setup or comparison | README, experiment scripts, configs |
| Person | Contributor or author explicitly represented in the repository | README, metadata, citation files |
| Organization | Organization explicitly associated with the work | README, metadata, citation files |
| MLS_Task | ML/NLP task addressed by the implementation | README, documentation, configs |
| MLS_Dataset | Dataset or benchmark used by the workflow | README, configs, data scripts |
| DataSource | Origin or source from which data are obtained | README, data scripts, configs |
| Method | Method or learning strategy used in the workflow | README, documentation, source code |
| MLS_Model | Named model used, trained, or evaluated | README, configs, model code |
| MLS_Algorithm | Named algorithm or optimization procedure | Source code, configs, documentation |
| Prompt | Prompt or instruction used by the workflow | Prompt files, configs, source code |
| MLS_Eval | Evaluation measure or evaluation specification | Evaluation scripts, README, configs |
| MLS_Implementation | Implementation details such as frameworks and entry points | Source code, README |
| Environment | Execution environment such as OS, Python, or CUDA | Dockerfile, conda/environment files |
| MLS_HyperParameter | Training, architecture, optimization, or data hyperparameters | Configs, argparse/dataclasses, source code |
| SoftwareRepository | Repository metadata | README, repository metadata |
| Dependency | Software/package dependencies | requirements/setup/pyproject/environment files |
| DataProcessingStep | Preprocessing or data-pipeline step | Preprocessing/data scripts |
| TrainingRun | Training execution | Training scripts/configs |
| EvaluationRun | Evaluation execution | Evaluation scripts/configs |
| PredictionSet | Prediction or inference output/process | Prediction/inference scripts |

## Hyperparameter Taxonomy (v2)

The schema defines a **typed hyperparameter hierarchy**. Every extracted MLS_HyperParameter entity MUST be classified into exactly one leaf type. The hierarchy is:


MLS_HyperParameter
├── HP_Optimization
│   ├── LearningRate          (aliases: lr, learning_rate, initial_lr, base_lr)
│   ├── Momentum              (aliases: momentum, sgd_momentum)
│   ├── WeightDecay           (aliases: weight_decay, wd, l2_reg, l2_penalty)
│   ├── WarmupSteps           (aliases: warmup_steps, warmup, num_warmup_steps, warmup_ratio)
│   └── DecayRate             (aliases: decay_rate, lr_decay, lr_decay_rate, decay_factor)
├── HP_Training
│   ├── BatchSize             (aliases: batch_size, train_batch_size, per_device_train_batch_size, micro_batch)
│   ├── NumEpochs             (aliases: num_epochs, epochs, num_train_epochs, max_epochs)
│   ├── MaxSteps              (aliases: max_steps, total_steps, training_steps, max_train_steps)
│   ├── Patience              (aliases: patience)
│   ├── GradientAccumulationSteps (aliases: gradient_accumulation_steps, accum_steps, grad_accum)
│   ├── NumWorkers            (aliases: num_workers, dataloader_num_workers, n_workers)
│   └── RandomSeed            (aliases: seed, random_seed, manual_seed)
├── HP_Architecture
│   ├── NumLayers             (aliases: num_layers, n_layers, num_hidden_layers, depth, "N-layer")
│   ├── HiddenSize            (aliases: hidden_size, d_model, hidden_dim, intermediate_size)
│   ├── EmbeddingDim          (aliases: embedding_dim, embed_dim, d_embed, word_embedding_dim)
│   ├── Dropout               (aliases: dropout, dropout_rate, drop_rate, attention_dropout, hidden_dropout)
│   └── AttentionHeads        (aliases: num_attention_heads, n_heads, num_heads, nhead)
└── HP_Data
    ├── MaxSequenceLength     (aliases: max_seq_length, max_length, max_seq_len, max_position_embeddings)
    └── TrainValTestSplit     (aliases: train_split, val_split, test_split, split_ratio)


### Classification Rules

1. **Exact match first**: Match parameter name against leaf aliases (case-insensitive).
2. **Semantic match second**: If no exact alias match, classify by semantic meaning (e.g., "λ" for regularization → WeightDecay).
3. **Fallback**: If a hyperparameter matches no category at all, set "hpType" to the best-fit category name (e.g., "HP_Optimization") and add "uncertain": true.
4. **Multi-value HPs**: If a single parameter name maps to multiple values (e.g., per-dataset or per-run), create one entity per value with dataset/run context in the @id and mls:name.

## Hyperparameter Extraction Strategy (High Recall)

To achieve high recall for hyperparameter extraction, the skill employs a multi-step, framework-aware strategy:

1. **Repo-Driven Candidates**: Scan all config files, argparse definitions, dataclass fields, and README/documentation for any spans that resemble hyperparameters. This includes explicit assignments (e.g., learning_rate: 0.001, --batch-size 32, dropout = 0.1), default argument values in add_argument(...) calls, Hugging Face TrainingArguments fields, and inline comments (e.g., # lr used in paper). Extract the full text span as a candidate.

2. **Classify Each Candidate**: For every candidate, determine its leaf type from the hierarchy above. Set the "hpType" field to the leaf class name (e.g., "LearningRate", "BatchSize", "NumLayers"). If uncertain, mark "uncertain": true.

3. **Framework-Aware Matching**: Identify the referenced framework or component (e.g., PyTorch, TensorFlow/Keras, Hugging Face Transformers, scikit-learn). Internally consult framework documentation knowledge to check if the candidate matches constructor arguments, optimizer parameters, scheduler parameters, or model configuration fields.

4. **Pattern & Alias Expansion**: Perform alias normalization and pattern expansion. Map synonyms (e.g., lr → LearningRate, wd → WeightDecay, λ → WeightDecay, dim → HiddenSize/EmbeddingDim), recognize numeric patterns (scientific notation, ranges, lists), and architecture counts (e.g., num_layers=2 → NumLayers, nhead=8 → AttentionHeads).

If unsure about a hyperparameter, extract it and mark it with "uncertain": true.

## Provenance File Detection

Classify repository files into provenance roles by analysing:

1. **File names**: train.py, eval.py, evaluate.py, preprocess.py, predict.py, infer.py
2. **Function / class names**: Trainer, Evaluator, Preprocessor, DataLoader, Predictor
3. **Import patterns**: torch.optim / transformers.Trainer (→ TrainingRun), sklearn.metrics / evaluate.load (→ EvaluationRun), torchvision.transforms / pandas.read_csv (→ DataProcessingStep), model.generate / pipeline(...) (→ PredictionSet)
4. **Comments / docstrings**: "training script", "evaluation pipeline", "data preprocessing", "inference"

For detailed patterns, consult references/file_patterns.md.

## Workflow

1. **Analyze Inputs**: Read the REPO_URL and SCHEMA_TEXT.
2. **Map Schema**: Interpret the Mermaid class diagram (see references/schema_mermaid.md) to understand all ontology entities, attributes, and relations, including the MLS_HyperParameter hierarchy.
3. **Inspect Repository Structure**: Locate and read relevant source files, entry points, configs, dependency manifests, environment files, documentation, and provenance scripts. Consult references/file_patterns.md for common patterns.
4. **Extract Candidates**: Identify all schema-compliant candidate entities belonging to the repository's core contribution, across the full ontology rather than only code-specific types. Consult references/extraction_policy.md for definitions and rules.
5. **Classify Hyperparameters**: For every retained hyperparameter, assign a leaf type from the HP hierarchy and populate "hpType" and "hpCategory" (HP_Optimization, HP_Training, HP_Architecture, or HP_Data).
6. **Calculate Offsets**: For every retained entity, use scripts/calculate_offsets.py to determine start_char_doc and end_char_doc within the source file and record its relative repository path.
7. **Capture Context**: Extract up to 5 words of prefix and suffix surrounding each entity mention.
8. **Format Output**: Structure the data using the @graph template and @context derived from SCHEMA_TEXT. Consult references/output_schema.md. Set wasDerivedFrom to "code" for entities extracted from repository evidence.
9. **Final Self-Check**:
    - Confirm valid JSON-LD with @context and @graph.
    - Confirm all ontology entity types supported by repository evidence are extracted, not only code-specific types.
    - Confirm every MLS_HyperParameter has "hpCategory" and "hpType".
    - Confirm every extracted entity has repository path provenance, accurate offsets, and prefix/suffix context.
    - Confirm all schema relations and applicable provenance relations are represented.
10. **Deliver Result**: Return the JSON object ONLY.

## Usage Guidelines

- **Strict JSON-LD @graph**: Output must be a single JSON object containing the @context and @graph array.
- **Comprehensive Extraction**: Extract all entities and attributes defined in SCHEMA_TEXT when supported by repository evidence; do not restrict extraction to code-specific entity types.
- **Typed Hyperparameters**: Every MLS_HyperParameter MUST include "hpCategory" and "hpType" fields from the hierarchy.
- **File-Path Provenance**: Every entity MUST include a "path" field (relative repository path) and "wasDerivedFrom": "code".
- **Character Precision**: Offsets must be accurate to the source file content for each extracted entity and value.
- **No Hallucinations**: Use null for missing fields; do not invent data.
- **Schema Adherence**: Strictly follow the entity, attribute, and relation definitions from the SCHEMA_TEXT.