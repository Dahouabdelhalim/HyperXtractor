---
name: paper2jsonld-contrib-extractor-13-04-2026
description: "Extract ALL contribution-related entities from ML/AI scientific papers in Markdown into STRICT JSON-LD using a comprehensive schema (Mermaid class diagram). Includes character offsets, prefix/suffix context, and full attribute extraction for Study, Experiment, Person, Organization, MLS_Task, MLS_Dataset, DataSource, Method, MLS_Model, MLS_Algorithm, Prompt, MLS_Eval, MLS_Implementation, Environment, and a typed MLS_HyperParameter hierarchy (HP_Optimization, HP_Training, HP_Architecture, HP_Data with leaf types such as LearningRate, BatchSize, NumLayers, MaxSequenceLength, etc.)."
---

# paper2jsonld-contrib-extractor

Expert information-extraction system for ML/AI scientific papers. This skill extracts all entities and fields defined in the comprehensive schema that are part of a paper's core contribution. All extracted information is formatted into strict JSON-LD with character-level precision and provenance tracking.

## Runtime Inputs (Mandatory)

Before proceeding, you MUST obtain the following from the user:
1. **PAPER_MD**: The full scientific paper content in Markdown.
2. **SCHEMA_TEXT**: A plain-text schema and extraction policy. The canonical Mermaid class diagram is stored in `references/schema_mermaid.md`. This schema includes the `mls:ExperimentGroup` type used for grouped experiment output (see § *Experiment Entity Grouping*).

## Hyperparameter Taxonomy (v2)

The schema defines a **typed hyperparameter hierarchy**. Every extracted `MLS_HyperParameter` entity MUST be classified into exactly one leaf type. The hierarchy is:

```
MLS_HyperParameter
├── HP_Optimization
│   ├── LearningRate          (aliases: lr, learning_rate, initial_lr, base_lr)
│   ├── Momentum              (aliases: momentum, sgd_momentum)
│   ├── WeightDecay           (aliases: weight_decay, wd, l2_reg, l2_penalty)
│   ├── WarmupSteps           (aliases: warmup_steps, warmup, num_warmup_steps, warmup_ratio)
│   └── DecayRate             (aliases: decay_rate, lr_decay, lr_decay_rate, decay_factor)
├── HP_Training
│   ├── BatchSize             (aliases: batch_size, train_batch_size, per_device_train_batch_size, micro_batch)
│   ├── NumEpochs             (aliases: num_epochs, epochs, num_train_epochs, max_epochs)
│   ├── MaxSteps              (aliases: max_steps, total_steps, training_steps, max_train_steps)
│   ├──	Patience	      (aliases: patience)
│   ├── GradientAccumulationSteps (aliases: gradient_accumulation_steps, accum_steps, grad_accum)
│   ├── NumWorkers            (aliases: num_workers, dataloader_num_workers, n_workers)
│   └── RandomSeed            (aliases: seed, random_seed, manual_seed)

├── HP_Architecture
│   ├── NumLayers             (aliases: num_layers, n_layers, num_hidden_layers, depth, "N-layer")
│   ├── HiddenSize            (aliases: hidden_size, d_model, hidden_dim, intermediate_size)
│   ├── EmbeddingDim          (aliases: embedding_dim, embed_dim, d_embed, word_embedding_dim)
│   ├── Dropout               (aliases: dropout, dropout_rate, drop_rate, attention_dropout, hidden_dropout)
│   ├── AttentionHeads        (aliases: num_attention_heads, n_heads, num_heads, nhead)
└── HP_Data
    ├── MaxSequenceLength     (aliases: max_seq_length, max_length, max_seq_len, max_position_embeddings)
    └── TrainValTestSplit     (aliases: train_split, val_split, test_split, split_ratio)
```

### Classification Rules

1. **Exact match first**: Match parameter name against leaf aliases (case-insensitive).
2. **Semantic match second**: If no exact alias match, classify by semantic meaning (e.g., "λ" for regularization → WeightDecay).
3. **Fallback**: If a hyperparameter matches no category at all, set `"hpType"` to the best-fit category name (e.g., `"HP_Optimization"`) and add `"uncertain": true`.
4. **Multi-value HPs**: If a single parameter name maps to multiple values (e.g., per-dataset), create one entity per value with dataset context in the `@id` and `mls:name`.

## Hyperparameter Extraction Strategy (High Recall)

To achieve high recall, apply a multi-step, framework-aware scan of `PAPER_MD`:

1. **Paper-Driven Candidates**: Collect any spans resembling hyperparameters — explicit assignments (`learning rate = 1e-3`, `batch size of 32`), implicit mentions (`BERT-base with 12 layers`, `trained for 50 epochs`), table headers (`Hyperparameters`, `Training details`), and inline parentheticals (`(lr = 1e-4)`, `(hidden size 768)`).

2. **Classify Each Candidate**: Assign a leaf type using the alias table and Classification Rules above. Set `"hpType"` accordingly; mark uncertain cases with `"uncertain": true`.

3. **Framework-Aware Matching**: Identify the referenced framework (PyTorch, TensorFlow/Keras, Hugging Face Transformers) and verify candidates against known constructor arguments, optimizer parameters, scheduler parameters, or model config fields.

4. **Architecture Counts**: Recognise written-out numerics as hyperparameters (e.g., `two-layer` → NumLayers, `3 heads` → AttentionHeads, `12-layer` → NumLayers).

If unsure about a hyperparameter, extract it and mark it with `"uncertain": true`.

## Experiment Entity Grouping

When multiple `Experiment` entities are extracted from the paper, apply the following grouping rule before serialising the `@graph`:

### Shared-Hypothesis Collapsing

1. **Detect shared attributes**: After extracting all `Experiment` entities, compare their `mls:hypothesis` values (normalised, whitespace-collapsed). Also check `mls:methodology` and any other top-level attributes that are textually identical across **all** experiments in the set.

2. **Apply grouping if all experiments share the same hypothesis**:
   - If every extracted `Experiment` shares an identical `mls:hypothesis` value, **do not repeat** that value on each child node.
   - Instead, create a **parent `Experiment` group node** that carries the shared attributes at the top level. Assign it an `@id` of the form `exp:group_{study_id}` and set `"@type": "mls:ExperimentGroup"`.
   - Nest the individual experiments as an array under the key `"mls:hasSubExperiment"` on the parent node.
   - Each sub-experiment node retains only the attributes that **differ** across experiments (e.g., `mls:dataset`, `mls:model`, `mls:result`, character offsets, prefix/suffix). Omit any attribute whose value is already declared on the parent.

3. **Shared attributes to hoist**: Always hoist the following fields to the parent when they are identical across all experiments: `mls:hypothesis`, `mls:methodology`, `mls:evaluationMeasure`, `mls:task` (if the same IRI). Hoist any additional attribute that is textually/IRI-identical across all child experiments.

4. **Partial sharing (not all experiments)**: If only a *subset* of experiments shares a hypothesis, do **not** apply group collapsing to the full set. Instead, create a group node only for the sharing subset and leave non-sharing experiments as standalone nodes at the same `@graph` level.

5. **Single experiment**: If only one `Experiment` is found, output it as a regular flat node — no grouping wrapper needed.

6. **Provenance**: The parent group node inherits the provenance relations (`prov:wasGeneratedBy`, `prov:wasDerivedFrom`) from the child experiments when those relations are identical. Child nodes that have unique provenance retain their own provenance fields.

**Example structure (JSON-LD skeleton)**:

```json
{
  "@id": "exp:group_study1",
  "@type": "mls:ExperimentGroup",
  "mls:hypothesis": "Shared hypothesis text extracted from paper",
  "mls:methodology": "Shared methodology description",
  "mls:hasSubExperiment": [
    {
      "@id": "exp:exp1",
      "@type": "mls:Experiment",
      "mls:dataset": { "@id": "dataset:SQuAD" },
      "mls:result": "F1 = 91.2",
      "start_char_doc": 4821,
      "end_char_doc": 4934,
      "prefix": "evaluated on the SQuAD",
      "suffix": "benchmark achieving state-of-the-art"
    },
    {
      "@id": "exp:exp2",
      "@type": "mls:Experiment",
      "mls:dataset": { "@id": "dataset:TriviaQA" },
      "mls:result": "F1 = 87.6",
      "start_char_doc": 5102,
      "end_char_doc": 5198,
      "prefix": "on TriviaQA the model",
      "suffix": "outperforms prior baselines by"
    }
  ]
}
```

## Canonical Entity ID Minting

Every entity in the `@graph` MUST have an `@id` derived deterministically from its type and canonical name using the rules below. IDs must be stable and reproducible: the same real-world entity mentioned in any paper must always yield the same `@id`.

### Namespace Prefix Table

| Entity type            | Prefix        | Example `@id`                     |
|------------------------|---------------|-----------------------------------|
| `MLS_Model`            | `model:`      | `model:roberta_base`              |
| `MLS_Algorithm`        | `algo:`       | `algo:adam`                       |
| `Method`               | `method:`     | `method:masked_language_modeling` |
| `MLS_Dataset`          | `dataset:`    | `dataset:squad_1_1`               |
| `DataSource`           | `datasource:` | `datasource:wikipedia_en`         |
| `MLS_Task`             | `task:`       | `task:extractive_qa`              |
| `MLS_Eval`             | `eval:`       | `eval:f1_score`                   |
| `MLS_HyperParameter`   | `hp:`         | `hp:learning_rate`                |
| `MLS_Implementation`   | `impl:`       | `impl:huggingface_transformers`   |
| `Environment`          | `env:`        | `env:nvidia_a100_pytorch_1_13`    |
| `Prompt`               | `prompt:`     | `prompt:zero_shot_qa`             |
| `Person`               | `person:`     | `person:devlin_jacob`             |
| `Organization`         | `org:`        | `org:google_research`             |
| `Study`                | `study:`      | `study:bert_pretraining_2019`     |
| `Experiment`           | `exp:`        | `exp:roberta_base_squad_1_1`      |
| `mls:ExperimentGroup`  | `expg:`        | `expg:group_extractive_qa_2019`    |
| `SoftwareRepository`  | `repo:`        | `repo:repository_name`    |

### Slug Normalization Algorithm

Apply these steps in order to any entity name before constructing the `@id`:

1. **Use the canonical name**: prefer the official name from the paper's title, abstract, or citation (e.g. `RoBERTa-base`, not `roberta encoder`).
2. **Lowercase**: `RoBERTa-base` → `roberta-base`.
3. **Replace separators**: convert spaces, hyphens, and slashes to underscores → `roberta_base`.
4. **Strip non-alphanumeric characters**: remove parentheses, quotes, dots, colons, and any other punctuation except underscores → `roberta_base`.
5. **Collapse underscores**: replace runs of `__+` with a single `_`, and strip leading/trailing underscores.
6. **Append version if present**: if the entity name includes an explicit version number or size variant, retain it as a suffix separated by `_` (e.g. `bert_large_uncased`, `squad_1_1`, `pytorch_1_13`).
7. **For `Person`**: use `lastname_firstname` order (e.g. `devlin_jacob`). If only one name is available, use it as-is.
8. **For `Experiment`**: concatenate the slugs of the primary model and dataset separated by `_` (e.g. `exp:roberta_base_squad_1_1`). If no model or dataset is applicable, use a descriptive slug from the experiment's task and year.
9. **For `mls:ExperimentGroup`**: use `exp:group_` followed by the task slug and year (e.g. `exp:group_extractive_qa_2019`).
10. **For `Environment`**: concatenate hardware slug and framework slug (e.g. `env:nvidia_a100_pytorch_1_13`).

### Multi-value and Ambiguous Entities

- If two distinct real-world entities normalize to the same slug (e.g. two different datasets both named "Benchmark-X"), disambiguate by appending the publication year or source organization: `dataset:benchmark_x_2022`, `dataset:benchmark_x_acl`.
- For hyperparameters that are model- or dataset-specific, append the scoping context to the slug: `hp:learning_rate_roberta_base_squad`.
- Never include paper-internal identifiers (e.g., "Experiment 1", "Model A") in the slug. Derive the slug from the real-world name.

### `@context` Prefix Declarations

The `@context` block MUST declare all namespaces used. At minimum include:

```json
"@context": {
  "mls":         "http://www.w3.org/ns/mls#",
  "prov":        "http://www.w3.org/ns/prov#",
  "model":       "https://w3id.org/mlskg/model/",
  "algo":        "https://w3id.org/mlskg/algorithm/",
  "method":      "https://w3id.org/mlskg/method/",
  "dataset":     "https://w3id.org/mlskg/dataset/",
  "datasource":  "https://w3id.org/mlskg/datasource/",
  "task":        "https://w3id.org/mlskg/task/",
  "eval":        "https://w3id.org/mlskg/eval/",
  "hp":          "https://w3id.org/mlskg/hp/",
  "impl":        "https://w3id.org/mlskg/implementation/",
  "env":         "https://w3id.org/mlskg/environment/",
  "prompt":      "https://w3id.org/mlskg/prompt/",
  "person":      "https://w3id.org/mlskg/person/",
  "org":         "https://w3id.org/mlskg/organization/",
  "study":       "https://w3id.org/mlskg/study/",
  "exp":         "https://w3id.org/mlskg/experiment/",
  "valueSource": "https://w3id.org/mlskg/meta/valueSource",
  "mention":     "https://w3id.org/mlskg/meta/mention"
}
```

## Attribute-Level Offsets and Value Provenance

Every attribute value on every entity — not just the entity's primary name mention — MUST be wrapped in a **provenance object** that records its character span and whether the value was literally found in the paper or was derived by the model.

### Provenance Wrapper Structure

Replace every bare attribute value with the following object:

```json
"<attribute_key>": {
  "value":          "<the attribute value>",
  "start_char_doc": <integer or null>,
  "end_char_doc":   <integer or null>,
  "prefix":         "<up to 5 words before the value span, or null>",
  "suffix":         "<up to 5 words after the value span, or null>",
  "valueSource":    "extracted" | "inferred"
}
```

### `valueSource` Rules

| `valueSource`  | Meaning | Offset requirement |
|----------------|---------|--------------------|
| `"extracted"`  | The value (or a close paraphrase) appears verbatim in `PAPER_MD`. | `start_char_doc`, `end_char_doc`, `prefix`, `suffix` are **required** (non-null). |
| `"inferred"`   | The value was derived, normalised, or inferred by the model — no direct textual span exists. | `start_char_doc`, `end_char_doc`, `prefix`, `suffix` MUST be `null`. |

Use `"inferred"` for values that are: schema-normalised labels (e.g. task type derived from context), aggregated or computed values (e.g. total parameter count calculated from architecture details), values implied by a citation rather than stated directly, and classification metadata (`hpType`, `hpCategory`).

### Entity-Level Mention Block

Each entity node retains a top-level `"mention"` block that records the character span of the entity's **primary name mention** — independently of its attribute values:

```json
"mention": {
  "start_char_doc": <integer>,
  "end_char_doc":   <integer>,
  "prefix":         "<up to 5 words>",
  "suffix":         "<up to 5 words>",
  "valueSource":    "extracted" | "inferred"
}
```

Set `"valueSource": "inferred"` on the `mention` block only if the entity is implied (e.g. a default framework assumed from context) rather than named in the text.

### Exempted Fields

Do **not** wrap the following in a provenance object — they are structural or classification metadata:

- `@id`, `@type`
- `hpType`, `hpCategory` (always inferred by definition)
- Relational attributes whose value is a bare `{"@id": "..."}` pointer to another entity node.

### Full Example

```json
{
  "@id": "model:roberta_base",
  "@type": "mls:Model",
  "mention": {
    "start_char_doc": 1204,
    "end_char_doc":   1216,
    "prefix":         "we fine-tune",
    "suffix":         "on the SQuAD benchmark",
    "valueSource":    "extracted"
  },
  "mls:name": {
    "value":          "RoBERTa-base",
    "start_char_doc": 1204,
    "end_char_doc":   1216,
    "prefix":         "we fine-tune",
    "suffix":         "on the SQuAD benchmark",
    "valueSource":    "extracted"
  },
  "mls:numParameters": {
    "value":          "125000000",
    "start_char_doc": null,
    "end_char_doc":   null,
    "prefix":         null,
    "suffix":         null,
    "valueSource":    "inferred"
  },
  "mls:hasHyperParameter": { "@id": "hp:learning_rate_roberta_base_squad" }
}
```

## Workflow

1. **Analyze Inputs**: Read the `PAPER_MD` and `SCHEMA_TEXT`.
2. **Map Schema**: Interpret the Mermaid class diagram (see `references/schema_mermaid.md`). Pay special attention to the `MLS_HyperParameter` hierarchy and the `mls:ExperimentGroup` type (see § *Experiment Entity Grouping*).
3. **Extract Entities**: Identify all schema-compliant entities belonging to the core contribution. Consult `references/extraction_policy.md` for definitions and rules.
4. **Mint Canonical IDs**: For every extracted entity, derive its `@id` using the Slug Normalization Algorithm and Namespace Prefix Table (see § *Canonical Entity ID Minting*). Resolve ambiguous slugs before proceeding.
5. **Classify Hyperparameters**: For every extracted hyperparameter, assign a leaf type from the HP hierarchy. Populate `"hpType"` and `"hpCategory"` (one of `HP_Optimization`, `HP_Training`, `HP_Architecture`, `HP_Data`).
6. **Group Experiments**: Apply the **Shared-Hypothesis Collapsing** rules (see § *Experiment Entity Grouping*). Produce a parent group node with hoisted shared attributes and nested sub-experiment nodes before proceeding to offset calculation.
7. **Calculate Offsets**: For every extracted entity, use `scripts/calculate_offsets.py` to determine offsets for (a) the entity's primary name mention (`mention` block) and (b) every individual attribute value that is `"extracted"`. Set offsets to `null` for `"inferred"` values. Do not calculate offsets for exempted fields (`@id`, `@type`, `hpType`, `hpCategory`, relational `@id` pointers).
8. **Capture Context**: For every span with non-null offsets, extract `prefix` and `suffix` (up to 5 words each). Set both to `null` for `"inferred"` values.
9. **Format Output**: Wrap every non-exempt attribute value in the provenance object (`value`, `start_char_doc`, `end_char_doc`, `prefix`, `suffix`, `valueSource`). Structure the `@graph` with the `@context` from the `SCHEMA_TEXT`, including all namespace prefixes from the Prefix Table. Consult `references/output_schema.md` for entity templates.
10. **Final Self-Check**:
    - Output is valid JSON-LD with `@context` and `@graph`.
    - All relevant entities and attributes are present.
    - Every entity `@id` follows the canonical slug format: `{prefix}:{normalized_slug}`. No paper-internal labels, no ad-hoc casing.
    - Every `MLS_HyperParameter` has `"hpCategory"` and `"hpType"` set.
    - Experiment grouping is correct: shared attributes are hoisted to the parent and not repeated on child nodes.
    - Every entity has a `"mention"` block. Every non-exempt attribute value is wrapped in a provenance object with `"valueSource"` set.
    - All `"extracted"` values have non-null offsets and prefix/suffix. All `"inferred"` values have `null` offsets and prefix/suffix.
    - All schema relations and provenance links (`prov:wasGeneratedBy`, `prov:wasDerivedFrom`, `prov:wasAssociatedWith`) are present.
11. **Deliver Result**: Return the JSON object ONLY.

## Usage Guidelines

- **Strict JSON-LD @graph**: Output must be a single JSON object containing the `@context` and `@graph` array.
- **Comprehensive Extraction**: Extract all entities and attributes specified in the provided `SCHEMA_TEXT`.
- **Typed Hyperparameters**: Every `MLS_HyperParameter` MUST include `"hpCategory"` and `"hpType"` fields from the hierarchy.
- **Character Precision**: Every non-exempt attribute value and every entity `mention` block must carry accurate `start_char_doc`/`end_char_doc` offsets when `valueSource` is `"extracted"`, and `null` offsets when `"inferred"`.
- **Value Provenance**: Every non-exempt attribute value MUST include `"valueSource": "extracted" | "inferred"`. Never omit this field or guess offsets for inferred values.
- **No Hallucinations**: Use `null` for missing fields; do not invent data.
- **Schema Adherence**: Strictly follow the entity, attribute, and relation definitions from the `SCHEMA_TEXT`.