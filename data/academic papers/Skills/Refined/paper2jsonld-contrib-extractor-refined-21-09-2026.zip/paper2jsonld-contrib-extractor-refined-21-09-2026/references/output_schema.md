# Output Schema and Skeleton (Comprehensive)

## JSON-LD Context
The output MUST include the following `@context` derived from the Mermaid class diagram:
```json
{
  "@context": {
    "mls": "http://www.w3.org/ns/mls#",
    "schema": "http://schema.org/",
    "xsd": "http://www.w3.org/2001/XMLSchema#",
    "rdfs": "http://www.w3.org/2000/01/rdf-schema#",
    "prov": "http://www.w3.org/ns/prov#",
    "Study": "mls:Study",
    "Experiment": "mls:Experiment",
    "Person": "mls:Person",
    "Organization": "mls:Organization",
    "MLS_Task": "mls:MLS_Task",
    "MLS_Dataset": "mls:MLS_Dataset",
    "DataSource": "mls:DataSource",
    "Method": "Method",
    "MLS_Model": "mls:MLS_Model",
    "MLS_Algorithm": "mls:MLS_Algorithm",
    "Prompt": "Prompt",
    "MLS_Eval": "mls:MLS_Eval",
    "SoftwareRepository": "SoftwareRepository",
    "MLS_Implementation": "mls:MLS_Implementation",
    "MLS_HyperParameter": "msl:MLS_HyperParameter",
    "HP_Optimization": "HP_Optimization",
    "HP_Training": "HP_Training",
    "HP_Architecture": "HP_Architecture",
    "HP_Data": "HP_Data",
    "LearningRate": "LearningRate",
    "Momentum": "Momentum",
    "WeightDecay": "WeightDecay",
    "WarmupSteps": "WarmupSteps",
    "DecayRate": "DecayRate",
    "BatchSize": "BatchSize",
    "NumEpochs": "NumEpochs",
    "MaxSteps": "MaxSteps",
    "GradientAccumulationSteps": "GradientAccumulationSteps",
    "NumWorkers": "NumWorkers",
    "RandomSeed": "RandomSeed",
    "NumLayers": "NumLayers",
    "HiddenSize": "HiddenSize",
    "EmbeddingDim": "EmbeddingDim",
    "Dropout": "Dropout",
    "AttentionHeads": "AttentionHeads",
    "MaxSequenceLength": "MaxSequenceLength",
    "TrainValTestSplit": "TrainValTestSplit",
    "Dependency": "Dependency",
    "Environment": "Environment",
    "DataProcessingStep": "DataProcessingStep",
    "TrainingRun": "TrainingRun",
    "EvaluationRun": "EvaluationRun",
    "PredictionSet": "PredictionSet",
    "issued": { "@id": "xsd:issued", "@type": "xsd:datetime" },
    "title": "schema:title",
    "abstract": "schema:abstract",
    "url": "schema:url",
    "doi": "schema:doi",
    "citation": "schema:citation",
    "publicationVenue": "schema:publicationVenue",
    "timestamp": { "@id": "schema:timestamp", "@type": "xsd:date" },
    "identifier": "schema:identifier",
    "description": "schema:description",
    "objective": "schema:objective",
    "hypothesis": "schema:hypothesis",
    "methodology": "schema:methodology",
    "name": "schema:name",
    "affiliation": "schema:affiliation",
    "email": "schema:email",
    "orcid": "schema:orcid",
    "type": "schema:type",
    "category": "schema:category",
    "metrics": "schema:metrics",
    "numInstances": { "@id": "schema:numInstances", "@type": "xsd:integer" },
    "language": "schema:language",
    "license": "schema:license",
    "modality": "schema:modality",
    "numClasses": { "@id": "schema:numClasses", "@type": "xsd:integer" },
    "version": "schema:version",
    "architecture": "schema:architecture",
    "parameters": "schema:parameters",
    "complexity": "mls:complexity",
    "pseudoCode": { "@id": "mls:pseudoCode", "@type": "xsd:anyURI" },
    "text": "schema:text",
    "role": "mls:role",
    "templateId": "mls:templateId",
    "usesContext": { "@id": "mls:usesContext", "@type": "xsd:boolean" },
    "measure": "mls:measure",
    "hasValue": { "@id": "mls:hasValue", "@type": "xsd:float" },
    "stdDev": { "@id": "mls:stdDev", "@type": "xsd:float" },
    "confidenceInterval": "mls:confidenceInterval",
    "programmingLanguage": "schema:programmingLanguage",
    "dateModified": { "@id": "schema:dateModified", "@type": "xsd:datetime" },
    "documentationUrl": { "@id": "mls:documentationUrl", "@type": "xsd:anyURI" },
    "codeRepository": { "@id": "mls:codeRepository", "@type": "xsd:anyURI" },
    "framework": "mls:framework",
    "dependencies": "mls:dependencies",
    "executionCommand": "mls:executionCommand",
    "entryPoint": "mls:entryPoint",
    "commitHash": "mls:commitHash",
    "branch": "mls:branch",
    "dependenciesHash": "mls:dependenciesHash",
    "packageName": "mls:packageName",
    "isOptional": { "@id": "mls:isOptional", "@type": "xsd:boolean" },
    "hardwareSpecs": "mls:hardwareSpecs",
    "os": "mls:os",
    "pythonVersion": "mls:pythonVersion",
    "requirementsFile": "mls:requirementsFile",
    "isDockerized": { "@id": "mls:isDockerized", "@type": "xsd:boolean" },
    "startedAtTime": { "@id": "prov:startedAtTime", "@type": "xsd:datetime" },
    "endedAtTime": { "@id": "prov:endedAtTime", "@type": "xsd:datetime" },
    "transformationType": "mls:transformationType",
    "codeReference": { "@id": "mls:codeReference", "@type": "xsd:anyURI" },
    "runId": "mls:runId",
    "logFile": { "@id": "mls:logFile", "@type": "xsd:anyURI" },
    "split": "mls:split",
    "onDatasetSplit": "mls:onDatasetSplit",
    "format": "mls:format",
    "artifactsLocation": { "@id": "mls:artifactsLocation", "@type": "xsd:anyURI" },
    "hpCategory": "mls:hpCategory",
    "hpType": "mls:hpType",
    "searchSpace": "mls:searchSpace",
    "uncertain": { "@id": "mls:uncertain", "@type": "xsd:boolean" },

    "hasAuthor": { "@id": "mls:hasAuthor", "@type": "@id" },
    "contains": { "@id": "mls:contains", "@type": "@id" },
    "implements": { "@id": "mls:implements", "@type": "@id" },
    "prov-affiliatedWith": { "@id": "mls:prov-affiliatedWith", "@type": "@id" },
    "realizes": { "@id": "mls:realizes", "@type": "@id" },
    "usesData": { "@id": "mls:usesData", "@type": "@id" },
    "produces": { "@id": "mls:produces", "@type": "@id" },
    "usesParameters": { "@id": "mls:usesParameters", "@type": "@id" },
    "executes": { "@id": "mls:executes", "@type": "@id" },
    "subDatasetOf": { "@id": "mls:subDatasetOf", "@type": "@id" },
    "prov-derivedFrom": { "@id": "mls:prov-derivedFrom", "@type": "@id" },
    "processedThrough": { "@id": "mls:processedThrough", "@type": "@id" },
    "prov-uses": { "@id": "mls:prov-uses", "@type": "@id" },
    "trainedOn": { "@id": "mls:trainedOn", "@type": "@id" },
    "evaluatedOn": { "@id": "mls:evaluatedOn", "@type": "@id" },
    "achieves": { "@id": "mls:achieves", "@type": "@id" },
    "prov-producedBy": { "@id": "mls:prov-producedBy", "@type": "@id" },
    "subMethod": { "@id": "mls:subMethod", "@type": "@id" },
    "evaluates": { "@id": "mls:evaluates", "@type": "@id" },
    "supports": { "@id": "mls:supports", "@type": "@id" },
    "runsIn": { "@id": "mls:runsIn", "@type": "@id" },
    "requires": { "@id": "mls:requires", "@type": "@id" },
    "prov-executedBy": { "@id": "mls:prov-executedBy", "@type": "@id" },
    "prov-generated": { "@id": "mls:prov-generated", "@type": "@id" },
    "benchmarkedOn": { "@id": "mls:benchmarkedOn", "@type": "@id" },
    "subTaskOf": { "@id": "mls:subTaskOf", "@type": "@id" },
    "dependsOn": { "@id": "mls:dependsOn", "@type": "@id" },
    "usedIn": { "@id": "mls:usedIn", "@type": "@id" },
    "trains": { "@id": "mls:trains", "@type": "@id" },
    "producedBy": { "@id": "mls:producedBy", "@type": "@id" },
    "sourceFile": "mls:sourceFile",
    "sourceLine": { "@id": "mls:sourceLine", "@type": "xsd:integer" },
    "dependencyType": "mls:dependencyType",
    "owner": "mls:owner",
    "platform": "mls:platform",
    "entryPointCommand": "mls:entryPointCommand",
    "evaluationScript": "mls:evaluationScript",
    "evaluationSplit": "mls:evaluationSplit",
    "metricsFile": "mls:metricsFile",
    "inputDataset": { "@id": "mls:inputDataset", "@type": "@id" },
    "outputDataset": { "@id": "mls:outputDataset", "@type": "@id" },
    "predictionFormat": "mls:predictionFormat",
    "storageLocation": "mls:storageLocation",
    "modelVersion": "mls:modelVersion",
    "appliedTo": { "@id": "mls:appliedTo", "@type": "@id" },
    "wasGeneratedBy": { "@id": "prov:wasGeneratedBy", "@type": "@id" },
    "wasDerivedFrom": { "@id": "prov:wasDerivedFrom", "@type": "@id" },
    "wasAssociatedWith": { "@id": "prov:wasAssociatedWith", "@type": "@id" },
    "used": { "@id": "prov:used", "@type": "@id" }
  },
  "@graph": []
}
```

## Entity Templates

Below are examples of how entities should be structured. If details are missing, include these with `null` fields.

### Study
```json
{
  "@id": "study_id",
  "@type": "Study",
  "schema:title": "Paper Title",
  "schema:abstract": "Abstract content...",
  "schema:url": "https://arxiv.org/abs/xxxx.xxxxx",
  "schema:doi": null,
  "schema:citation": null,
  "schema:publicationVenue": null,
  "schema:timestamp": null,
  "hasAuthor": [ { "@id": "person_id" } ],
  "contains": [ { "@id": "experiment_id" } ],
  "implements": { "@id": "software_repo_id" },
  "start_char_doc": 0,
  "end_char_doc": 0,
  "wasDerivedFrom": "paper",
  "context": { "prefix": "", "suffix": "" }
}
```

### Experiment
```json
{
  "@id": "experiment_id",
  "@type": "Experiment",
  "schema:identifier": "Experiment Name",
  "schema:description": "Description of the experiment",
  "schema:objective": null,
  "schema:hypothesis": null,
  "schema:methodology": null,
  "realizes": [ { "@id": "mls_task_id" } ],
  "usesData": [ { "@id": "mls_dataset_id" } ],
  "produces": [ { "@id": "method_id" } ],
  "usesParameters": [ { "@id": "hp_learning_rate" }, { "@id": "hp_batch_size" } ],
  "executes": [ { "@id": "mls_implementation_id" } ],
  "start_char_doc": 0,
  "end_char_doc": 0,
  "wasDerivedFrom": "paper",
  "context": { "prefix": "", "suffix": "" }
}
```

### Person
```json
{
  "@id": "person_id",
  "@type": "Person",
  "schema:name": "Person Name",
  "schema:affiliation": null,
  "schema:email": null,
  "schema:orcid": null,
  "prov-affiliatedWith": [ { "@id": "organization_id" } ],
  "start_char_doc": 0,
  "end_char_doc": 0,
  "wasDerivedFrom": "paper",
  "context": { "prefix": "", "suffix": "" }
}
```

### Organization
```json
{
  "@id": "organization_id",
  "@type": "Organization",
  "schema:name": "Organization Name",
  "schema:url": null,
  "schema:type": null,
  "start_char_doc": 0,
  "end_char_doc": 0,
  "wasDerivedFrom": "paper",
  "context": { "prefix": "", "suffix": "" }
}
```

### MLS_Task
```json
{
  "@id": "mls_task_id",
  "@type": "MLS_Task",
  "schema:name": "Task Name",
  "schema:description": "Description of the task",
  "schema:category": null,
  "schema:metrics": null,
  "benchmarkedOn": [ { "@id": "mls_dataset_id" } ],
  "subTaskOf": [ { "@id": "parent_mls_task_id" } ],
  "start_char_doc": 0,
  "end_char_doc": 0,
  "wasDerivedFrom": "paper",
  "context": { "prefix": "", "suffix": "" }
}
```

### MLS_Dataset
```json
{
  "@id": "mls_dataset_id",
  "@type": "MLS_Dataset",
  "schema:name": "Dataset Name",
  "schema:description": null,
  "schema:numInstances": null,
  "schema:language": null,
  "schema:license": null,
  "schema:modality": null,
  "schema:numClasses": null,
  "subDatasetOf": [ { "@id": "parent_mls_dataset_id" } ],
  "prov-derivedFrom": [ { "@id": "data_source_id" } ],
  "processedThrough": [ { "@id": "data_processing_step_id" } ],
  "start_char_doc": 0,
  "end_char_doc": 0,
  "wasDerivedFrom": "paper",
  "context": { "prefix": "", "suffix": "" }
}
```

### DataSource
```json
{
  "@id": "data_source_id",
  "@type": "DataSource",
  "schema:name": "Data Source Name",
  "schema:url": null,
  "schema:type": null,
  "schema:license": null,
  "start_char_doc": 0,
  "end_char_doc": 0,
  "wasDerivedFrom": "paper",
  "context": { "prefix": "", "suffix": "" }
}
```

### Method
```json
{
  "@id": "method_id",
  "@type": "Method",
  "schema:name": "Method Name",
  "schema:description": null,
  "schema:version": null,
  "trainedOn": [ { "@id": "mls_dataset_id" } ],
  "evaluatedOn": [ { "@id": "mls_dataset_id" } ],
  "achieves": [ { "@id": "mls_eval_id" } ],
  "prov-producedBy": { "@id": "training_run_id" },
  "subMethod": [ { "@id": "sub_method_id" } ],
  "start_char_doc": 0,
  "end_char_doc": 0,
  "wasDerivedFrom": "paper",
  "context": { "prefix": "", "suffix": "" }
}
```

### MLS_Model (inherits from Method)
```json
{
  "@id": "mls_model_id",
  "@type": ["MLS_Model", "Method"],
  "schema:name": "Model Name",
  "schema:description": null,
  "schema:version": null,
  "schema:architecture": null,
  "schema:parameters": null,
  "trainedOn": [ { "@id": "mls_dataset_id" } ],
  "evaluatedOn": [ { "@id": "mls_dataset_id" } ],
  "achieves": [ { "@id": "mls_eval_id" } ],
  "prov-producedBy": { "@id": "training_run_id" },
  "subMethod": [],
  "start_char_doc": 0,
  "end_char_doc": 0,
  "wasDerivedFrom": "paper",
  "context": { "prefix": "", "suffix": "" }
}
```

### MLS_Algorithm (inherits from Method)
```json
{
  "@id": "mls_algorithm_id",
  "@type": ["MLS_Algorithm", "Method"],
  "schema:name": "Algorithm Name",
  "schema:description": null,
  "schema:version": null,
  "mls:complexity": null,
  "mls:pseudoCode": null,
  "trainedOn": [],
  "evaluatedOn": [],
  "achieves": [],
  "prov-producedBy": null,
  "subMethod": [],
  "start_char_doc": 0,
  "end_char_doc": 0,
  "wasDerivedFrom": "paper",
  "context": { "prefix": "", "suffix": "" }
}
```

### Prompt (inherits from Method)
```json
{
  "@id": "prompt_id",
  "@type": ["Prompt", "Method"],
  "schema:name": "Prompt Name",
  "schema:description": null,
  "schema:version": null,
  "schema:text": "Prompt text content",
  "mls:role": null,
  "mls:templateId": null,
  "mls:usesContext": null,
  "trainedOn": [],
  "evaluatedOn": [],
  "achieves": [],
  "prov-producedBy": null,
  "subMethod": [],
  "start_char_doc": 0,
  "end_char_doc": 0,
  "wasDerivedFrom": "paper",
  "context": { "prefix": "", "suffix": "" }
}
```

### MLS_Eval
```json
{
  "@id": "mls_eval_id",
  "@type": "MLS_Eval",
  "mls:measure": "Metric Name",
  "mls:hasValue": null,
  "mls:stdDev": null,
  "mls:confidenceInterval": null,
  "mls:onDataset": { "@id": "mls_dataset_id" },
  "prov-producedBy": { "@id": "evaluation_run_id" },
  "start_char_doc": 0,
  "end_char_doc": 0,
  "wasDerivedFrom": "paper",
  "context": { "prefix": "", "suffix": "" }
}
```

### SoftwareRepository
```json
{
  "@id": "software_repo_id",
  "@type": "SoftwareRepository",
  "schema:name": "Repository Name",
  "schema:url": "https://github.com/user/repo",
  "schema:version": null,
  "schema:programmingLanguage": null,
  "schema:dateModified": null,
  "schema:license": null,
  "mls:documentationUrl": null,
  "contains": [ { "@id": "mls_implementation_id" } ],
  "supports": [ { "@id": "environment_id" } ],
  "start_char_doc": 0,
  "end_char_doc": 0,
  "wasDerivedFrom": "paper",
  "context": { "prefix": "", "suffix": "" }
}
```

### MLS_Implementation
```json
{
  "@id": "mls_implementation_id",
  "@type": "MLS_Implementation",
  "schema:identifier": "Implementation Identifier",
  "mls:codeRepository": "https://github.com/user/repo",
  "mls:framework": null,
  "mls:dependencies": null,
  "mls:executionCommand": null,
  "mls:entryPoint": null,
  "mls:commitHash": null,
  "mls:branch": null,
  "mls:dependenciesHash": null,
  "runsIn": { "@id": "environment_id" },
  "requires": [ { "@id": "dependency_id" } ],
  "start_char_doc": 0,
  "end_char_doc": 0,
  "wasDerivedFrom": "paper",
  "context": { "prefix": "", "suffix": "" }
}
```

### MLS_HyperParameter (Typed with HP Hierarchy)
```json
{
  "@id": "hp_learning_rate",
  "@type": "MLS_HyperParameter",
  "mls:name": "http://example.org/hp/learning_rate",
  "mls:hasValue": "5e-5",
  "mls:wasDerivedFrom": "paper",
  "mls:type": "float",
  "mls:searchSpace": null,
  "hpCategory": "HP_Optimization",
  "hpType": "LearningRate",
  "uncertain": false,
  "start_char_doc": 1234,
  "end_char_doc": 1238,
  "wasDerivedFrom": "paper",
  "context": { "prefix": "We set the", "suffix": "for the encoder" }
}
```

**HP Hierarchy Quick Reference**:

| hpCategory | hpType (Leaf) | Example mls:name | Example mls:hasValue |
|------------|---------------|-------------------|----------------------|
| HP_Optimization | LearningRate | http://example.org/hp/learning_rate | "5e-5" |
| HP_Optimization | Momentum | http://example.org/hp/momentum | "0.9" |
| HP_Optimization | WeightDecay | http://example.org/hp/weight_decay | "0.01" |
| HP_Optimization | WarmupSteps | http://example.org/hp/warmup_steps | "1000" |
| HP_Optimization | DecayRate | http://example.org/hp/decay_rate | "0.1" |
| HP_Training | BatchSize | http://example.org/hp/batch_size | "32" |
| HP_Training | NumEpochs | http://example.org/hp/num_epochs | "50" |
| HP_Training | MaxSteps | http://example.org/hp/max_steps | "100000" |
| HP_Training | GradientAccumulationSteps | http://example.org/hp/gradient_accumulation_steps | "4" |
| HP_Training | NumWorkers | http://example.org/hp/num_workers | "8" |
| HP_Training | RandomSeed | http://example.org/hp/random_seed | "42" |
| HP_Architecture | NumLayers | http://example.org/hp/num_layers | "12" |
| HP_Architecture | HiddenSize | http://example.org/hp/hidden_size | "768" |
| HP_Architecture | EmbeddingDim | http://example.org/hp/embedding_dim | "300" |
| HP_Architecture | Dropout | http://example.org/hp/dropout | "0.1" |
| HP_Architecture | AttentionHeads | http://example.org/hp/num_attention_heads | "12" |
| HP_Architecture | UnknownArchitectureHP | http://example.org/hp/custom_arch_param | "value" |
| HP_Data | MaxSequenceLength | http://example.org/hp/max_seq_length | "512" |
| HP_Data | TrainValTestSplit | http://example.org/hp/train_split | "0.8" |

### Dependency
```json
{
  "@id": "dependency_id",
  "@type": "Dependency",
  "mls:packageName": "Package Name",
  "mls:version": null,
  "mls:type": null,
  "mls:isOptional": null,
  "start_char_doc": 0,
  "end_char_doc": 0,
  "wasDerivedFrom": "paper",
  "context": { "prefix": "", "suffix": "" }
}
```

### Environment
```json
{
  "@id": "environment_id",
  "@type": "Environment",
  "schema:name": "Environment Name",
  "schema:description": null,
  "mls:hardwareSpecs": null,
  "mls:os": null,
  "mls:pythonVersion": null,
  "mls:requirementsFile": null,
  "mls:isDockerized": null,
  "start_char_doc": 0,
  "end_char_doc": 0,
  "wasDerivedFrom": "paper",
  "context": { "prefix": "", "suffix": "" }
}
```

### DataProcessingStep
```json
{
  "@id": "step_unique_identifier",
  "@type": "DataProcessingStep",
  "description": "Human-readable description of the processing step",
  "codeReference": "script_file.py",
  "wasDerivedFrom": "code",
  "startedAtTime": null,
  "endedAtTime": null,
  "transformationType": "preprocessing_type",
  "parameters": null,
  "prov-uses": { "@id": "data_source_id" }
}
```

### TrainingRun
```json
{
  "@id": "training_run_id",
  "@type": "TrainingRun",
  "mls:runId": "Run ID",
  "schema:description": null,
  "prov:startedAtTime": null,
  "prov:endedAtTime": null,
  "mls:codeReference": null,
  "mls:logFile": null,
  "mls:artifactsLocation": null,
  "prov-executedBy": { "@id": "mls_implementation_id" },
  "prov-uses": { "@id": "mls_dataset_id" },
  "start_char_doc": 0,
  "end_char_doc": 0,
  "wasDerivedFrom": "paper",
  "context": { "prefix": "", "suffix": "" }
}
```

### EvaluationRun
```json
{
  "@id": "evaluation_run_id",
  "@type": "EvaluationRun",
  "mls:runId": "Run ID",
  "schema:description": null,
  "prov:startedAtTime": null,
  "prov:endedAtTime": null,
  "mls:split": null,
  "mls:codeReference": null,
  "mls:metricsFile": null,
  "prov-executedBy": { "@id": "mls_implementation_id" },
  "prov-generated": [ { "@id": "prediction_set_id" } ],
  "evaluates": { "@id": "method_id" },
  "start_char_doc": 0,
  "end_char_doc": 0,
  "wasDerivedFrom": "paper",
  "context": { "prefix": "", "suffix": "" }
}
```

### PredictionSet
```json
{
  "@id": "prediction_set_id",
  "@type": "PredictionSet",
  "schema:id": "Prediction Set ID",
  "mls:numInstances": null,
  "mls:onDatasetSplit": null,
  "mls:format": null,
  "mls:artifactsLocation": null,
  "start_char_doc": 0,
  "end_char_doc": 0,
  "wasDerivedFrom": "paper",
  "context": { "prefix": "", "suffix": "" }
}
```
