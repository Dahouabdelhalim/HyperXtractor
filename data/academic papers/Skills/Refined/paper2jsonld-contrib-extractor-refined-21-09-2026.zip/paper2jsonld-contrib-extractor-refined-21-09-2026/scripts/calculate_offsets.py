import re
import json
import sys

def calculate_offsets(file_path, search_patterns):
    """
    Calculates character offsets and context for a list of search patterns in a file.
    
    Args:
        file_path (str): Path to the markdown file.
        search_patterns (list): List of strings or regex patterns to find.
        
    Returns:
        list: A list of dictionaries containing start, end, and context for each match.
    """
    try:
        with open(file_path, 'r', encoding='utf-8') as f:
            content = f.read()
    except Exception as e:
        return {"error": f"Could not read file: {str(e)}"}

    results = []
    for pattern in search_patterns:
        # Escape pattern if it's a literal string, or use as is if it's intended as regex
        # Here we assume literal strings for safety
        match = re.search(re.escape(pattern), content)
        if match:
            start, end = match.span()
            
            # Get context (up to 5 words before and after)
            prefix_text = content[:start].strip().split()
            suffix_text = content[end:].strip().split()
            
            prefix = " ".join(prefix_text[-5:]) if prefix_text else ""
            suffix = " ".join(suffix_text[:5]) if suffix_text else ""
            
            results.append({
                "pattern": pattern,
                "start_char_doc": start,
                "end_char_doc": end,
                "context": {
                    "prefix": prefix,
                    "suffix": suffix
                }
            })
        else:
            results.append({
                "pattern": pattern,
                "error": "Pattern not found"
            })
            
    return results

if __name__ == "__main__":
    if len(sys.argv) < 3:
        print("Usage: python3 calculate_offsets.py <file_path> <pattern1> [pattern2 ...]")
        sys.exit(1)
        
    file_path = sys.argv[1]
    patterns = sys.argv[2:]
    
    output = calculate_offsets(file_path, patterns)
    print(json.dumps(output, indent=2))
