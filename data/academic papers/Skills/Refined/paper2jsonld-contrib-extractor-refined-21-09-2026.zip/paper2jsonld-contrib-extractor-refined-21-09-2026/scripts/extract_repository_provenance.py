"""
Repository Provenance and Implementation Details Extractor

Extracts implementation-level provenance, configuration, dependencies, and execution
details from a software repository provided via URL or local path.

Supports:
- Repository metadata extraction
- Hyperparameter discovery from config files and scripts (with separate entries per mention)
- Typed HP classification into hierarchy: HP_Optimization, HP_Training, HP_Architecture, HP_Data
- Dependency extraction from multiple formats
- Execution provenance tracking
- Prediction artifacts detection
"""

import json
import re
import os
from pathlib import Path
from typing import Dict, List, Any, Optional, Tuple
from dataclasses import dataclass, field, asdict
from datetime import datetime
import subprocess
import yaml


# ── HP Hierarchy Definition ──────────────────────────────────────────────────

HP_HIERARCHY: Dict[str, Dict[str, List[str]]] = {
    "HP_Optimization": {
        "LearningRate": [
            "lr", "learning_rate", "initial_lr", "base_lr", "peak_lr", "lr_init",
        ],
        "Momentum": [
            "momentum", "sgd_momentum", "beta1", "beta2", "betas",
        ],
        "WeightDecay": [
            "weight_decay", "wd", "l2_reg", "l2_penalty", "lambda",
        ],
        "WarmupSteps": [
            "warmup_steps", "warmup", "num_warmup_steps", "warmup_ratio",
            "warmup_epochs", "warmup_proportion",
        ],
        "DecayRate": [
            "decay_rate", "lr_decay", "lr_decay_rate", "decay_factor",
            "lr_scheduler_decay", "step_decay",
        ],
    },
    "HP_Training": {
        "BatchSize": [
            "batch_size", "train_batch_size", "per_device_train_batch_size",
            "micro_batch", "eval_batch_size",
        ],
        "NumEpochs": [
            "num_epochs", "epochs", "num_train_epochs", "max_epochs",
            "n_epochs", "training_epochs",
        ],
        "MaxSteps": [
            "max_steps", "total_steps", "training_steps", "max_train_steps",
            "total_training_steps",
        ],
        "GradientAccumulationSteps": [
            "gradient_accumulation_steps", "accum_steps", "grad_accum",
            "accumulation_steps",
        ],
        "NumWorkers": [
            "num_workers", "dataloader_num_workers", "n_workers", "workers",
        ],
        "RandomSeed": [
            "seed", "random_seed", "manual_seed", "torch_seed", "np_seed",
        ],
    },
    "HP_Architecture": {
        "NumLayers": [
            "num_layers", "n_layers", "num_hidden_layers", "depth",
            "encoder_layers", "decoder_layers",
        ],
        "HiddenSize": [
            "hidden_size", "d_model", "hidden_dim", "intermediate_size",
            "d_ff", "ffn_dim",
        ],
        "EmbeddingDim": [
            "embedding_dim", "embed_dim", "d_embed", "word_embedding_dim",
            "token_embedding_dim",
        ],
        "Dropout": [
            "dropout", "dropout_rate", "drop_rate", "attention_dropout",
            "hidden_dropout", "classifier_dropout",
        ],
        "AttentionHeads": [
            "num_attention_heads", "n_heads", "num_heads", "nhead",
            "attention_heads",
        ],
        "UnknownArchitectureHP": [],  # fallback
    },
    "HP_Data": {
        "MaxSequenceLength": [
            "max_seq_length", "max_length", "max_seq_len",
            "max_position_embeddings", "max_tokens", "seq_len",
        ],
        "TrainValTestSplit": [
            "train_split", "val_split", "test_split", "split_ratio",
            "train_size", "val_size", "test_size",
        ],
    },
}

# Build a flat alias → (category, leaf) lookup for O(1) classification
_ALIAS_LOOKUP: Dict[str, Tuple[str, str]] = {}
for _cat, _leaves in HP_HIERARCHY.items():
    for _leaf, _aliases in _leaves.items():
        for _alias in _aliases:
            _ALIAS_LOOKUP[_alias.lower()] = (_cat, _leaf)


def classify_hyperparameter(name: str) -> Tuple[str, str, bool]:
    """
    Classify a hyperparameter name into (hpCategory, hpType, uncertain).

    Returns:
        Tuple of (category, leaf_type, uncertain_flag).
    """
    name_lower = name.lower().strip()

    # 1. Exact alias match
    if name_lower in _ALIAS_LOOKUP:
        cat, leaf = _ALIAS_LOOKUP[name_lower]
        return cat, leaf, False

    # 2. Substring / partial match against aliases
    for alias, (cat, leaf) in _ALIAS_LOOKUP.items():
        if alias in name_lower or name_lower in alias:
            return cat, leaf, False

    # 3. Keyword-based heuristic for category detection
    arch_keywords = [
        "layer", "hidden", "embed", "dim", "head", "channel", "kernel",
        "stride", "padding", "pool", "activation", "norm",
    ]
    opt_keywords = [
        "lr", "learning", "momentum", "decay", "warmup", "schedule",
        "optimizer", "beta", "epsilon", "eps",
    ]
    train_keywords = [
        "batch", "epoch", "step", "accumul", "worker", "seed", "grad_clip",
        "clip", "fp16", "mixed_precision",
    ]
    data_keywords = [
        "max_len", "seq_len", "split", "truncat", "pad", "vocab",
    ]

    if any(kw in name_lower for kw in arch_keywords):
        return "HP_Architecture", "UnknownArchitectureHP", True
    if any(kw in name_lower for kw in opt_keywords):
        return "HP_Optimization", "HP_Optimization", True
    if any(kw in name_lower for kw in train_keywords):
        return "HP_Training", "HP_Training", True
    if any(kw in name_lower for kw in data_keywords):
        return "HP_Data", "HP_Data", True

    # 4. Fallback: cannot classify
    return "HP_Training", "HP_Training", True


# ── Data Classes ─────────────────────────────────────────────────────────────

@dataclass
class RepositoryMetadata:
    """Repository-level metadata"""
    name: str
    url: str
    platform: str  # github, gitlab, bitbucket
    owner: str
    version: Optional[str] = None
    license: Optional[str] = None
    last_modified: Optional[str] = None
    programming_language: str = "Python"
    description: Optional[str] = None


@dataclass
class HyperParameterMention:
    """Individual hyperparameter mention in repository (separate entity per mention)"""
    id: str
    name: str
    value: str
    code_references: List[str]
    start_char_repo: int
    end_char_repo: int
    context_prefix: str
    context_suffix: str
    hp_category: str = ""       # HP_Optimization | HP_Training | HP_Architecture | HP_Data
    hp_type: str = ""           # Leaf class name (e.g. LearningRate, BatchSize)
    uncertain: bool = False
    derived_from: str = "code"


@dataclass
class Dependency:
    """Software dependency extracted from repository"""
    name: str
    version: Optional[str] = None
    dependency_type: str = "runtime"
    source_file: str = ""


@dataclass
class TrainingRunMetadata:
    """Training execution provenance"""
    run_id: Optional[str] = None
    description: Optional[str] = None
    script_reference: Optional[str] = None
    log_file: Optional[str] = None
    artifacts_location: Optional[str] = None
    code_reference: Optional[str] = None
    executed_by: Optional[str] = None
    used: Optional[List[str]] = None


@dataclass
class EvaluationRunMetadata:
    """Evaluation execution provenance"""
    run_id: Optional[str] = None
    description: Optional[str] = None
    code_reference: Optional[str] = None
    started_at_time: Optional[str] = None
    ended_at_time: Optional[str] = None
    split: Optional[str] = None
    metrics_file: Optional[str] = None
    evaluates: Optional[str] = None


@dataclass
class DataProcessingStep:
    """Data preprocessing/transformation step"""
    id: str
    description: Optional[str] = None
    code_reference: Optional[str] = None
    started_at_time: Optional[str] = None
    ended_at_time: Optional[str] = None
    transformation_type: Optional[str] = None
    parameters: Optional[Dict[str, Any]] = None


@dataclass
class PredictionArtifact:
    """Prediction output artifacts"""
    name: str
    format: str
    storage_path: str
    dataset_split: Optional[str] = None
    model_version: Optional[str] = None
    timestamp: Optional[str] = None


# ── Main Extractor ───────────────────────────────────────────────────────────

class RepositoryProvenanceExtractor:
    """Main extractor for repository-level provenance information"""

    def __init__(self, repo_url: str):
        self.repo_url = repo_url
        self.repo_path = self._resolve_repo_path(repo_url)
        self.hyperparameters: List[HyperParameterMention] = []
        self.dependencies: List[Dependency] = []
        self.training_runs: List[TrainingRunMetadata] = []
        self.evaluation_runs: List[EvaluationRunMetadata] = []
        self.data_processing_steps: List[DataProcessingStep] = []
        self.prediction_artifacts: List[PredictionArtifact] = []

    def _resolve_repo_path(self, repo_url: str) -> Path:
        if os.path.exists(repo_url):
            return Path(repo_url)
        raise ValueError(f"Repository path not found: {repo_url}")

    # ── Hyperparameter Extraction ────────────────────────────────────────

    def extract_hyperparameters(self) -> List[HyperParameterMention]:
        """Extract and classify hyperparameters from repository files."""
        config_files = self._find_config_files()
        hp_mentions: List[HyperParameterMention] = []
        hp_counter: Dict[str, int] = {}

        for config_file in config_files:
            try:
                content = config_file.read_text()
                if config_file.suffix in ['.yaml', '.yml', '.json']:
                    hp_mentions.extend(
                        self._extract_from_structured_file(config_file, content, hp_counter)
                    )
                else:
                    hp_mentions.extend(
                        self._extract_from_python_file(config_file, content, hp_counter)
                    )
            except Exception as e:
                print(f"Warning: Could not parse {config_file}: {e}")

        self.hyperparameters = hp_mentions
        return hp_mentions

    def _find_config_files(self) -> List[Path]:
        config_patterns = [
            '*config*.yaml', '*config*.yml', '*config*.json',
            'hyperparameters*.yaml', 'hyperparameters*.json',
            'settings*.py', 'train*.py', 'model*.py',
        ]
        config_files = []
        for pattern in config_patterns:
            config_files.extend(self.repo_path.glob(f'**/{pattern}'))
        return list(set(config_files))

    def _extract_from_structured_file(
        self, file_path: Path, content: str, hp_counter: Dict
    ) -> List[HyperParameterMention]:
        mentions = []
        try:
            if file_path.suffix in ['.yaml', '.yml']:
                data = yaml.safe_load(content)
            else:
                data = json.loads(content)

            flat_params = self._flatten_dict(data)

            for param_name, param_value in flat_params.items():
                pattern = rf'{re.escape(param_name)}\s*:\s*{re.escape(str(param_value))}'
                match = re.search(pattern, content)

                if match:
                    start_pos = match.start()
                    end_pos = match.end()
                    prefix_start = max(0, start_pos - 50)
                    suffix_end = min(len(content), end_pos + 50)
                    prefix = content[prefix_start:start_pos].strip()
                    suffix = content[end_pos:suffix_end].strip()

                    hp_id = self._generate_hp_id(param_name, param_value, hp_counter)

                    # Classify into HP hierarchy
                    leaf_name = param_name.split('.')[-1]  # use last segment for nested keys
                    hp_cat, hp_type, uncertain = classify_hyperparameter(leaf_name)

                    mention = HyperParameterMention(
                        id=hp_id,
                        name=param_name,
                        value=str(param_value),
                        code_references=[file_path.name],
                        start_char_repo=start_pos,
                        end_char_repo=end_pos,
                        context_prefix=prefix[-30:] if prefix else "",
                        context_suffix=suffix[:30] if suffix else "",
                        hp_category=hp_cat,
                        hp_type=hp_type,
                        uncertain=uncertain,
                    )
                    mentions.append(mention)

        except Exception as e:
            print(f"Warning: Could not parse structured file {file_path}: {e}")

        return mentions

    def _extract_from_python_file(
        self, file_path: Path, content: str, hp_counter: Dict
    ) -> List[HyperParameterMention]:
        mentions = []
        pattern = r'(\w+)\s*=\s*(["\']?)([^"\'\n]+)\2'

        for match in re.finditer(pattern, content):
            param_name = match.group(1)
            param_value = match.group(3)

            if self._is_likely_hyperparameter(param_name, param_value):
                hp_id = self._generate_hp_id(param_name, param_value, hp_counter)

                # Classify into HP hierarchy
                hp_cat, hp_type, uncertain = classify_hyperparameter(param_name)

                prefix_start = max(0, match.start() - 30)
                suffix_end = min(len(content), match.end() + 30)
                prefix = content[prefix_start:match.start()].strip()
                suffix = content[match.end():suffix_end].strip()

                mention = HyperParameterMention(
                    id=hp_id,
                    name=param_name,
                    value=param_value,
                    code_references=[file_path.name],
                    start_char_repo=match.start(3),
                    end_char_repo=match.end(3),
                    context_prefix=prefix[-30:] if prefix else "",
                    context_suffix=suffix[:30] if suffix else "",
                    hp_category=hp_cat,
                    hp_type=hp_type,
                    uncertain=uncertain,
                )
                mentions.append(mention)

        return mentions

    def _flatten_dict(self, d: Dict, parent_key: str = '') -> Dict:
        items = []
        for k, v in d.items():
            new_key = f"{parent_key}.{k}" if parent_key else k
            if isinstance(v, dict):
                items.extend(self._flatten_dict(v, new_key).items())
            else:
                items.append((new_key, v))
        return dict(items)

    def _is_likely_hyperparameter(self, name: str, value: str) -> bool:
        """Check if a variable assignment is likely a hyperparameter."""
        # First check against the HP hierarchy aliases
        hp_cat, hp_type, uncertain = classify_hyperparameter(name)
        if not uncertain:
            return True

        # Fallback keyword check
        hp_keywords = [
            'lr', 'learning', 'rate', 'batch', 'size', 'epoch', 'dropout',
            'hidden', 'layer', 'head', 'embedding', 'seed', 'weight', 'decay',
            'momentum', 'beta', 'gamma', 'alpha', 'temperature', 'patience',
            'warmup', 'max_length', 'num_', 'n_', 'dim', 'channels',
            'gradient', 'accumulation', 'steps', 'workers',
        ]
        name_lower = name.lower()
        return any(keyword in name_lower for keyword in hp_keywords)

    def _generate_hp_id(self, param_name: str, param_value: Any, counter: Dict) -> str:
        base_id = f"hp_{param_name.lower().replace('.', '_')}"
        if base_id in counter:
            counter[base_id] += 1
            return f"{base_id}_{counter[base_id]}"
        else:
            counter[base_id] = 0
            return base_id

    # ── Dependency Extraction ────────────────────────────────────────────

    def extract_dependencies(self) -> List[Dependency]:
        dependencies = []
        req_file = self.repo_path / 'requirements.txt'
        if req_file.exists():
            dependencies.extend(self._parse_requirements_file(req_file))
        env_file = self.repo_path / 'environment.yml'
        if env_file.exists():
            dependencies.extend(self._parse_environment_file(env_file))
        pyproject_file = self.repo_path / 'pyproject.toml'
        if pyproject_file.exists():
            dependencies.extend(self._parse_pyproject_file(pyproject_file))
        self.dependencies = dependencies
        return dependencies

    def _parse_requirements_file(self, file_path: Path) -> List[Dependency]:
        deps = []
        try:
            for line in file_path.read_text().splitlines():
                line = line.strip()
                if line and not line.startswith('#'):
                    match = re.match(r'([a-zA-Z0-9\-_]+)\s*([><=!]+)?\s*([0-9.]+)?', line)
                    if match:
                        deps.append(Dependency(
                            name=match.group(1),
                            version=match.group(3),
                            dependency_type='runtime',
                            source_file='requirements.txt',
                        ))
        except Exception as e:
            print(f"Warning: Could not parse requirements.txt: {e}")
        return deps

    def _parse_environment_file(self, file_path: Path) -> List[Dependency]:
        deps = []
        try:
            data = yaml.safe_load(file_path.read_text())
            if 'dependencies' in data:
                for dep in data['dependencies']:
                    if isinstance(dep, str):
                        match = re.match(r'([a-zA-Z0-9\-_]+)\s*([><=!]+)?\s*([0-9.]+)?', dep)
                        if match:
                            deps.append(Dependency(
                                name=match.group(1),
                                version=match.group(3),
                                dependency_type='runtime',
                                source_file='environment.yml',
                            ))
        except Exception as e:
            print(f"Warning: Could not parse environment.yml: {e}")
        return deps

    def _parse_pyproject_file(self, file_path: Path) -> List[Dependency]:
        deps = []
        try:
            content = file_path.read_text()
            match = re.search(r'\[project\]\s*dependencies\s*=\s*\[(.*?)\]', content, re.DOTALL)
            if match:
                deps_str = match.group(1)
                for dep_line in deps_str.split(','):
                    dep_line = dep_line.strip().strip('"').strip("'")
                    if dep_line:
                        match = re.match(r'([a-zA-Z0-9\-_]+)\s*([><=!]+)?\s*([0-9.]+)?', dep_line)
                        if match:
                            deps.append(Dependency(
                                name=match.group(1),
                                version=match.group(3),
                                dependency_type='runtime',
                                source_file='pyproject.toml',
                            ))
        except Exception as e:
            print(f"Warning: Could not parse pyproject.toml: {e}")
        return deps

    # ── JSON-LD Output ───────────────────────────────────────────────────

    def to_jsonld(self) -> Dict:
        """Convert extracted provenance to JSON-LD format with typed HP hierarchy."""
        graph = []

        # Add hyperparameter entities (each mention as separate entity, typed)
        for hp in self.hyperparameters:
            graph.append({
                "@id": hp.id,
                "@type": "MLS_HyperParameter",
                "mls:name": hp.name,
                "mls:hasValue": hp.value,
                "hpCategory": hp.hp_category,
                "hpType": hp.hp_type,
                "uncertain": hp.uncertain,
                "codeReference": hp.code_references,
                "start_char_repo": hp.start_char_repo,
                "end_char_repo": hp.end_char_repo,
                "wasDerivedFrom": hp.derived_from,
                "context": {
                    "prefix": hp.context_prefix,
                    "suffix": hp.context_suffix,
                },
            })

        # Add dependency entities
        for dep in self.dependencies:
            graph.append({
                "@id": f"dep_{dep.name.lower()}",
                "@type": "Dependency",
                "mls:packageName": dep.name,
                "mls:version": dep.version,
                "mls:dependencyType": dep.dependency_type,
                "mls:sourceFile": dep.source_file,
                "wasDerivedFrom": "code",
            })

        return {
            "@context": {
                "mls": "http://example.org/ontology/mls#",
                "schema": "http://schema.org/",
                "prov": "http://www.w3.org/ns/prov#",
            },
            "@graph": graph,
        }


if __name__ == "__main__":
    import sys
    if len(sys.argv) > 1:
        repo_path = sys.argv[1]
        extractor = RepositoryProvenanceExtractor(repo_path)

        hyperparameters = extractor.extract_hyperparameters()
        dependencies = extractor.extract_dependencies()

        result = extractor.to_jsonld()
        print(json.dumps(result, indent=2))
    else:
        print("Usage: python extract_repository_provenance.py <repo_path>")
