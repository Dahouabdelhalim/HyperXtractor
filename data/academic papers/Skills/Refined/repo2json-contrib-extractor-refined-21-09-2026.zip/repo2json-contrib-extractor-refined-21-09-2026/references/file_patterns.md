# Common File Patterns in ML/AI Repositories

This reference documents the file naming, structural, and code patterns used to detect and classify the nine in-scope entity types from ML/AI repositories.

---

## Training Files → TrainingRun

### File Name Patterns
- `train.py`, `trainer.py`, `training.py`
- `main.py` (when it contains a training loop)
- `run_training.py`, `run_experiment.py`
- `finetune.py`, `pretrain.py`

### Class / Function Indicators
- Classes: `Trainer`, `TrainingPipeline`, `ModelTrainer`
- Functions: `train()`, `train_model()`, `run_training()`, `fit()`

### Import Patterns
- `torch.optim` (PyTorch optimisers)
- `torch.nn.Module` (model definition)
- `tensorflow.keras.optimizers`
- `transformers.Trainer`
- `pytorch_lightning.Trainer`

### Code Patterns
- Training loops: `for epoch in range(num_epochs):`
- Optimiser steps: `optimizer.step()`, `optimizer.zero_grad()`
- Loss computation: `loss.backward()`, `loss.item()`
- Model saving: `torch.save()`, `model.save_pretrained()`

---

## Evaluation Files → EvaluationRun

### File Name Patterns
- `eval.py`, `evaluate.py`, `evaluation.py`
- `test.py`, `testing.py`
- `validate.py`, `validation.py`
- `benchmark.py`, `metrics.py`

### Class / Function Indicators
- Classes: `Evaluator`, `Tester`, `Validator`
- Functions: `evaluate()`, `test()`, `compute_metrics()`, `validate()`

### Import Patterns
- `sklearn.metrics` (evaluation metrics)
- `torch.no_grad()` (inference mode)
- `transformers.EvalPrediction`
- Metric libraries: `torchmetrics`, `evaluate`

### Code Patterns
- No-gradient blocks: `with torch.no_grad():`
- Metric computation: `accuracy_score()`, `f1_score()`, `precision_recall_fscore_support()`
- Result logging: `wandb.log()`, `print(f"F1: {f1}")`

---

## Preprocessing Files → DataProcessingStep

### File Name Patterns
- `preprocess.py`, `preprocessing.py`
- `data_preparation.py`, `prepare_data.py`
- `dataset.py`, `dataloader.py`
- `clean_data.py`, `transform.py`

### Directory Patterns
- `data_preparation/`
- `preprocessing/`
- `data/` (containing processing scripts)

### Class / Function Indicators
- Classes: `Preprocessor`, `DataProcessor`, `DataCleaner`, `Dataset`
- Functions: `preprocess()`, `clean_data()`, `transform()`, `load_data()`

### Import Patterns
- `pandas` (data manipulation)
- `torch.utils.data.Dataset`
- `transformers.AutoTokenizer`
- `sklearn.preprocessing`

### Code Patterns
- Data loading: `pd.read_csv()`, `json.load()`
- Tokenisation: `tokenizer.encode()`, `tokenizer(...)`
- Data splitting: `train_test_split()`
- Feature engineering: `StandardScaler()`, `normalize()`

### TransformationType Mapping

| Code pattern | transformationType |
|---|---|
| `tokenizer.encode()`, `AutoTokenizer` | `tokenization` |
| `StandardScaler()`, `normalize()` | `normalization` |
| `RandomCrop()`, `augment()` | `augmentation` |
| `dropna()`, `filter()`, `clean_data()` | `cleaning` |
| `train_test_split()` | `splitting` |
| `TfidfVectorizer()`, `extract_features()` | `feature_extraction` |

---

## Prediction / Inference Files → PredictionSet

### File Name Patterns
- `predict.py`, `prediction.py`
- `inference.py`, `infer.py`
- `generate.py`, `generation.py`
- `demo.py`, `app.py` (inference demos)

### Class / Function Indicators
- Classes: `Predictor`, `InferenceEngine`, `Generator`
- Functions: `predict()`, `infer()`, `generate()`, `run_inference()`

### Import Patterns
- `torch.no_grad()` (inference mode)
- `transformers.pipeline`
- Model loading: `torch.load()`, `model.load_state_dict()`

### Code Patterns
- Model loading: `model = torch.load(...)`, `model.eval()`
- Batch prediction: `predictions = model(inputs)`
- Output generation: `model.generate()`, `pipeline(...)`
- Writing outputs: `json.dump()`, `df.to_csv()`

---

## Configuration Files → MLS_HyperParameter

### YAML / JSON
- `config.yaml`, `config.yml`, `*.yaml`, `*.yml`
- `config.json`, `settings.json`
- `hparams.yaml`, `hyperparameters.yaml`
- Dataset-specific: `nyt_config.yaml`, `wos_config.yaml`

### Python Config Files
- `config.py`, `configuration.py`
- `args.py`, `arguments.py`
- `settings.py`, `options.py`

### Framework-Specific Config Patterns
- **Hugging Face:** `config.json`, `training_args.json`, `TrainingArguments(...)` calls
- **Hydra:** `config/` directory with YAML files, `@hydra.main(...)` decorator
- **Sacred:** `config.py` with `@ex.config` decorator
- **argparse:** `ArgumentParser()` with `add_argument(...)` defaults

---

## Dependency Files → Dependency

| File | Format | Notes |
|---|---|---|
| `requirements.txt` | `package==version` per line | Most common; handle extras and comments |
| `setup.py` | `install_requires=[...]` | May use `>=` ranges |
| `pyproject.toml` | `[project.dependencies]` | Poetry, PDM, Hatch |
| `environment.yml` | `dependencies:` section | Conda; mix of pip and conda packages |
| `Pipfile` | `[packages]` section | Pipenv |

---

## Environment Files → Environment

| File | What to extract |
|---|---|
| `Dockerfile` | Base image (OS), `RUN pip install` lines, CUDA tag |
| `environment.yml` | `name`, Python version, package list |
| `requirements.txt` | Confirms pip-based environment |
| `.python-version` | Exact Python version (pyenv) |
| `runtime.txt` | Python version (Heroku/cloud) |
| `README.md` | Hardware requirements, GPU/CUDA notes |

---

## Entry Point Detection → MLS_Implementation

### Priority Order
1. `main.py` (most common)
2. `run.py`, `run_experiment.py`
3. `train.py` (when training is the primary function)
4. `__main__.py` (package entry point)
5. `app.py` (web or demo applications)

### Entry Point Indicators
- `if __name__ == "__main__":`
- `argparse.ArgumentParser()` (CLI arguments)
- `fire.Fire()` (Google Fire CLI)
- `click.command()` (Click CLI)

### setup.py Console Scripts
```python
entry_points={
    'console_scripts': ['command=package.module:function'],
}
```

---

## Framework Detection → MLS_Implementation / Environment

| Framework | Key imports | Model file extensions |
|---|---|---|
| PyTorch | `import torch`, `import torch.nn` | `.pt`, `.pth`, `.ckpt` |
| TensorFlow / Keras | `import tensorflow`, `from tensorflow import keras` | `.h5`, `saved_model/` |
| Hugging Face Transformers | `from transformers import` | `pytorch_model.bin`, `model.safetensors` |
| JAX / Flax | `import jax`, `import flax` | `.msgpack`, `.pkl` |
| PyTorch Lightning | `import pytorch_lightning`, `class ... (pl.LightningModule)` | `.ckpt` |
| scikit-learn | `from sklearn import` | `.pkl`, `.joblib` |

---

## Common Repository Structures

### Standard ML Project
```
repo/
├── data/              # Data files or loading scripts
├── models/            # Model definitions
├── configs/           # Configuration files
├── scripts/           # Utility scripts
├── train.py           # Training → TrainingRun
├── eval.py            # Evaluation → EvaluationRun
├── requirements.txt   # Dependencies → Dependency
└── README.md
```

### Research Paper Implementation
```
repo/
├── data_preparation/  # Preprocessing → DataProcessingStep
├── experiments/       # Experiment configs → MLS_HyperParameter
├── models/            # Model architectures
├── utils/             # Utility functions
├── main.py            # Entry point → MLS_Implementation / TrainingRun / EvaluationRun
├── *_config.yaml      # Dataset-specific hyperparameters → MLS_HyperParameter
└── requirements.txt   # Dependencies → Dependency
```

### Hugging Face Style
```
repo/
├── src/
│   ├── data/          # Data processing → DataProcessingStep
│   ├── models/        # Model definitions
│   └── training/      # Training logic
├── configs/           # Configuration files → MLS_HyperParameter
├── run_training.py    # Training → TrainingRun
├── run_evaluation.py  # Evaluation → EvaluationRun
└── requirements.txt   # Dependencies → Dependency
```

---

## Heuristic Priority

When multiple patterns match the same file, classify by priority:

1. **Explicit naming:** `train.py` > `main.py` for TrainingRun
2. **Class / function names:** `class Trainer` over a generic `main()` function
3. **Import patterns:** Framework-specific imports confirm purpose
4. **Code patterns:** Actual loop / metric logic in the file body
5. **Comments / docstrings:** Explicit descriptions in documentation

---

## Edge Cases

### Multi-Purpose Files
`main.py` may contain training, evaluation, and prediction logic. Analyse the functions and classes present and create one entity per role (TrainingRun, EvaluationRun, PredictionSet), all sharing the same `codeReference`.

### Jupyter Notebooks
`*.ipynb` files may encode entire pipelines. Extract from cell source fields if possible; treat the notebook file as the `codeReference`.

### Distributed / Split Code
Training logic spread across multiple files: trace imports, identify the orchestrator file, and set it as the primary `codeReference` while noting supporting modules in `description`.

### Auto-Generated Config Files
Hydra or similar frameworks may emit generated YAML. Focus extraction on source templates and `@hydra.main(...)` decorated files rather than generated outputs.

### Missing requirements.txt
Infer dependencies from `import` statements across Python source files. Mark inferred entries with `"dependencyType": "inferred"` and set `"version": null`.
