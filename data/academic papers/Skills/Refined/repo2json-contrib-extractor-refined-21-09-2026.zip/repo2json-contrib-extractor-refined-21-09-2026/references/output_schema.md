# Output Schema Reference (Repository Entities)

This file defines the JSON-LD `@context` and entity templates for the nine in-scope entity types extracted from ML/AI software repositories.

---

## JSON-LD Context

The output MUST include the following `@context`. Only terms relevant to repository entities are declared here.

```json
{
  "@context": {
    "mls":    "http://example.org/ontology/mls#",
    "schema": "http://schema.org/",
    "xsd":    "http://www.w3.org/2001/XMLSchema#",
    "rdfs":   "http://www.w3.org/2000/01/rdf-schema#",
    "prov":   "http://www.w3.org/ns/prov#",

    "SoftwareRepository":  "mls:SoftwareRepository",
    "MLS_Implementation":  "mls:MLS_Implementation",
    "MLS_HyperParameter":  "mls:MLS_HyperParameter",
    "Dependency":          "mls:Dependency",
    "Environment":         "mls:Environment",
    "DataProcessingStep":  "mls:DataProcessingStep",
    "TrainingRun":         "mls:TrainingRun",
    "EvaluationRun":       "mls:EvaluationRun",
    "PredictionSet":       "mls:PredictionSet",

    "name":                "schema:name",
    "identifier":          "schema:identifier",
    "description":         "schema:description",
    "url":                 "schema:url",
    "version":             "schema:version",
    "license":             "schema:license",
    "programmingLanguage": "schema:programmingLanguage",
    "dateModified":        { "@id": "schema:dateModified",    "@type": "xsd:dateTime" },
    "documentationUrl":    { "@id": "mls:documentationUrl",  "@type": "xsd:anyURI" },

    "owner":               "mls:owner",
    "platform":            "mls:platform",
    "codeRepository":      { "@id": "mls:codeRepository",    "@type": "xsd:anyURI" },
    "framework":           "mls:framework",
    "entryPoint":          "mls:entryPoint",
    "entryPointCommand":   "mls:entryPointCommand",
    "executionCommand":    "mls:executionCommand",
    "commitHash":          "mls:commitHash",
    "branch":              "mls:branch",
    "dependenciesHash":    "mls:dependenciesHash",

    "packageName":         "mls:packageName",
    "dependencyType":      "mls:dependencyType",
    "isOptional":          { "@id": "mls:isOptional",        "@type": "xsd:boolean" },

    "hardwareSpecs":       "mls:hardwareSpecs",
    "os":                  "mls:os",
    "pythonVersion":       "mls:pythonVersion",
    "requirementsFile":    "mls:requirementsFile",
    "isDockerized":        { "@id": "mls:isDockerized",      "@type": "xsd:boolean" },

    "hasValue":            { "@id": "mls:hasValue",          "@type": "xsd:string" },
    "hpCategory":          "mls:hpCategory",
    "hpType":              "mls:hpType",
    "sourceFile":          "mls:sourceFile",
    "sourceLine":          { "@id": "mls:sourceLine",        "@type": "xsd:integer" },
    "uncertain":           { "@id": "mls:uncertain",         "@type": "xsd:boolean" },

    "transformationType":  "mls:transformationType",
    "codeReference":       { "@id": "mls:codeReference",     "@type": "xsd:anyURI" },
    "runId":               "mls:runId",
    "logFile":             { "@id": "mls:logFile",           "@type": "xsd:anyURI" },
    "artifactsLocation":   { "@id": "mls:artifactsLocation", "@type": "xsd:anyURI" },
    "split":               "mls:split",
    "evaluationScript":    "mls:evaluationScript",
    "evaluationSplit":     "mls:evaluationSplit",
    "metricsFile":         "mls:metricsFile",
    "format":              "mls:format",
    "predictionFormat":    "mls:predictionFormat",
    "storageLocation":     "mls:storageLocation",
    "numInstances":        { "@id": "mls:numInstances",      "@type": "xsd:integer" },
    "onDatasetSplit":      "mls:onDatasetSplit",
    "startedAtTime":       { "@id": "prov:startedAtTime",    "@type": "xsd:dateTime" },
    "endedAtTime":         { "@id": "prov:endedAtTime",      "@type": "xsd:dateTime" },

    "contains":            { "@id": "mls:contains",          "@type": "@id" },
    "supports":            { "@id": "mls:supports",          "@type": "@id" },
    "runsIn":              { "@id": "mls:runsIn",            "@type": "@id" },
    "requires":            { "@id": "mls:requires",          "@type": "@id" },
    "inputDataset":        { "@id": "mls:inputDataset",      "@type": "@id" },
    "outputDataset":       { "@id": "mls:outputDataset",     "@type": "@id" },
    "trains":              { "@id": "mls:trains",            "@type": "@id" },
    "evaluates":           { "@id": "mls:evaluates",         "@type": "@id" },
    "appliedTo":           { "@id": "mls:appliedTo",         "@type": "@id" },
    "producedBy":          { "@id": "mls:producedBy",        "@type": "@id" },
    "prov-executedBy":     { "@id": "mls:prov-executedBy",   "@type": "@id" },
    "prov-generated":      { "@id": "mls:prov-generated",    "@type": "@id" },
    "used":                { "@id": "prov:used",             "@type": "@id" },
    "wasGeneratedBy":      { "@id": "prov:wasGeneratedBy",   "@type": "@id" },
    "wasDerivedFrom":      { "@id": "prov:wasDerivedFrom",   "@type": "@id" },
    "wasAssociatedWith":   { "@id": "prov:wasAssociatedWith","@type": "@id" }
  },
  "@graph": []
}
```

---

## Provenance Block (Common to Every Entity)

Every entity MUST include the following provenance block. Use default values when the entity mention cannot be located in a specific file.

```json
{
  "wasDerivedFrom": "code",
  "codeReference": "relative/path/to/source_file.py",
  "path":          "relative/path/to/source_file.py",
  "start_char_doc": 245,
  "end_char_doc":   250,
  "context": {
    "prefix": "up to five words before",
    "suffix": "up to five words after"
  }
}
```

**Default values when not found in any file:**
```json
{
  "wasDerivedFrom": "code",
  "codeReference": "",
  "path":          "",
  "start_char_doc": 0,
  "end_char_doc":   0,
  "context": { "prefix": "", "suffix": "" }
}
```

---

## Entity Templates

### SoftwareRepository

```json
{
  "@id":                "repo_{owner}_{name}",
  "@type":              "SoftwareRepository",
  "name":               "Repository Name",
  "url":                "https://github.com/owner/repo",
  "owner":              "owner",
  "platform":           "GitHub",
  "programmingLanguage": "Python",
  "version":            null,
  "license":            null,
  "dateModified":       null,
  "documentationUrl":   null,
  "contains":           [ { "@id": "impl_{repo_name}" } ],
  "supports":           [ { "@id": "env_{repo_name}"  } ],
  "wasDerivedFrom":     "code",
  "codeReference":      "README.md",
  "path":               "README.md",
  "start_char_doc":     0,
  "end_char_doc":       0,
  "context":            { "prefix": "", "suffix": "" }
}
```

---

### MLS_Implementation

```json
{
  "@id":               "impl_{repo_name}",
  "@type":             "MLS_Implementation",
  "identifier":        "Descriptive Implementation Name",
  "codeRepository":    "https://github.com/owner/repo",
  "framework":         "PyTorch",
  "entryPoint":        "main.py",
  "entryPointCommand": "python main.py --config config.yaml",
  "executionCommand":  null,
  "commitHash":        null,
  "branch":            null,
  "dependenciesHash":  null,
  "runsIn":            { "@id": "env_{repo_name}" },
  "requires":          [ { "@id": "dep_{package}" } ],
  "wasDerivedFrom":    "code",
  "codeReference":     "main.py",
  "path":              "main.py",
  "start_char_doc":    0,
  "end_char_doc":      0,
  "context":           { "prefix": "", "suffix": "" }
}
```

---

### Environment

```json
{
  "@id":              "env_{repo_name}",
  "@type":            "Environment",
  "name":             "Descriptive Environment Name",
  "framework":        "PyTorch 2.2.2",
  "pythonVersion":    "3.11",
  "os":               null,
  "hardwareSpecs":    null,
  "requirementsFile": "requirements.txt",
  "isDockerized":     false,
  "wasDerivedFrom":   "code",
  "codeReference":    "requirements.txt",
  "path":             "requirements.txt",
  "start_char_doc":   0,
  "end_char_doc":     0,
  "context":          { "prefix": "", "suffix": "" }
}
```

---

### Dependency

```json
{
  "@id":            "dep_{package_name}",
  "@type":          "Dependency",
  "packageName":    "torch",
  "version":        "2.2.2",
  "dependencyType": "runtime",
  "isOptional":     false,
  "wasDerivedFrom": "code",
  "codeReference":  "requirements.txt:176",
  "path":           "requirements.txt",
  "start_char_doc": 0,
  "end_char_doc":   0,
  "context":        { "prefix": "", "suffix": "" }
}
```

---

### MLS_HyperParameter

Every hyperparameter entity MUST include `hpCategory` (one of `HP_Optimization`, `HP_Training`, `HP_Architecture`, `HP_Data`) and `hpType` (the exact leaf class name, e.g. `LearningRate`). Mark `"uncertain": true` when classification is ambiguous.

```json
{
  "@id":            "hp_{param_name}",
  "@type":          "MLS_HyperParameter",
  "name":           "learning_rate",
  "hasValue":       "5e-5",
  "hpCategory":     "HP_Optimization",
  "hpType":         "LearningRate",
  "uncertain":      false,
  "sourceFile":     "config.yaml",
  "sourceLine":     14,
  "wasDerivedFrom": "code",
  "codeReference":  "config.yaml:14",
  "path":           "config.yaml",
  "start_char_doc": 312,
  "end_char_doc":   325,
  "context":        { "prefix": "optimizer settings:", "suffix": "scheduler cosine warmup" }
}
```

**Multi-value example** (same parameter across dataset-specific configs):
```json
{
  "@id":            "hp_learning_rate_nyt",
  "@type":          "MLS_HyperParameter",
  "name":           "learning_rate (NYT)",
  "hasValue":       "1e-4",
  "hpCategory":     "HP_Optimization",
  "hpType":         "LearningRate",
  "uncertain":      false,
  "sourceFile":     "nyt_config.yaml",
  "sourceLine":     22,
  "wasDerivedFrom": "code",
  "codeReference":  "nyt_config.yaml:22",
  "path":           "nyt_config.yaml",
  "start_char_doc": 0,
  "end_char_doc":   0,
  "context":        { "prefix": "", "suffix": "" }
}
```

---

### DataProcessingStep

```json
{
  "@id":               "preprocess_{script_name}",
  "@type":             "DataProcessingStep",
  "identifier":        "Descriptive Step Name",
  "description":       "What the preprocessing does",
  "transformationType": "tokenization",
  "startedAtTime":     null,
  "endedAtTime":       null,
  "inputDataset":      null,
  "outputDataset":     null,
  "prov-executedBy":   { "@id": "impl_{repo_name}" },
  "wasDerivedFrom":    "code",
  "codeReference":     "preprocess.py",
  "path":              "preprocess.py",
  "start_char_doc":    0,
  "end_char_doc":      0,
  "context":           { "prefix": "", "suffix": "" }
}
```

Valid `transformationType` values: `"tokenization"`, `"normalization"`, `"augmentation"`, `"cleaning"`, `"splitting"`, `"feature_extraction"`.

---

### TrainingRun

```json
{
  "@id":              "training_{repo_name}",
  "@type":            "TrainingRun",
  "runId":            "training_run_identifier",
  "description":      "Description of what is being trained",
  "logFile":          null,
  "artifactsLocation": null,
  "startedAtTime":    null,
  "endedAtTime":      null,
  "prov-executedBy":  { "@id": "impl_{repo_name}" },
  "used":             [ { "@id": "dataset_id" } ],
  "trains":           null,
  "wasDerivedFrom":   "code",
  "codeReference":    "train.py",
  "path":             "train.py",
  "start_char_doc":   0,
  "end_char_doc":     0,
  "context":          { "prefix": "", "suffix": "" }
}
```

---

### EvaluationRun

```json
{
  "@id":               "evaluation_{repo_name}",
  "@type":             "EvaluationRun",
  "runId":             "evaluation_run_identifier",
  "description":       "Description of what is being evaluated",
  "split":             "test",
  "evaluationScript":  "eval.py",
  "metricsFile":       null,
  "startedAtTime":     null,
  "endedAtTime":       null,
  "prov-executedBy":   { "@id": "impl_{repo_name}" },
  "evaluates":         null,
  "prov-generated":    [ { "@id": "prediction_{name}" } ],
  "wasDerivedFrom":    "code",
  "codeReference":     "eval.py",
  "path":              "eval.py",
  "start_char_doc":    0,
  "end_char_doc":      0,
  "context":           { "prefix": "", "suffix": "" }
}
```

---

### PredictionSet

```json
{
  "@id":              "prediction_{script_name}",
  "@type":            "PredictionSet",
  "identifier":       "Descriptive Name",
  "description":      "What predictions are generated",
  "predictionFormat": "JSON",
  "storageLocation":  "predictions/",
  "numInstances":     null,
  "onDatasetSplit":   null,
  "appliedTo":        null,
  "wasGeneratedBy":   null,
  "producedBy":       { "@id": "impl_{repo_name}" },
  "wasDerivedFrom":   "code",
  "codeReference":    "predict.py",
  "path":             "predict.py",
  "start_char_doc":   0,
  "end_char_doc":     0,
  "context":          { "prefix": "", "suffix": "" }
}
```

---

## Code Reference Format

| Format | Example | When to use |
|---|---|---|
| File only | `"train.py"` | Entity spans an entire file |
| File + line | `"config.yaml:14"` | Entity pinned to a single line |
| File + line range | `"utils.py:23-45"` | Entity spans several lines |
| Config key path | `"config.yaml:model.hidden_size"` | Nested YAML/JSON key |
