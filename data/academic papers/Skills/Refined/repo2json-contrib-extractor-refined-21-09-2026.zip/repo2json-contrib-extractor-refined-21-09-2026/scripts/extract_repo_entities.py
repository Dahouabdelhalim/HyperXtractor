#!/usr/bin/env python3
"""
Main extraction script for repository contribution entities.
Extracts hyperparameters, dependencies, provenance files, and implementation details.
"""

import argparse
import json
import re
import os
import sys
from pathlib import Path
from typing import Dict, List, Any, Optional, Tuple
from urllib.parse import urlparse
import yaml

class RepositoryExtractor:
    """Extract contribution entities from ML/AI repositories."""
    
    def __init__(self, repo_url: str, repo_path: str):
        self.repo_url = repo_url
        self.repo_path = Path(repo_path)
        self.repo_name = self._extract_repo_name(repo_url)
        self.owner = self._extract_owner(repo_url)
        self.entities = []
        
    def _extract_repo_name(self, url: str) -> str:
        """Extract repository name from URL."""
        parts = url.rstrip('/').split('/')
        return parts[-1].replace('.git', '')
    
    def _extract_owner(self, url: str) -> str:
        """Extract owner from URL."""
        parts = url.rstrip('/').split('/')
        return parts[-2] if len(parts) >= 2 else "unknown"
    
    def _sanitize_id(self, text: str) -> str:
        """Sanitize text for use in entity IDs."""
        return re.sub(r'[^a-zA-Z0-9_]', '_', text.lower())
    
    def extract_all(self) -> Dict[str, Any]:
        """Extract all entities from repository."""
        print(f"Extracting entities from {self.repo_name}...")
        
        # Extract core entities
        self._extract_repository()
        self._extract_implementation()
        self._extract_environment()
        self._extract_dependencies()
        
        # Extract hyperparameters from config files
        self._extract_hyperparameters()
        
        # Extract provenance files
        self._extract_provenance_files()
        
        # Build JSON-LD output
        return self._build_jsonld()
    
    def _extract_repository(self):
        """Extract SoftwareRepository entity."""
        repo_id = f"repo_{self._sanitize_id(self.owner)}_{self._sanitize_id(self.repo_name)}"
        
        # Detect programming language
        py_files = list(self.repo_path.glob("**/*.py"))
        prog_lang = "Python" if py_files else "Unknown"
        
        entity = {
            "@id": repo_id,
            "@type": "SoftwareRepository",
            "name": self.repo_name,
            "url": self.repo_url,
            "owner": self.owner,
            "platform": "GitHub",
            "programmingLanguage": prog_lang,
            "contains": [{"@id": f"impl_{self._sanitize_id(self.repo_name)}"}],
            "supports": [{"@id": f"env_{self._sanitize_id(self.repo_name)}"}],
            "start_char_doc": 0,
            "end_char_doc": 0,
            "context": {"prefix": "", "suffix": ""},
            "path": "",
            "wasDerivedFrom": "code"
        }
        
        self.entities.append(entity)
        print(f"  ✓ Extracted SoftwareRepository: {repo_id}")
    
    def _extract_implementation(self):
        """Extract MLS_Implementation entity."""
        impl_id = f"impl_{self._sanitize_id(self.repo_name)}"
        
        # Find entry point
        entry_point = self._find_entry_point()
        
        # Detect framework
        framework = self._detect_framework()
        
        # Get commit hash (if available from git)
        commit_hash = self._get_commit_hash()
        
        entity = {
            "@id": impl_id,
            "@type": "MLS_Implementation",
            "identifier": f"{self.repo_name} Implementation",
            "codeRepository": self.repo_url,
            "framework": framework,
            "entryPoint": entry_point,
            "commitHash": commit_hash,
            "runsIn": {"@id": f"env_{self._sanitize_id(self.repo_name)}"},
            "requires": [],  # Will be populated with dependencies
            "start_char_doc": 0,
            "end_char_doc": 0,
            "context": {"prefix": "", "suffix": ""},
            "path": "",
            "wasDerivedFrom": "code"
        }
        
        self.entities.append(entity)
        print(f"  ✓ Extracted MLS_Implementation: {impl_id}")
        print(f"    - Entry point: {entry_point}")
        print(f"    - Framework: {framework}")
    
    def _find_entry_point(self) -> Optional[str]:
        """Find the main entry point file."""
        candidates = [
            "main.py", "train.py", "run.py", "__main__.py",
            "run_training.py", "run_experiment.py"
        ]
        
        for candidate in candidates:
            if (self.repo_path / candidate).exists():
                return candidate
        
        # Check for if __name__ == "__main__" in Python files
        for py_file in self.repo_path.glob("*.py"):
            content = py_file.read_text(errors='ignore')
            if 'if __name__ == "__main__"' in content:
                return py_file.name
        
        return None
    
    def _detect_framework(self) -> str:
        """Detect ML framework used."""
        # Check imports in Python files
        frameworks = {
            "torch": "PyTorch",
            "tensorflow": "TensorFlow",
            "jax": "JAX",
            "flax": "Flax",
            "transformers": "Hugging Face Transformers",
            "pytorch_lightning": "PyTorch Lightning"
        }
        
        for py_file in self.repo_path.glob("**/*.py"):
            try:
                content = py_file.read_text(errors='ignore')
                for import_name, framework_name in frameworks.items():
                    if f"import {import_name}" in content or f"from {import_name}" in content:
                        return framework_name
            except:
                continue
        
        return "Unknown"
    
    def _get_commit_hash(self) -> Optional[str]:
        """Get latest commit hash if .git exists."""
        git_dir = self.repo_path / ".git"
        if git_dir.exists():
            head_file = git_dir / "HEAD"
            if head_file.exists():
                try:
                    head_content = head_file.read_text().strip()
                    if head_content.startswith("ref:"):
                        ref_path = head_content.split(": ")[1]
                        ref_file = git_dir / ref_path
                        if ref_file.exists():
                            return ref_file.read_text().strip()[:7]
                except:
                    pass
        return None
    
    def _extract_environment(self):
        """Extract Environment entity."""
        env_id = f"env_{self._sanitize_id(self.repo_name)}"
        
        # Detect Python version
        python_version = self._detect_python_version()
        
        # Check for Docker
        is_dockerized = (self.repo_path / "Dockerfile").exists()
        
        # Find requirements file
        req_file = self._find_requirements_file()
        
        entity = {
            "@id": env_id,
            "@type": "Environment",
            "name": f"{self.repo_name} Environment",
            "framework": self._detect_framework(),
            "pythonVersion": python_version,
            "requirementsFile": req_file,
            "isDockerized": is_dockerized,
            "start_char_doc": 0,
            "end_char_doc": 0,
            "context": {"prefix": "", "suffix": ""},
            "path": "",
            "wasDerivedFrom": "code"
        }
        
        self.entities.append(entity)
        print(f"  ✓ Extracted Environment: {env_id}")
    
    def _detect_python_version(self) -> Optional[str]:
        """Detect Python version from various sources."""
        # Check .python-version
        python_version_file = self.repo_path / ".python-version"
        if python_version_file.exists():
            return python_version_file.read_text().strip()
        
        # Check runtime.txt
        runtime_file = self.repo_path / "runtime.txt"
        if runtime_file.exists():
            content = runtime_file.read_text().strip()
            match = re.search(r'python-(\d+\.\d+\.\d+)', content)
            if match:
                return match.group(1)
        
        # Check setup.py
        setup_file = self.repo_path / "setup.py"
        if setup_file.exists():
            content = setup_file.read_text(errors='ignore')
            match = re.search(r'python_requires=["\']>=(\d+\.\d+)', content)
            if match:
                return f">={match.group(1)}"
        
        return None
    
    def _find_requirements_file(self) -> Optional[str]:
        """Find requirements file."""
        candidates = [
            "requirements.txt",
            "requirements/base.txt",
            "requirements/production.txt"
        ]
        
        for candidate in candidates:
            if (self.repo_path / candidate).exists():
                return candidate
        
        if (self.repo_path / "setup.py").exists():
            return "setup.py"
        
        if (self.repo_path / "pyproject.toml").exists():
            return "pyproject.toml"
        
        return None
    
    def _extract_dependencies(self):
        """Extract Dependency entities."""
        req_file = self._find_requirements_file()
        
        if not req_file:
            print("  ⚠ No requirements file found")
            return
        
        req_path = self.repo_path / req_file
        
        if req_file == "requirements.txt" or req_file.endswith(".txt"):
            deps = self._parse_requirements_txt(req_path)
        elif req_file == "setup.py":
            deps = self._parse_setup_py(req_path)
        elif req_file == "pyproject.toml":
            deps = self._parse_pyproject_toml(req_path)
        else:
            deps = []
        
        impl_id = f"impl_{self._sanitize_id(self.repo_name)}"
        
        for dep_name, dep_version in deps:
            dep_id = f"dep_{self._sanitize_id(dep_name)}"
            
            entity = {
                "@id": dep_id,
                "@type": "Dependency",
                "packageName": dep_name,
                "version": dep_version,
                "dependencyType": "runtime",
                "isOptional": False,
                "codeReference": req_file,
                "start_char_doc": 0,
                "end_char_doc": 0,
                "context": {"prefix": "", "suffix": ""},
            "path": "",
                "wasDerivedFrom": "code"
            }
            
            self.entities.append(entity)
            
            # Add to implementation requires
            for e in self.entities:
                if e.get("@id") == impl_id:
                    e["requires"].append({"@id": dep_id})
        
        print(f"  ✓ Extracted {len(deps)} dependencies")
    
    def _parse_requirements_txt(self, file_path: Path) -> List[Tuple[str, Optional[str]]]:
        """Parse requirements.txt file."""
        deps = []
        
        try:
            content = file_path.read_text(errors='ignore')
            for line in content.split('\n'):
                line = line.strip()
                
                # Skip comments and empty lines
                if not line or line.startswith('#'):
                    continue
                
                # Skip -e and git+ lines
                if line.startswith('-e') or line.startswith('git+'):
                    continue
                
                # Parse package==version or package>=version
                match = re.match(r'([a-zA-Z0-9_-]+)([=<>!]+)([0-9.]+)', line)
                if match:
                    pkg_name = match.group(1)
                    operator = match.group(2)
                    version = match.group(3)
                    
                    if operator == "==":
                        deps.append((pkg_name, version))
                    else:
                        deps.append((pkg_name, f"{operator}{version}"))
                else:
                    # Package without version
                    pkg_name = re.match(r'([a-zA-Z0-9_-]+)', line)
                    if pkg_name:
                        deps.append((pkg_name.group(1), None))
        except Exception as e:
            print(f"  ⚠ Error parsing requirements.txt: {e}")
        
        return deps
    
    def _parse_setup_py(self, file_path: Path) -> List[Tuple[str, Optional[str]]]:
        """Parse setup.py file (simplified)."""
        deps = []
        
        try:
            content = file_path.read_text(errors='ignore')
            
            # Find install_requires
            match = re.search(r'install_requires\s*=\s*\[(.*?)\]', content, re.DOTALL)
            if match:
                requires_str = match.group(1)
                
                # Extract package names
                for line in requires_str.split(','):
                    line = line.strip().strip('"').strip("'")
                    if line:
                        pkg_match = re.match(r'([a-zA-Z0-9_-]+)([=<>!]+)?([0-9.]+)?', line)
                        if pkg_match:
                            pkg_name = pkg_match.group(1)
                            version = pkg_match.group(3) if pkg_match.group(3) else None
                            deps.append((pkg_name, version))
        except Exception as e:
            print(f"  ⚠ Error parsing setup.py: {e}")
        
        return deps
    
    def _parse_pyproject_toml(self, file_path: Path) -> List[Tuple[str, Optional[str]]]:
        """Parse pyproject.toml file (simplified)."""
        deps = []
        
        try:
            content = file_path.read_text(errors='ignore')
            
            # Find dependencies section
            in_deps = False
            for line in content.split('\n'):
                if '[project.dependencies]' in line or 'dependencies = [' in line:
                    in_deps = True
                    continue
                
                if in_deps:
                    if line.strip().startswith('['):
                        break
                    
                    match = re.search(r'"([a-zA-Z0-9_-]+)([=<>!]+)?([0-9.]+)?"', line)
                    if match:
                        pkg_name = match.group(1)
                        version = match.group(3) if match.group(3) else None
                        deps.append((pkg_name, version))
        except Exception as e:
            print(f"  ⚠ Error parsing pyproject.toml: {e}")
        
        return deps
    
    def _extract_hyperparameters(self):
        """Extract hyperparameters from config files."""
        # Find YAML config files
        yaml_files = list(self.repo_path.glob("*.yaml")) + list(self.repo_path.glob("*.yml"))
        yaml_files += list(self.repo_path.glob("config/*.yaml")) + list(self.repo_path.glob("config/*.yml"))
        yaml_files += list(self.repo_path.glob("configs/*.yaml")) + list(self.repo_path.glob("configs/*.yml"))
        
        # Find JSON config files
        json_files = list(self.repo_path.glob("*config*.json"))
        json_files += list(self.repo_path.glob("config/*.json")) + list(self.repo_path.glob("configs/*.json"))
        
        total_params = 0
        
        for yaml_file in yaml_files:
            params = self._extract_from_yaml(yaml_file)
            total_params += len(params)
        
        for json_file in json_files:
            params = self._extract_from_json(json_file)
            total_params += len(params)
        
        if total_params > 0:
            print(f"  ✓ Extracted {total_params} hyperparameters")
        else:
            print("  ⚠ No hyperparameters found")
    
    def _extract_from_yaml(self, file_path: Path) -> List[Dict]:
        """Extract hyperparameters from YAML file."""
        params = []
        
        try:
            with open(file_path, 'r') as f:
                data = yaml.safe_load(f)
            
            if not isinstance(data, dict):
                return params
            
            # Flatten nested dict
            flat_params = self._flatten_dict(data)
            
            for key, value in flat_params.items():
                # Skip non-hyperparameter keys
                if key in ['train_src', 'train_tgt', 'val_src', 'val_tgt', 'test_src', 'test_tgt',
                          'label_file', 'hiera_file', 'text_pseudo_file', 'model_file', 'result_file',
                          'log_file', 'trained_model_file', 'Desc']:
                    continue
                
                param_id = f"hp_{self._sanitize_id(key)}"
                
                # Check if this param already exists (from another config file)
                existing = False
                for entity in self.entities:
                    if entity.get("@id") == param_id:
                        existing = True
                        # Update codeReference to include multiple files
                        if isinstance(entity.get("codeReference"), str):
                            entity["codeReference"] = [entity["codeReference"], str(file_path.name)]
                        elif isinstance(entity.get("codeReference"), list):
                            entity["codeReference"].append(str(file_path.name))
                        break
                
                if not existing:
                    entity = {
                        "@id": param_id,
                        "@type": "MLS_HyperParameter",
                        "name": key,
                        "hasValue": str(value),
                        "codeReference": str(file_path.name),
                        "sourceFile": file_path.name,
                        "start_char_doc": 0,
                        "end_char_doc": 0,
                        "context": {"prefix": "", "suffix": ""},
            "path": "",
                        "wasDerivedFrom": "code"
                    }
                    
                    self.entities.append(entity)
                    params.append(entity)
        
        except Exception as e:
            print(f"  ⚠ Error parsing {file_path.name}: {e}")
        
        return params
    
    def _extract_from_json(self, file_path: Path) -> List[Dict]:
        """Extract hyperparameters from JSON file."""
        params = []
        
        try:
            with open(file_path, 'r') as f:
                data = json.load(f)
            
            if not isinstance(data, dict):
                return params
            
            # Flatten nested dict
            flat_params = self._flatten_dict(data)
            
            for key, value in flat_params.items():
                param_id = f"hp_{self._sanitize_id(key)}"
                
                entity = {
                    "@id": param_id,
                    "@type": "MLS_HyperParameter",
                    "name": key,
                    "hasValue": str(value),
                    "codeReference": str(file_path.name),
                    "sourceFile": file_path.name,
                    "start_char_doc": 0,
                    "end_char_doc": 0,
                    "context": {"prefix": "", "suffix": ""},
            "path": "",
                    "wasDerivedFrom": "code"
                }
                
                self.entities.append(entity)
                params.append(entity)
        
        except Exception as e:
            print(f"  ⚠ Error parsing {file_path.name}: {e}")
        
        return params
    
    def _flatten_dict(self, d: Dict, parent_key: str = '', sep: str = '.') -> Dict:
        """Flatten nested dictionary."""
        items = []
        for k, v in d.items():
            new_key = f"{parent_key}{sep}{k}" if parent_key else k
            if isinstance(v, dict):
                items.extend(self._flatten_dict(v, new_key, sep=sep).items())
            else:
                items.append((new_key, v))
        return dict(items)
    
    def _extract_provenance_files(self):
        """Extract provenance file entities."""
        # Find training files
        training_files = self._find_files_by_pattern([
            "train.py", "trainer.py", "training.py", "main.py",
            "run_training.py", "finetune.py"
        ])
        
        if training_files:
            self._create_training_run(training_files)
        
        # Find evaluation files
        eval_files = self._find_files_by_pattern([
            "eval.py", "evaluate.py", "evaluation.py", "test.py",
            "validate.py", "benchmark.py"
        ])
        
        if eval_files:
            self._create_evaluation_run(eval_files)
        
        # Find preprocessing files
        preprocess_files = self._find_files_by_pattern([
            "preprocess.py", "preprocessing.py", "prepare_data.py",
            "data_preparation.py", "dataset.py"
        ])
        
        # Check for preprocessing directories
        preprocess_dirs = []
        for dir_name in ["data_preparation", "preprocessing", "data_processing"]:
            dir_path = self.repo_path / dir_name
            if dir_path.exists() and dir_path.is_dir():
                preprocess_dirs.append(dir_name)
        
        if preprocess_files or preprocess_dirs:
            self._create_preprocessing_step(preprocess_files, preprocess_dirs)
        
        # Find prediction files
        predict_files = self._find_files_by_pattern([
            "predict.py", "prediction.py", "inference.py", "infer.py",
            "generate.py", "demo.py"
        ])
        
        if predict_files:
            self._create_prediction_set(predict_files)
    
    def _find_files_by_pattern(self, patterns: List[str]) -> List[str]:
        """Find files matching patterns."""
        found = []
        
        for pattern in patterns:
            matches = list(self.repo_path.glob(f"**/{pattern}"))
            found.extend([str(m.relative_to(self.repo_path)) for m in matches])
        
        return found
    
    def _create_training_run(self, files: List[str]):
        """Create TrainingRun entity."""
        training_id = f"training_{self._sanitize_id(self.repo_name)}"
        impl_id = f"impl_{self._sanitize_id(self.repo_name)}"
        
        # Find log files
        log_files = list(self.repo_path.glob("logs/**/*.txt"))
        log_file = str(log_files[0].relative_to(self.repo_path)) if log_files else None
        
        entity = {
            "@id": training_id,
            "@type": "TrainingRun",
            "runId": f"{self.repo_name}_training",
            "description": f"Training run for {self.repo_name}",
            "codeReference": files[0] if files else None,
            "logFile": log_file,
            "prov-executedBy": {"@id": impl_id},
            "start_char_doc": 0,
            "end_char_doc": 0,
            "context": {"prefix": "", "suffix": ""},
            "path": "",
            "wasDerivedFrom": "code"
        }
        
        self.entities.append(entity)
        print(f"  ✓ Extracted TrainingRun: {training_id}")
    
    def _create_evaluation_run(self, files: List[str]):
        """Create EvaluationRun entity."""
        eval_id = f"evaluation_{self._sanitize_id(self.repo_name)}"
        impl_id = f"impl_{self._sanitize_id(self.repo_name)}"
        
        # Find result files
        result_files = list(self.repo_path.glob("results/**/*.txt"))
        result_file = str(result_files[0].relative_to(self.repo_path)) if result_files else None
        
        entity = {
            "@id": eval_id,
            "@type": "EvaluationRun",
            "runId": f"{self.repo_name}_evaluation",
            "description": f"Evaluation run for {self.repo_name}",
            "split": "test",
            "codeReference": files[0] if files else None,
            "evaluationScript": files[0] if files else None,
            "metricsFile": result_file,
            "prov-executedBy": {"@id": impl_id},
            "start_char_doc": 0,
            "end_char_doc": 0,
            "context": {"prefix": "", "suffix": ""},
            "path": "",
            "wasDerivedFrom": "code"
        }
        
        self.entities.append(entity)
        print(f"  ✓ Extracted EvaluationRun: {eval_id}")
    
    def _create_preprocessing_step(self, files: List[str], dirs: List[str]):
        """Create DataProcessingStep entity."""
        preprocess_id = f"preprocess_{self._sanitize_id(self.repo_name)}"
        impl_id = f"impl_{self._sanitize_id(self.repo_name)}"
        
        code_ref = dirs[0] if dirs else (files[0] if files else None)
        
        entity = {
            "@id": preprocess_id,
            "@type": "DataProcessingStep",
            "identifier": f"{self.repo_name} Data Preprocessing",
            "transformationType": "preprocessing",
            "description": "Data preprocessing and preparation pipeline",
            "codeReference": code_ref,
            "prov-executedBy": {"@id": impl_id},
            "start_char_doc": 0,
            "end_char_doc": 0,
            "context": {"prefix": "", "suffix": ""},
            "path": "",
            "wasDerivedFrom": "code"
        }
        
        self.entities.append(entity)
        print(f"  ✓ Extracted DataProcessingStep: {preprocess_id}")
    
    def _create_prediction_set(self, files: List[str]):
        """Create PredictionSet entity."""
        predict_id = f"prediction_{self._sanitize_id(self.repo_name)}"
        impl_id = f"impl_{self._sanitize_id(self.repo_name)}"
        
        entity = {
            "@id": predict_id,
            "@type": "PredictionSet",
            "identifier": f"{self.repo_name} Predictions",
            "description": "Model predictions and inference outputs",
            "codeReference": files[0] if files else None,
            "producedBy": {"@id": impl_id},
            "start_char_doc": 0,
            "end_char_doc": 0,
            "context": {"prefix": "", "suffix": ""},
            "path": "",
            "wasDerivedFrom": "code"
        }
        
        self.entities.append(entity)
        print(f"  ✓ Extracted PredictionSet: {predict_id}")
    
    def _build_jsonld(self) -> Dict[str, Any]:
        """Build final JSON-LD output."""
        context = {
            "mls": "http://example.org/ontology/mls#",
            "schema": "http://schema.org/",
            "xsd": "http://www.w3.org/2001/XMLSchema#",
            "prov": "http://www.w3.org/ns/prov#",
            "SoftwareRepository": "mls:SoftwareRepository",
            "MLS_Implementation": "mls:MLS_Implementation",
            "Environment": "mls:Environment",
            "Dependency": "mls:Dependency",
            "MLS_HyperParameter": "mls:MLS_HyperParameter",
            "DataProcessingStep": "mls:DataProcessingStep",
            "TrainingRun": "mls:TrainingRun",
            "EvaluationRun": "mls:EvaluationRun",
            "PredictionSet": "mls:PredictionSet",
            "name": "schema:name",
            "url": "schema:url",
            "description": "schema:description",
            "identifier": "schema:identifier",
            "programmingLanguage": "schema:programmingLanguage",
            "codeRepository": {"@id": "mls:codeRepository", "@type": "xsd:anyURI"},
            "framework": "mls:framework",
            "entryPoint": "mls:entryPoint",
            "commitHash": "mls:commitHash",
            "packageName": "mls:packageName",
            "version": "schema:version",
            "dependencyType": "mls:dependencyType",
            "isOptional": {"@id": "mls:isOptional", "@type": "xsd:boolean"},
            "pythonVersion": "mls:pythonVersion",
            "requirementsFile": "mls:requirementsFile",
            "isDockerized": {"@id": "mls:isDockerized", "@type": "xsd:boolean"},
            "hasValue": {"@id": "mls:hasValue", "@type": "xsd:string"},
            "codeReference": "mls:codeReference",
            "sourceFile": "mls:sourceFile",
            "sourceLine": {"@id": "mls:sourceLine", "@type": "xsd:integer"},
            "transformationType": "mls:transformationType",
            "runId": "mls:runId",
            "logFile": {"@id": "mls:logFile", "@type": "xsd:anyURI"},
            "split": "mls:split",
            "evaluationScript": "mls:evaluationScript",
            "metricsFile": "mls:metricsFile",
            "predictionFormat": "mls:predictionFormat",
            "storageLocation": "mls:storageLocation",
            "owner": "mls:owner",
            "platform": "mls:platform",
            "contains": {"@id": "mls:contains", "@type": "@id"},
            "supports": {"@id": "mls:supports", "@type": "@id"},
            "runsIn": {"@id": "mls:runsIn", "@type": "@id"},
            "requires": {"@id": "mls:requires", "@type": "@id"},
            "prov-executedBy": {"@id": "prov:executedBy", "@type": "@id"},
            "producedBy": {"@id": "mls:producedBy", "@type": "@id"},
            "wasDerivedFrom": {"@id": "prov:wasDerivedFrom", "@type": "xsd:string"}
        }
        
        return {
            "@context": context,
            "@graph": self.entities
        }


def main():
    parser = argparse.ArgumentParser(description="Extract entities from ML/AI repository")
    parser.add_argument("--repo-url", required=True, help="GitHub repository URL")
    parser.add_argument("--repo-path", required=True, help="Local path to cloned repository")
    parser.add_argument("--output", required=True, help="Output JSON-LD file path")
    
    args = parser.parse_args()
    
    # Validate inputs
    if not os.path.exists(args.repo_path):
        print(f"Error: Repository path does not exist: {args.repo_path}")
        sys.exit(1)
    
    # Extract entities
    extractor = RepositoryExtractor(args.repo_url, args.repo_path)
    output = extractor.extract_all()
    
    # Write output
    with open(args.output, 'w', encoding='utf-8') as f:
        json.dump(output, f, indent=2, ensure_ascii=False)
    
    print(f"\n✅ Extraction complete!")
    print(f"   Total entities: {len(output['@graph'])}")
    print(f"   Output: {args.output}")


if __name__ == "__main__":
    main()
