#!/usr/bin/env python3
"""
Calculate character offsets and context for entities mentioned across all repository files.
Searches README, documentation, source code, and config files for entity mentions.
Updates JSON-LD entities with start_char_doc, end_char_doc, context, and path fields.
"""

import argparse
import json
import re
import os
from pathlib import Path
from typing import Dict, List, Tuple, Optional


class MultiFileOffsetCalculator:
    """Calculate offsets for entities across multiple repository files."""
    
    def __init__(self, repo_path: str):
        self.repo_path = Path(repo_path)
        self.file_cache = {}  # Cache file contents
        
    def get_searchable_files(self) -> List[Path]:
        """
        Get list of files to search for entity mentions.
        Prioritizes documentation and source files.
        """
        searchable_files = []
        
        # Priority 1: Documentation files
        doc_patterns = [
            "README.md", "README.rst", "README.txt",
            "CONTRIBUTING.md", "CHANGELOG.md", "HISTORY.md",
            "docs/**/*.md", "docs/**/*.rst", "docs/**/*.txt",
            "documentation/**/*.md"
        ]
        
        for pattern in doc_patterns:
            searchable_files.extend(self.repo_path.glob(pattern))
        
        # Priority 2: Python source files (main modules)
        py_patterns = [
            "*.py",
            "src/**/*.py",
            "lib/**/*.py",
            "**/main.py",
            "**/train.py",
            "**/model.py"
        ]
        
        for pattern in py_patterns:
            searchable_files.extend(self.repo_path.glob(pattern))
        
        # Priority 3: Config files
        config_patterns = [
            "*.yaml", "*.yml", "*.json",
            "config/**/*.yaml", "config/**/*.yml",
            "configs/**/*.yaml", "configs/**/*.yml"
        ]
        
        for pattern in config_patterns:
            searchable_files.extend(self.repo_path.glob(pattern))
        
        # Remove duplicates and sort by priority
        unique_files = list(set(searchable_files))
        
        # Sort: README first, then docs, then source, then config
        def sort_key(f):
            name = f.name.lower()
            if name.startswith('readme'):
                return (0, f)
            elif 'doc' in str(f).lower():
                return (1, f)
            elif f.suffix == '.py':
                return (2, f)
            else:
                return (3, f)
        
        return sorted(unique_files, key=sort_key)
    
    def read_file(self, file_path: Path) -> Optional[str]:
        """Read and cache file content."""
        if file_path in self.file_cache:
            return self.file_cache[file_path]
        
        try:
            content = file_path.read_text(encoding='utf-8', errors='ignore')
            self.file_cache[file_path] = content
            return content
        except Exception as e:
            print(f"  ⚠ Error reading {file_path}: {e}")
            return None
    
    def find_offset(self, text: str, search_str: str, start_pos: int = 0) -> Tuple[Optional[int], Optional[int]]:
        """Find character offset of a string in text."""
        idx = text.find(search_str, start_pos)
        if idx == -1:
            return None, None
        return idx, idx + len(search_str)
    
    def get_context(self, text: str, start: int, end: int, context_words: int = 5) -> Dict[str, str]:
        """Extract prefix and suffix context around a span."""
        if start is None or end is None:
            return {"prefix": "", "suffix": ""}
        
        # Get prefix
        prefix_start = max(0, start - 200)
        prefix = text[prefix_start:start].strip()
        prefix_words = prefix.split()[-context_words:]
        prefix_text = ' '.join(prefix_words)
        
        # Get suffix
        suffix_end = min(len(text), end + 200)
        suffix = text[end:suffix_end].strip()
        suffix_words = suffix.split()[:context_words]
        suffix_text = ' '.join(suffix_words)
        
        return {"prefix": prefix_text, "suffix": suffix_text}
    
    def generate_search_candidates(self, entity: Dict) -> List[str]:
        """Generate search strings for an entity based on its type."""
        entity_type = entity.get("@type", "")
        candidates = []
        
        if entity_type == "SoftwareRepository":
            if "name" in entity:
                candidates.append(entity["name"])
            if "url" in entity:
                candidates.append(entity["url"])
        
        elif entity_type == "MLS_Implementation":
            if "framework" in entity:
                candidates.append(entity["framework"])
            if "identifier" in entity:
                candidates.append(entity["identifier"])
            if "entryPoint" in entity:
                candidates.append(entity["entryPoint"])
        
        elif entity_type == "Environment":
            if "framework" in entity:
                candidates.append(entity["framework"])
            if "pythonVersion" in entity and entity["pythonVersion"]:
                candidates.append(f"Python {entity['pythonVersion']}")
                candidates.append(entity["pythonVersion"])
        
        elif entity_type == "MLS_HyperParameter":
            if "name" in entity:
                param_name = entity["name"]
                candidates.append(param_name)
                # Try variations
                candidates.append(param_name.replace("_", " "))
                candidates.append(param_name.replace("_", "-"))
                candidates.append(param_name.replace(".", "_"))
                # Try just the last part for nested params
                if "." in param_name:
                    candidates.append(param_name.split(".")[-1])
        
        elif entity_type == "Dependency":
            if "packageName" in entity:
                pkg = entity["packageName"]
                candidates.append(pkg)
                # Try import variations
                candidates.append(f"import {pkg}")
                candidates.append(f"from {pkg}")
        
        elif entity_type in ["TrainingRun", "EvaluationRun", "DataProcessingStep", "PredictionSet"]:
            if "description" in entity:
                desc = entity["description"]
                # Extract key phrases
                phrases = re.findall(r'\b[A-Z][a-z]+(?:\s+[A-Z][a-z]+)*\b', desc)
                candidates.extend(phrases[:3])
            if "identifier" in entity:
                candidates.append(entity["identifier"])
            if "codeReference" in entity and entity["codeReference"]:
                candidates.append(entity["codeReference"])
        
        # Remove empty and duplicate candidates
        return [c for c in list(set(candidates)) if c]
    
    def search_entity_in_files(self, entity: Dict, files: List[Path]) -> Tuple[Optional[Path], Optional[int], Optional[int], Dict[str, str]]:
        """
        Search for entity across multiple files.
        Returns: (file_path, start_offset, end_offset, context)
        """
        candidates = self.generate_search_candidates(entity)
        
        if not candidates:
            return None, None, None, {"prefix": "", "suffix": ""}
        
        # Search in each file
        for file_path in files:
            content = self.read_file(file_path)
            if not content:
                continue
            
            # Try each candidate
            for candidate in candidates:
                # Try exact match
                start, end = self.find_offset(content, candidate)
                if start is not None:
                    context = self.get_context(content, start, end)
                    return file_path, start, end, context
                
                # Try case-insensitive match
                pattern = re.compile(re.escape(candidate), re.IGNORECASE)
                match = pattern.search(content)
                if match:
                    start, end = match.start(), match.end()
                    context = self.get_context(content, start, end)
                    return file_path, start, end, context
        
        return None, None, None, {"prefix": "", "suffix": ""}
    
    def calculate_offsets(self, entities_file: str, output_path: str):
        """Calculate offsets for all entities."""
        print(f"Searching repository at {self.repo_path}...")
        
        # Get searchable files
        files = self.get_searchable_files()
        print(f"Found {len(files)} searchable files")
        
        # Read entities
        print(f"Reading entities from {entities_file}...")
        with open(entities_file, 'r', encoding='utf-8') as f:
            data = json.load(f)
        
        entities = data.get("@graph", [])
        updated_count = 0
        
        print(f"Calculating offsets for {len(entities)} entities...\n")
        
        for entity in entities:
            entity_id = entity.get("@id", "unknown")
            entity_type = entity.get("@type", "unknown")
            
            # Search for entity across files
            file_path, start, end, context = self.search_entity_in_files(entity, files)
            
            if file_path and start is not None:
                # Calculate relative path
                rel_path = file_path.relative_to(self.repo_path)
                
                # Update entity
                entity["start_char_doc"] = start
                entity["end_char_doc"] = end
                entity["context"] = context
                entity["path"] = str(rel_path)
                
                # Keep wasDerivedFrom as "code"
                if "wasDerivedFrom" not in entity:
                    entity["wasDerivedFrom"] = "code"
                
                updated_count += 1
                print(f"  ✓ {entity_type} ({entity_id})")
                print(f"    File: {rel_path}")
                print(f"    Offset: {start}-{end}")
            else:
                # Not found, keep defaults
                if "start_char_doc" not in entity:
                    entity["start_char_doc"] = 0
                if "end_char_doc" not in entity:
                    entity["end_char_doc"] = 0
                if "context" not in entity:
                    entity["context"] = {"prefix": "", "suffix": ""}
                if "path" not in entity:
                    entity["path"] = ""
        
        # Write updated entities
        print(f"\n✅ Updated {updated_count}/{len(entities)} entities with file offsets")
        
        with open(output_path, 'w', encoding='utf-8') as f:
            json.dump(data, f, indent=2, ensure_ascii=False)
        
        print(f"   Output written to: {output_path}")


def main():
    parser = argparse.ArgumentParser(
        description="Calculate character offsets for entities across repository files"
    )
    parser.add_argument(
        "--repo-path",
        required=True,
        help="Path to local repository"
    )
    parser.add_argument(
        "--entities-file",
        required=True,
        help="Path to JSON-LD entities file"
    )
    parser.add_argument(
        "--output",
        required=True,
        help="Path to write updated JSON-LD file"
    )
    
    args = parser.parse_args()
    
    # Validate repo path
    if not os.path.exists(args.repo_path):
        print(f"Error: Repository path does not exist: {args.repo_path}")
        return 1
    
    calculator = MultiFileOffsetCalculator(args.repo_path)
    calculator.calculate_offsets(args.entities_file, args.output)
    
    return 0


if __name__ == "__main__":
    exit(main())
