# Schema: Mermaid Class Diagram (Taxonomy v2)

This file contains the canonical Mermaid class diagram for the extraction schema. It defines all entities, attributes, relations, and the hyperparameter hierarchy.

```mermaid
---
config:
  layout: elk
  theme: mc
  look: handDrawn
---
classDiagram
direction TB

  class Study {
    +issued datetime
    +title string
    +abstract string
    +url URI
    +doi string
    +citation string
    +publicationVenue string
    +timestamp date
  }

  class Experiment {
    +description string
    +objective string
    +hypothesis string
    +methodology string
  }

  class Person {
    +name string
    +affiliation string
    +email string
    +orcid string
  }

  class Organization {
    +name string
    +url URI
    +type string
  }

  class MLS_Task {
    +name string
    +description string
    +category string
    +metrics string
  }

  class MLS_Dataset {
    +name string
    +description string
    +numInstances integer
    +language string
    +license string
    +modality string
    +numClasses integer
  }

  class DataSource {
    +name string
    +url URI
    +type string
    +license string
  }

  class Method {
    +name string
    +description string
    +version string
  }

  class MLS_Model {
    +architecture string
    +parameters string
  }

  class MLS_Algorithm {
    +complexity string
    +pseudoCode URI
  }

  class Prompt {
    +text string
    +role string
    +templateId string
    +usesContext boolean
  }

  class MLS_Eval {
    +measure string
    +hasValue float
    +stdDev float
    +confidenceInterval string
  }

  class SoftwareRepository {
    +name string
    +url URI
    +version string
    +programmingLanguage string
    +dateModified datetime
    +license string
    +documentationUrl URI
  }

  class MLS_Implementation {
    +codeRepository URI
    +framework string
    +executionCommand string
    +entryPoint string
    +branch string
  }

  class MLS_HyperParameter {
    +name URI
    +hasValue string
    +wasDerivedFrom string
    +type string
    +searchSpace string
  }

  class HP_Optimization
  class HP_Training
  class HP_Architecture
  class HP_Data
  MLS_HyperParameter -- HP_Optimization
  MLS_HyperParameter -- HP_Training
  MLS_HyperParameter -- HP_Architecture
  MLS_HyperParameter -- HP_Data

  class LearningRate
  class Momentum
  class WeightDecay
  class WarmupSteps
  class DecayRate
  HP_Optimization -- LearningRate
  HP_Optimization -- Momentum
  HP_Optimization -- WeightDecay
  HP_Optimization -- WarmupSteps
  HP_Optimization -- DecayRate

  class BatchSize
  class NumEpochs
  class MaxSteps
  class GradientAccumulationSteps
  class NumWorkers
  class RandomSeed
  HP_Training -- BatchSize
  HP_Training -- NumEpochs
  HP_Training -- MaxSteps
  HP_Training -- GradientAccumulationSteps
  HP_Training -- NumWorkers
  HP_Training -- RandomSeed

  class NumLayers
  class HiddenSize
  class EmbeddingDim
  class Dropout
  class AttentionHeads
  class UnknownArchitectureHP
  HP_Architecture -- NumLayers
  HP_Architecture -- HiddenSize
  HP_Architecture -- EmbeddingDim
  HP_Architecture -- Dropout
  HP_Architecture -- AttentionHeads

  class MaxSequenceLength
  class TrainValTestSplit
  HP_Data -- MaxSequenceLength
  HP_Data -- TrainValTestSplit

  Experiment "1" -- "0..*" MLS_HyperParameter : usesParameters

  Method <|-- MLS_Model
  Method <|-- MLS_Algorithm
  Method <|-- Prompt

  Study "1" -- "*" Person : hasAuthor
  Study "1" -- "1..*" Experiment : contains
  Study "1" -- "0..1" SoftwareRepository : implements
  Person "1" -- "*" Organization : prov-affiliatedWith

  Experiment "1" -- "1..*" MLS_Task : realizes
  Experiment "1" -- "1..*" MLS_Dataset : usesData
  Experiment "1" -- "1..*" Method : produces
  Experiment "1" -- "1..*" MLS_Implementation : executes

  MLS_Dataset "1" -- "0..*" MLS_Dataset : subDatasetOf
  MLS_Dataset "1" -- "1..*" DataSource : prov-derivedFrom
  MLS_Dataset "1" -- "1..*" DataProcessingStep : processedThrough
  DataProcessingStep "1" -- "1" DataSource : prov-uses

  Method "1" -- "1..*" MLS_Dataset : trainedOn
  Method "1" -- "1..*" MLS_Dataset : evaluatedOn
  Method "1" -- "1..*" MLS_Eval : achieves
  Method "1" -- "1..*" Method : subMethod

  SoftwareRepository "1" -- "1..*" MLS_Implementation : contains
  SoftwareRepository "1" -- "1..*" Environment : supports
  MLS_Implementation "1" -- "1" Environment : runsIn
  MLS_Implementation "1" -- "0..*" Dependency : requires


  MLS_Task "1" -- "1..*" MLS_Dataset : benchmarkedOn
  MLS_Task "1" -- "0..*" MLS_Task : subTaskOf
```
