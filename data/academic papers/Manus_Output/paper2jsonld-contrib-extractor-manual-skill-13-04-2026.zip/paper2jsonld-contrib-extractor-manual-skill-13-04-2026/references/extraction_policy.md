# Extraction Policy: ML/AI Scientific Paper Contributions (Comprehensive)

This policy defines the protocol for extracting structured information from scientific papers into a strict `@graph` JSON-LD format, adhering to the provided Mermaid class diagram schema.

## 1. Core Contribution Definition

Extract ONLY the entities and fields defined in the schema, and ONLY if they are part of the paper's novel contribution or directly support its understanding.

### ENTITIES TO INCLUDE (If present in contribution):
- **Study**: The paper itself, including title, abstract, authors, and publication details.
- **Person**: Authors of the paper, with their affiliations, ORCID, and email.
- **Organization**: Affiliations of the authors.
- **Experiment**: The main experimental setup, objectives, and methodology of the paper.
- **MLS_Task**: The machine learning task addressed (e.g., Hierarchical Text Classification).
- **MLS_Dataset**: Datasets used in the experiments, including statistics like number of instances and classes.
- **DataSource**: Original sources of the datasets (name, URL, type, license).
- **Method**: The proposed novel method and its sub-methods/models. Superclass of MLS_Model, MLS_Algorithm, and Prompt.
- **MLS_Model**: Specific models used or proposed (inherits from Method; adds architecture, parameters).
- **MLS_Algorithm**: If a specific algorithm is detailed with complexity or pseudocode (inherits from Method).
- **Prompt**: If prompt engineering is a core contribution (inherits from Method; adds text, role, templateId, usesContext).
- **MLS_Eval**: Evaluation metrics and their corresponding values for the proposed method, broken down by dataset.
- **SoftwareRepository**: Link to the code repository.
- **MLS_Implementation**: Details about the software implementation (framework, commit hash, etc.).
- **Dependency**: Software dependencies of the implementation.
- **Environment**: Computational infrastructure and software stack.
- **MLS_HyperParameter**: Training, optimization, architecture, and data configuration parameters. MUST be typed using the HP hierarchy (see Section 2).
- **DataProcessingStep**: Novel data processing steps that are part of the contribution.
- **TrainingRun**: Details of the training process.
- **EvaluationRun**: Details of the evaluation process.
- **PredictionSet**: If prediction outputs are a core contribution.

### EXCLUDE:
- **Baselines & Prior Work**: Methods, models, or datasets used only for comparison, unless directly modified or integrated as a novel part of the contribution.
- **SOTA Tables**: Do not extract results for models the authors did not propose.
- **Ablations**: Exclude variants unless an ablation reveals a specific sub-method that is a primary contribution.

## 2. Hyperparameter Hierarchy and Classification

The schema defines a **typed hyperparameter hierarchy**. Every extracted `MLS_HyperParameter` entity MUST be classified into exactly one leaf type under one of four categories.

### 2.1 Hierarchy Definition

```
MLS_HyperParameter
├── HP_Optimization          (optimizer and learning rate schedule parameters)
│   ├── LearningRate
│   ├── Momentum
│   ├── WeightDecay
│   ├── WarmupSteps
│   └── DecayRate
├── HP_Training              (training loop and execution parameters)
│   ├── BatchSize
│   ├── NumEpochs
│   ├── MaxSteps
│   ├── GradientAccumulationSteps
│   ├── NumWorkers
│   └── RandomSeed
├── HP_Architecture          (model architecture parameters)
│   ├── NumLayers
│   ├── HiddenSize
│   ├── EmbeddingDim
│   ├── Dropout
│   ├── AttentionHeads
│   └── UnknownArchitectureHP
└── HP_Data                  (data preprocessing and splitting parameters)
    ├── MaxSequenceLength
    └── TrainValTestSplit
```

### 2.2 Alias Lookup Table

Each leaf type has known aliases. Use case-insensitive matching.

| Leaf Type | Aliases |
|-----------|---------|
| LearningRate | lr, learning_rate, initial_lr, base_lr, peak_lr, lr_init |
| Momentum | momentum, sgd_momentum, beta1, beta2, betas |
| WeightDecay | weight_decay, wd, l2_reg, l2_penalty, lambda, λ |
| WarmupSteps | warmup_steps, warmup, num_warmup_steps, warmup_ratio, warmup_epochs, warmup_proportion |
| DecayRate | decay_rate, lr_decay, lr_decay_rate, decay_factor, lr_scheduler_decay, step_decay |
| BatchSize | batch_size, train_batch_size, per_device_train_batch_size, micro_batch, eval_batch_size |
| NumEpochs | num_epochs, epochs, num_train_epochs, max_epochs, n_epochs, training_epochs |
| MaxSteps | max_steps, total_steps, training_steps, max_train_steps, total_training_steps |
| GradientAccumulationSteps | gradient_accumulation_steps, accum_steps, grad_accum, accumulation_steps |
| NumWorkers | num_workers, dataloader_num_workers, n_workers, workers |
| RandomSeed | seed, random_seed, manual_seed, torch_seed, np_seed |
| NumLayers | num_layers, n_layers, num_hidden_layers, depth, encoder_layers, decoder_layers, "N-layer" |
| HiddenSize | hidden_size, d_model, hidden_dim, intermediate_size, d_ff, ffn_dim |
| EmbeddingDim | embedding_dim, embed_dim, d_embed, word_embedding_dim, token_embedding_dim |
| Dropout | dropout, dropout_rate, drop_rate, attention_dropout, hidden_dropout, classifier_dropout |
| AttentionHeads | num_attention_heads, n_heads, num_heads, nhead, attention_heads |
| UnknownArchitectureHP | (fallback for architecture HPs not matching above leaves) |
| MaxSequenceLength | max_seq_length, max_length, max_seq_len, max_position_embeddings, max_tokens, seq_len |
| TrainValTestSplit | train_split, val_split, test_split, split_ratio, train_size, val_size, test_size |

### 2.3 Classification Rules

1. **Exact alias match**: Match parameter name against the alias lookup table (case-insensitive). If matched, assign the corresponding leaf type.
2. **Semantic match**: If no exact alias match, classify by semantic meaning. For example, "λ" used for regularization → `WeightDecay`; "patience" for scheduler → `DecayRate` (or `HP_Optimization` category); "label_smoothing" → `HP_Training` category.
3. **Architecture fallback**: If a hyperparameter is clearly architectural (relates to model structure) but matches no specific leaf → `UnknownArchitectureHP`.
4. **Category fallback**: If a hyperparameter matches no leaf at all, set `"hpType"` to the best-fit category name (e.g., `"HP_Optimization"`) and add `"uncertain": true`.
5. **Multi-value HPs**: If a single parameter name maps to multiple values (e.g., per-dataset or per-experiment), create one entity per value with dataset/experiment context in the `@id` and `mls:name`.

### 2.4 JSON-LD Template for Typed Hyperparameters

Each hyperparameter MUST follow this template:

```json
{
  "@id": "hp_learning_rate_encoder",
  "@type": "MLS_HyperParameter",
  "mls:name": "http://example.org/hp/learning_rate",
  "mls:hasValue": "5e-5",
  "mls:wasDerivedFrom": "paper",
  "mls:type": "float",
  "mls:searchSpace": null,
  "hpCategory": "HP_Optimization",
  "hpType": "LearningRate",
  "uncertain": false,
  "start_char_doc": 1234,
  "end_char_doc": 1238,
  "wasDerivedFrom": "paper",
  "context": { "prefix": "We set the", "suffix": "for the encoder" }
}
```

**Required fields for every MLS_HyperParameter**:
- `"hpCategory"`: One of `HP_Optimization`, `HP_Training`, `HP_Architecture`, `HP_Data`.
- `"hpType"`: The leaf class name (e.g., `LearningRate`, `BatchSize`, `NumLayers`, `MaxSequenceLength`, `UnknownArchitectureHP`). If no leaf matches, use the category name.
- `"uncertain"`: Boolean. Set to `true` if classification is uncertain.

### 2.5 Hyperparameter Extraction from Paper Text

Scan the `PAPER_MD` for ALL hyperparameter mentions using these patterns:

**A. Explicit assignments**: "learning rate = 1e-3", "batch size of 32", "dropout set to 0.1", "λ = 0.01"
**B. Implicit mentions**: "we use Adam", "BERT-base with 12 layers", "a two-layer GCN", "trained for 50 epochs"
**C. Table content**: Hyperparameter tables, training configuration tables, experimental setup tables
**D. Inline parentheticals**: "(lr = 1e-4)", "(hidden size 768)", "(d_model = 512)"
**E. Architecture descriptions**: "12-layer Transformer", "768-dimensional hidden states", "8 attention heads"

For each candidate:
1. Extract the full text span.
2. Classify using the hierarchy (Section 2.3).
3. Calculate character offsets using `scripts/calculate_offsets.py`.
4. Capture prefix/suffix context.



## 3. Repository-Level Extraction Scope (if REPO_LINK provided)

### 3.1 Repository Metadata Extraction

Extract from the repository:
- **URL**, **Repository Name**, **Owner**, **Platform**, **Version/Release Tag**, **License**, **Last Modification Date**, **Programming Language**, **Description**.
- Create a `SoftwareRepository` entity and link to `MLS_Implementation` via `codeRepository`.


## 4. Evidence & Character Offsets

Every extracted entity MUST include character offsets and context, calculated using `scripts/calculate_offsets.py`:
- **start_char_doc**: 0-indexed character offset of the entity name/mention.
- **end_char_doc**: 0-indexed character offset.
- **wasDerivedFrom**: "paper" for paper-extracted entities, "code" for repository-extracted entities, "paper_and_code" for entities found in both.
- **context**: { "prefix": "up to 5 words", "suffix": "up to 5 words" }

For repository-extracted entities:
- **start_char_doc** and **end_char_doc**: Set to `null` if extracted from repository files only.
- **wasDerivedFrom**: Set to "code".

For SoftwareRepository entities created from REPO_LINK input:
- **start_char_doc** and **end_char_doc**: Set to `null`.
- **wasDerivedFrom**: Set to "external_input".

## 5. Provenance Relations

When repository entities are extracted, establish provenance relations using W3C PROV vocabulary:
- **prov:wasGeneratedBy**: Link generated artifacts (predictions, logs) to their generating runs.
- **prov:wasDerivedFrom**: Link repository entities to their source files.
- **prov:wasAssociatedWith**: Link runs to their associated hyperparameters and dependencies.
- **prov:used**: Link runs to the datasets and models they used.

## 6. Formatting & Data Integrity

- **Strict JSON-LD @graph**: Output must be a single JSON object with `@context` and `@graph`.
- **Schema Adherence**: Strictly follow the entity, attribute, and relation definitions from the provided Mermaid class diagram.
- **Typed Hyperparameters**: Every `MLS_HyperParameter` MUST include `hpCategory` and `hpType` fields.
- **Forced Inclusion**: If a mandatory entity is not explicitly detailed, create the entity with a unique @id and set its specific fields to `null`.
- **Verbatim Naming**: Use the paper's exact wording for names/titles. For repository entities, use names as they appear in source files.
- **No Hallucinations**: Use `null` for missing fields; do not invent data.
- **Relations**: Ensure all relations specified in the Mermaid class diagram are correctly represented using @id references.
- **Repository Entity Linking**: All repository-extracted entities MUST be explicitly linked to paper entities via appropriate relations.
- **Deduplication**: If a hyperparameter or dependency appears in both paper and repository, extract once and mark source as "paper_and_code".
