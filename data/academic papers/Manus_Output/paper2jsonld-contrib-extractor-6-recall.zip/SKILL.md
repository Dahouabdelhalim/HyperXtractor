---
name: paper2jsonld-contrib-extractor
description: "Extract ALL contribution-related entities from ML/AI scientific papers in Markdown into STRICT JSON-LD using a comprehensive schema (Mermaid class diagram). Includes character offsets, prefix/suffix context, and full attribute extraction for Study, Experiment, Person, Organization, MLS_Task, MLS_Dataset, Method, MLS_Model, MLS_Eval, MLS_Implementation, Environment, and MLS_HyperParameter."
---

# paper2jsonld-contrib-extractor

Expert information-extraction system for ML/AI scientific papers. This skill extracts all entities and fields defined in the comprehensive schema that are part of a paper's core contribution and formats them into strict JSON-LD with character-level precision.

## Runtime Inputs (Mandatory)

Before proceeding, you MUST obtain the following from the user:
1. **PAPER_MD**: The full scientific paper content in Markdown.
2. **SCHEMA_TEXT**: A plain-text schema and extraction policy.

## Workflow

### Hyperparameter Extraction Strategy (High Recall)

To achieve high recall for hyperparameter extraction, the skill employs a multi-step, framework-aware strategy:

1.  **Paper-Driven Candidates**: Scan the `PAPER_MD` for any spans that resemble hyperparameters. This includes explicit assignments (e.g., "learning rate = 1e-3", "batch size of 32", "dropout set to 0.1"), implicit mentions (e.g., "we use Adam", "BERT-base with 12 layers", "a two-layer GCN", "trained for 50 epochs"), table headers and captions (e.g., "Hyperparameters", "Training details", "Experimental setup"), and inline parentheticals (e.g., "(lr = 1e-4)", "(hidden size 768)"). Extract the full text span as a candidate.

2.  **Framework-Aware Matching**: For each candidate, identify the referenced framework or component (e.g., PyTorch, TensorFlow/Keras, Hugging Face Transformers). Internally consult framework documentation knowledge to check if the candidate matches constructor arguments, optimizer parameters, scheduler parameters, or model configuration fields. If a match is found, extract it as a hyperparameter.

3.  **Pattern & Alias Expansion**: Perform alias normalization and pattern expansion. This includes mapping synonyms (e.g., "lr" → "learning_rate", "wd" → "weight_decay", "λ" → "lambda", "dim" → "hidden_size" / "embedding_dim"), recognizing numeric patterns (e.g., scientific notation, ranges, lists), and architecture counts (e.g., "two-layer", "12-layer", "3 heads"). These must be treated as hyperparameters even if not explicitly labeled.

If unsure about a hyperparameter, extract it and mark it with `"uncertain": true`.



1.  **Analyze Inputs**: Read the `PAPER_MD` and `SCHEMA_TEXT`.
2.  **Map Schema**: Interpret the provided Mermaid class diagram to understand the entities, their attributes, and relations for JSON-LD structuring. Pay special attention to the `MLS_HyperParameter` entity and its attributes to ensure high recall as per the strategy outlined above.
3.  **Extract Entities**: Identify all schema-compliant entities belonging to the core contribution. Consult `/home/ubuntu/skills/paper2jsonld-contrib-extractor/references/extraction_policy.md` for detailed definitions and rules.
4.  **Calculate Offsets**: For every extracted entity, use the `scripts/calculate_offsets.py` script to determine its `start_char_doc` and `end_char_doc` offsets within the original `PAPER_MD`.
5.  **Capture Context**: Extract the `prefix` and `suffix` (up to 5 words each) surrounding the entity name/mention.
6.  **Format Output**: Structure the data using the `@graph` template and `@context` derived from the provided `SCHEMA_TEXT`.
7.  **Final Self-Check**:
    - Confirm the output is valid JSON-LD with `@context` and `@graph`.
    - Confirm ALL relevant entities and their attributes, as defined in the `SCHEMA_TEXT`, are present, including specific measures and values for MLS_Eval entities per dataset.
    - Confirm every entity has accurate character offsets and prefix/suffix context, as calculated by `scripts/calculate_offsets.py`.
    - Confirm all relations specified in the `SCHEMA_TEXT` are correctly represented.
8.  **Deliver Result**: Return the JSON object ONLY.

## Usage Guidelines

- **Strict JSON-LD @graph**: Output must be a single JSON object containing the `@context` and `@graph` array.
- **Comprehensive Extraction**: Extract all entities and attributes specified in the provided `SCHEMA_TEXT`.
- **Character Precision**: Offsets must be accurate to the provided Markdown text.
- **No Hallucinations**: Use `null` for missing fields; do not invent data.
- **Schema Adherence**: Strictly follow the entity, attribute, and relation definitions from the `SCHEMA_TEXT`.
