# Output Schema and Skeleton (Comprehensive)

## JSON-LD Context
The output MUST include the following `@context` derived from the Mermaid class diagram:
```json
{
  "@context": {
    "mls": "http://example.org/ontology/mls#",
    "schema": "http://schema.org/",
    "xsd": "http://www.w3.org/2001/XMLSchema#",
    "rdfs": "http://www.w3.org/2000/01/rdf-schema#",
    "prov": "http://www.w3.org/ns/prov#",
    "Study": "mls:Study",
    "Experiment": "mls:Experiment",
    "Person": "mls:Person",
    "Organization": "mls:Organization",
    "MLS_Task": "mls:MLS_Task",
    "MLS_Dataset": "mls:MLS_Dataset",
    "DataSource": "mls:DataSource",
    "Method": "mls:Method",
    "MLS_Model": "mls:MLS_Model",
    "MLS_Algorithm": "mls:MLS_Algorithm",
    "Prompt": "mls:Prompt",
    "MLS_Eval": "mls:MLS_Eval",
    "SoftwareRepository": "mls:SoftwareRepository",
    "MLS_Implementation": "mls:MLS_Implementation",
    "MLS_HyperParameter": "mls:MLS_HyperParameter",
    "Dependency": "mls:Dependency",
    "Environment": "mls:Environment",
    "DataProcessingStep": "mls:DataProcessingStep",
    "TrainingRun": "mls:TrainingRun",
    "EvaluationRun": "mls:EvaluationRun",
    "PredictionSet": "mls:PredictionSet",
    "issued": { "@id": "mls:issued", "@type": "xsd:datetime" },
    "title": "schema:title",
    "abstract": "schema:abstract",
    "url": "schema:url",
    "doi": "schema:doi",
    "citation": "schema:citation",
    "publicationVenue": "schema:publicationVenue",
    "timestamp": { "@id": "schema:timestamp", "@type": "xsd:date" },
    "identifier": "schema:identifier",
    "description": "schema:description",
    "objective": "schema:objective",
    "hypothesis": "schema:hypothesis",
    "methodology": "schema:methodology",
    "name": "schema:name",
    "affiliation": "schema:affiliation",
    "email": "schema:email",
    "orcid": "schema:orcid",
    "type": "schema:type",
    "category": "schema:category",
    "metrics": "schema:metrics",
    "numInstances": { "@id": "schema:numInstances", "@type": "xsd:integer" },
    "language": "schema:language",
    "license": "schema:license",
    "modality": "schema:modality",
    "numClasses": { "@id": "schema:numClasses", "@type": "xsd:integer" },
    "version": "schema:version",
    "architecture": "schema:architecture",
    "parameters": "schema:parameters",
    "complexity": "mls:complexity",
    "pseudoCode": { "@id": "mls:pseudoCode", "@type": "xsd:anyURI" },
    "text": "schema:text",
    "role": "mls:role",
    "templateId": "mls:templateId",
    "usesContext": { "@id": "mls:usesContext", "@type": "xsd:boolean" },
    "measure": "mls:measure",
    "hasValue": { "@id": "mls:hasValue", "@type": "xsd:float" },
    "stdDev": { "@id": "mls:stdDev", "@type": "xsd:float" },
    "confidenceInterval": "mls:confidenceInterval",
    "programmingLanguage": "schema:programmingLanguage",
    "dateModified": { "@id": "schema:dateModified", "@type": "xsd:datetime" },
    "documentationUrl": { "@id": "mls:documentationUrl", "@type": "xsd:anyURI" },
    "codeRepository": { "@id": "mls:codeRepository", "@type": "xsd:anyURI" },
    "framework": "mls:framework",
    "dependencies": "mls:dependencies",
    "executionCommand": "mls:executionCommand",
    "entryPoint": "mls:entryPoint",
    "commitHash": "mls:commitHash",
    "branch": "mls:branch",
    "dependenciesHash": "mls:dependenciesHash",
    "packageName": "mls:packageName",
    "isOptional": { "@id": "mls:isOptional", "@type": "xsd:boolean" },
    "hardwareSpecs": "mls:hardwareSpecs",
    "os": "mls:os",
    "pythonVersion": "mls:pythonVersion",
    "requirementsFile": "mls:requirementsFile",
    "isDockerized": { "@id": "mls:isDockerized", "@type": "xsd:boolean" },
    "startedAtTime": { "@id": "prov:startedAtTime", "@type": "xsd:datetime" },
    "endedAtTime": { "@id": "prov:endedAtTime", "@type": "xsd:datetime" },
    "transformationType": "mls:transformationType",
    "codeReference": { "@id": "mls:codeReference", "@type": "xsd:anyURI" },
    "runId": "mls:runId",
    "logFile": { "@id": "mls:logFile", "@type": "xsd:anyURI" },
    "split": "mls:split",
    "numInstances": { "@id": "mls:numInstances", "@type": "xsd:integer" },
    "onDatasetSplit": "mls:onDatasetSplit",
    "format": "mls:format",
    "artifactsLocation": { "@id": "mls:artifactsLocation", "@type": "xsd:anyURI" },

    "hasAuthor": { "@id": "mls:hasAuthor", "@type": "@id" },
    "contains": { "@id": "mls:contains", "@type": "@id" },
    "implements": { "@id": "mls:implements", "@type": "@id" },
    "prov-affiliatedWith": { "@id": "mls:prov-affiliatedWith", "@type": "@id" },
    "realizes": { "@id": "mls:realizes", "@type": "@id" },
    "usesData": { "@id": "mls:usesData", "@type": "@id" },
    "produces": { "@id": "mls:produces", "@type": "@id" },
    "usesParameters": { "@id": "mls:usesParameters", "@type": "@id" },
    "executes": { "@id": "mls:executes", "@type": "@id" },
    "subDatasetOf": { "@id": "mls:subDatasetOf", "@type": "@id" },
    "prov-derivedFrom": { "@id": "mls:prov-derivedFrom", "@type": "@id" },
    "processedThrough": { "@id": "mls:processedThrough", "@type": "@id" },
    "prov-uses": { "@id": "mls:prov-uses", "@type": "@id" },
    "trainedOn": { "@id": "mls:trainedOn", "@type": "@id" },
    "evaluatedOn": { "@id": "mls:evaluatedOn", "@type": "@id" },
    "achieves": { "@id": "mls:achieves", "@type": "@id" },
    "prov-producedBy": { "@id": "mls:prov-producedBy", "@type": "@id" },
    "subMethod": { "@id": "mls:subMethod", "@type": "@id" },
    "evaluates": { "@id": "mls:evaluates", "@type": "@id" },
    "supports": { "@id": "mls:supports", "@type": "@id" },
    "runsIn": { "@id": "mls:runsIn", "@type": "@id" },
    "requires": { "@id": "mls:requires", "@type": "@id" },
    "prov-executedBy": { "@id": "mls:prov-executedBy", "@type": "@id" },
    "prov-generated": { "@id": "mls:prov-generated", "@type": "@id" },
    "benchmarkedOn": { "@id": "mls:benchmarkedOn", "@type": "@id" },
    "subTaskOf": { "@id": "mls:subTaskOf", "@type": "@id" }
  },
  "@graph": []
}
```

## Entity Templates

Below are examples of how entities should be structured. If details are missing, include these with `null` fields.

### Study
```json
{
  "@id": "study_id",
  "@type": "Study",
  "schema:title": "Paper Title",
  "schema:abstract": "Abstract content...",
  "schema:url": "https://arxiv.org/abs/xxxx.xxxxx",
  "schema:doi": null,
  "schema:citation": null,
  "schema:publicationVenue": null,
  "schema:timestamp": null,
  "hasAuthor": [ { "@id": "person_id" } ],
  "contains": [ { "@id": "experiment_id" } ],
  "implements": { "@id": "software_repo_id" },
  "start_char_doc": 0,
  "end_char_doc": 0,
  "wasDerivedFrom": "paper",
  "context": { "prefix": "", "suffix": "" }
}
```

### Experiment
```json
{
  "@id": "experiment_id",
  "@type": "Experiment",
  "schema:identifier": "Experiment Name",
  "schema:description": "Description of the experiment",
  "schema:objective": null,
  "schema:hypothesis": null,
  "schema:methodology": null,
  "realizes": [ { "@id": "mls_task_id" } ],
  "usesData": [ { "@id": "mls_dataset_id" } ],
  "produces": [ { "@id": "method_id" } ],
  "usesParameters": [ { "@id": "mls_hyperparameter_id" } ],
  "executes": [ { "@id": "mls_implementation_id" } ],
  "start_char_doc": 0,
  "end_char_doc": 0,
  "wasDerivedFrom": "paper",
  "context": { "prefix": "", "suffix": "" }
}
```

### Person
```json
{
  "@id": "person_id",
  "@type": "Person",
  "schema:name": "Person Name",
  "schema:affiliation": null,
  "schema:email": null,
  "schema:orcid": null,
  "prov-affiliatedWith": [ { "@id": "organization_id" } ],
  "start_char_doc": 0,
  "end_char_doc": 0,
  "wasDerivedFrom": "paper",
  "context": { "prefix": "", "suffix": "" }
}
```

### Organization
```json
{
  "@id": "organization_id",
  "@type": "Organization",
  "schema:name": "Organization Name",
  "schema:url": null,
  "schema:type": null,
  "start_char_doc": 0,
  "end_char_doc": 0,
  "wasDerivedFrom": "paper",
  "context": { "prefix": "", "suffix": "" }
}
```

### MLS_Task
```json
{
  "@id": "mls_task_id",
  "@type": "MLS_Task",
  "schema:name": "Task Name",
  "schema:description": "Description of the task",
  "schema:category": null,
  "schema:metrics": null,
  "benchmarkedOn": [ { "@id": "mls_dataset_id" } ],
  "subTaskOf": [ { "@id": "parent_mls_task_id" } ],
  "start_char_doc": 0,
  "end_char_doc": 0,
  "wasDerivedFrom": "paper",
  "context": { "prefix": "", "suffix": "" }
}
```

### MLS_Dataset
```json
{
  "@id": "mls_dataset_id",
  "@type": "MLS_Dataset",
  "schema:name": "Dataset Name",
  "schema:description": null,
  "schema:numInstances": null,
  "schema:language": null,
  "schema:license": null,
  "schema:modality": null,
  "schema:numClasses": null,
  "subDatasetOf": [ { "@id": "parent_mls_dataset_id" } ],
  "prov-derivedFrom": [ { "@id": "data_source_id" } ],
  "processedThrough": [ { "@id": "data_processing_step_id" } ],
  "start_char_doc": 0,
  "end_char_doc": 0,
  "wasDerivedFrom": "paper",
  "context": { "prefix": "", "suffix": "" }
}
```

### DataSource
```json
{
  "@id": "data_source_id",
  "@type": "DataSource",
  "schema:name": "Data Source Name",
  "schema:url": null,
  "schema:type": null,
  "schema:license": null,
  "start_char_doc": 0,
  "end_char_doc": 0,
  "wasDerivedFrom": "paper",
  "context": { "prefix": "", "suffix": "" }
}
```

### Method
```json
{
  "@id": "method_id",
  "@type": "Method",
  "schema:name": "Method Name",
  "schema:description": null,
  "schema:version": null,
  "trainedOn": [ { "@id": "mls_dataset_id" } ],
  "evaluatedOn": [ { "@id": "mls_dataset_id" } ],
  "achieves": [ { "@id": "mls_eval_id" } ],
  "prov-producedBy": { "@id": "training_run_id" },
  "subMethod": [ { "@id": "sub_method_id" } ],
  "start_char_doc": 0,
  "end_char_doc": 0,
  "wasDerivedFrom": "paper",
  "context": { "prefix": "", "suffix": "" }
}
```

### MLS_Model
```json
{
  "@id": "mls_model_id",
  "@type": "MLS_Model",
  "schema:name": "Model Name",
  "schema:architecture": null,
  "schema:parameters": null,
  "start_char_doc": 0,
  "end_char_doc": 0,
  "wasDerivedFrom": "paper",
  "context": { "prefix": "", "suffix": "" }
}
```

### MLS_Algorithm
```json
{
  "@id": "mls_algorithm_id",
  "@type": "MLS_Algorithm",
  "schema:name": "Algorithm Name",
  "mls:complexity": null,
  "mls:pseudoCode": null,
  "start_char_doc": 0,
  "end_char_doc": 0,
  "wasDerivedFrom": "paper",
  "context": { "prefix": "", "suffix": "" }
}
```

### Prompt
```json
{
  "@id": "prompt_id",
  "@type": "Prompt",
  "schema:text": "Prompt text",
  "mls:role": null,
  "mls:templateId": null,
  "mls:usesContext": null,
  "start_char_doc": 0,
  "end_char_doc": 0,
  "wasDerivedFrom": "paper",
  "context": { "prefix": "", "suffix": "" }
}
```

### MLS_Eval
```json
{
  "@id": "mls_eval_id",
  "@type": "MLS_Eval",
  "mls:measure": "Metric Name",
  "mls:hasValue": null,
  "mls:stdDev": null,
  "mls:confidenceInterval": null,
  "mls:onDataset": { "@id": "mls_dataset_id" },
  "prov-producedBy": { "@id": "evaluation_run_id" },
  "start_char_doc": 0,
  "end_char_doc": 0,
  "wasDerivedFrom": "paper",
  "context": { "prefix": "", "suffix": "" }
}
```

### SoftwareRepository
```json
{
  "@id": "software_repo_id",
  "@type": "SoftwareRepository",
  "schema:name": "Repository Name",
  "schema:url": "https://github.com/user/repo",
  "schema:version": null,
  "schema:programmingLanguage": null,
  "schema:dateModified": null,
  "schema:license": null,
  "schema:documentationUrl": null,
  "contains": [ { "@id": "mls_implementation_id" } ],
  "supports": [ { "@id": "environment_id" } ],
  "start_char_doc": 0,
  "end_char_doc": 0,
  "wasDerivedFrom": "paper",
  "context": { "prefix": "", "suffix": "" }
}
```

### MLS_Implementation
```json
{
  "@id": "mls_implementation_id",
  "@type": "MLS_Implementation",
  "schema:identifier": "Implementation Identifier",
  "mls:codeRepository": "https://github.com/user/repo",
  "mls:framework": null,
  "mls:dependencies": null,
  "mls:executionCommand": null,
  "mls:entryPoint": null,
  "mls:commitHash": null,
  "mls:branch": null,
  "mls:dependenciesHash": null,
  "runsIn": { "@id": "environment_id" },
  "requires": [ { "@id": "dependency_id" } ],
  "start_char_doc": 0,
  "end_char_doc": 0,
  "wasDerivedFrom": "paper",
  "context": { "prefix": "", "suffix": "" }
}
```

### MLS_HyperParameter
```json
{
  "@id": "mls_hyperparameter_id",
  "@type": "MLS_HyperParameter",
  "schema:name": "http://example.org/hp/parameter_name",
  "mls:hasValue": "value",
  "mls:wasDerivedFrom": null,
  "mls:type": null,
  "mls:searchSpace": null,
  "start_char_doc": 0,
  "end_char_doc": 0,
  "wasDerivedFrom": "paper",
  "context": { "prefix": "", "suffix": "" }
}
```

### Dependency
```json
{
  "@id": "dependency_id",
  "@type": "Dependency",
  "mls:packageName": "Package Name",
  "mls:version": null,
  "mls:type": null,
  "mls:isOptional": null,
  "start_char_doc": 0,
  "end_char_doc": 0,
  "wasDerivedFrom": "paper",
  "context": { "prefix": "", "suffix": "" }
}
```

### Environment
```json
{
  "@id": "environment_id",
  "@type": "Environment",
  "schema:name": "Environment Name",
  "schema:description": null,
  "mls:hardwareSpecs": null,
  "mls:os": null,
  "mls:pythonVersion": null,
  "mls:requirementsFile": null,
  "mls:isDockerized": null,
  "start_char_doc": 0,
  "end_char_doc": 0,
  "wasDerivedFrom": "paper",
  "context": { "prefix": "", "suffix": "" }
}
```

### DataProcessingStep
```json
{
  "@id": "data_processing_step_id",
  "@type": "DataProcessingStep",
  "schema:id": "Step ID",
  "prov:startedAtTime": null,
  "prov:endedAtTime": null,
  "schema:description": null,
  "mls:transformationType": null,
  "mls:parameters": null,
  "mls:codeReference": null,
  "prov-uses": { "@id": "data_source_id" },
  "start_char_doc": 0,
  "end_char_doc": 0,
  "wasDerivedFrom": "paper",
  "context": { "prefix": "", "suffix": "" }
}
```

### TrainingRun
```json
{
  "@id": "training_run_id",
  "@type": "TrainingRun",
  "mls:runId": "Run ID",
  "prov:startedAtTime": null,
  "prov:endedAtTime": null,
  "mls:codeReference": null,
  "mls:logFile": null,
  "prov-executedBy": { "@id": "mls_implementation_id" },
  "prov-uses": { "@id": "mls_dataset_id" },
  "start_char_doc": 0,
  "end_char_doc": 0,
  "wasDerivedFrom": "paper",
  "context": { "prefix": "", "suffix": "" }
}
```

### EvaluationRun
```json
{
  "@id": "evaluation_run_id",
  "@type": "EvaluationRun",
  "mls:runId": "Run ID",
  "prov:startedAtTime": null,
  "prov:endedAtTime": null,
  "mls:split": null,
  "mls:codeReference": null,
  "prov-executedBy": { "@id": "mls_implementation_id" },
  "prov-generated": [ { "@id": "prediction_set_id" } ],
  "evaluates": { "@id": "method_id" },
  "start_char_doc": 0,
  "end_char_doc": 0,
  "wasDerivedFrom": "paper",
  "context": { "prefix": "", "suffix": "" }
}
```

### PredictionSet
```json
{
  "@id": "prediction_set_id",
  "@type": "PredictionSet",
  "schema:id": "Prediction Set ID",
  "mls:numInstances": null,
  "mls:onDatasetSplit": null,
  "mls:format": null,
  "mls:artifactsLocation": null,
  "start_char_doc": 0,
  "end_char_doc": 0,
  "wasDerivedFrom": "paper",
  "context": { "prefix": "", "suffix": "" }
}
```
