# Extraction Policy: ML/AI Scientific Paper Contributions (Comprehensive)

This policy defines the protocol for extracting structured information from scientific papers into a strict `@graph` JSON-LD format, adhering to the provided Mermaid class diagram schema.

## 1. Core Contribution Definition
Extract ONLY the entities and fields defined in the schema, and ONLY if they are part of the paper’s novel contribution or directly support its understanding.

### ENTITIES TO INCLUDE (If present in contribution):
- **Study**: The paper itself, including title, abstract, authors, and publication details.
- **Person**: Authors of the paper, with their affiliations, ORCID, and email.
- **Organization**: Affiliations of the authors.
- **Experiment**: The main experimental setup, objectives, and methodology of the paper.
- **MLS_Task**: The machine learning task addressed (e.g., Hierarchical Text Classification).
- **MLS_Dataset**: Datasets used in the experiments, including statistics like number of instances and classes.
- **DataSource**: Original sources of the datasets.
- **Method**: The proposed novel method (e.g., RADAr) and its sub-methods/models.
- **MLS_Model**: Specific models used or proposed (e.g., RoBERTa base, custom autoregressive decoder).
- **MLS_Algorithm**: If a specific algorithm is detailed with complexity or pseudocode.
- **Prompt**: If prompt engineering is a core contribution.
- **MLS_Eval**: Evaluation metrics and their corresponding values for the proposed method, broken down by dataset.
- **SoftwareRepository**: Link to the code repository.
- **MLS_Implementation**: Details about the software implementation (e.g., framework, commit hash).
- **Dependency**: Software dependencies of the implementation.
- **Environment**: Computational infrastructure and software stack (e.g., hardware, OS, Python version).
-### MLS_HyperParameter
- **High Recall Strategy**: Prioritize high recall for hyperparameter extraction. It is acceptable to extract borderline or uncertain hyperparameters.
- **Paper-Driven Candidates**: Extract any spans that look like hyperparameters, including explicit assignments (e.g., "learning rate = 1e-3", "batch size of 32", "dropout set to 0.1"), implicit mentions (e.g., "we use Adam", "BERT-base with 12 layers", "a two-layer GCN", "trained for 50 epochs"), table headers and captions (e.g., "Hyperparameters", "Training details", "Experimental setup"), and inline parentheticals (e.g., "(lr = 1e-4)", "(hidden size 768)").
- **Framework-Aware Matching**: Identify the referenced framework or component (e.g., PyTorch, TensorFlow/Keras, Hugging Face Transformers). Internally consult framework documentation knowledge to check if the candidate matches constructor arguments, optimizer parameters, scheduler parameters, or model configuration fields. If a match is found, extract it.
- **Pattern & Alias Expansion**: Perform alias normalization (e.g., "lr" → "learning_rate", "wd" → "weight_decay", "λ" → "lambda", "dim" → "hidden_size" / "embedding_dim"), recognize numeric patterns (e.g., scientific notation, ranges, lists), and architecture counts (e.g., "two-layer", "12-layer", "3 heads").
- **Uncertainty Marking**: If unsure about a hyperparameter, extract it and mark it with `"uncertain": true`.
- **Atomic Representation**: Each individual hyperparameter must be its own object with a single value, even if they are grouped in the source text.
- **DataProcessingStep**: Novel data processing steps that are part of the contribution.
- **TrainingRun**: Details of the training process.
- **EvaluationRun**: Details of the evaluation process.
- **PredictionSet**: If prediction outputs are a core contribution.

### EXCLUDE:
- **Baselines & Prior Work**: Methods, models, or datasets used only for comparison, unless they are directly modified or integrated as a novel part of the contribution.
- **SOTA Tables**: Do not extract results for models the authors did not propose.
- **Ablations**: Exclude variants unless an ablation reveals a specific sub-method that is a primary contribution.

## 2. Evidence & Character Offsets
Every extracted entity MUST include character offsets and context, calculated using `scripts/calculate_offsets.py`:
- **start_char_doc**: 0-indexed character offset of the entity name/mention.
- **end_char_doc**: 0-indexed character offset.
- **wasDerivedFrom**: "paper".
- **context**: { "prefix": "up to 5 words", "suffix": "up to 5 words" }

## 3. Formatting & Data Integrity
- **Strict JSON-LD @graph**: Output must be a single JSON object with `@context` and `@graph`.
- **Schema Adherence**: Strictly follow the entity, attribute, and relation definitions from the provided Mermaid class diagram.
- **Forced Inclusion**: If a mandatory entity (e.g., `MLS_Implementation`, `Environment`) is not explicitly detailed, create the entity with a unique `@id` and set its specific fields to `null`.
- **Verbatim Naming**: Use the paper's exact wording for names/titles.
- **No Hallucinations**: Use `null` for missing fields; do not invent data.
- **Relations**: Ensure all relations specified in the Mermaid class diagram are correctly represented using `@id` references.
