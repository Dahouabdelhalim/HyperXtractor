# Entity Extraction Policy

This document defines rules and policies for extracting entities from ML/AI software repositories.

## General Principles

### Completeness
Extract all identifiable entities even if some attributes are missing. Use `null` for unavailable fields rather than omitting entities.

### Precision
Prefer precise code references (file paths, line numbers) over vague descriptions. Every entity should be traceable to its source.

### Consistency
Apply the same extraction rules across all repositories. Entity IDs should follow consistent naming patterns.

### Offset Calculation
For entities mentioned in any repository file (README, documentation, source code, config files), calculate character offsets (`start_char_doc`, `end_char_doc`) within that specific file and extract surrounding context (`prefix`, `suffix`). The `path` attribute stores the relative file path. Entities not found in any file should have default offset values (0, 0), empty context, and empty path.

## Entity Extraction Rules

### SoftwareRepository

**Required Attributes:**
- `@id`: Format as `repo_{owner}_{name}` (sanitized)
- `name`: Repository name from URL
- `url`: Full GitHub URL
- `programmingLanguage`: Detected from GitHub API or file extensions

**Optional Attributes:**
- `owner`: GitHub username or organization
- `platform`: Always "GitHub" for this skill
- `dateModified`: Last commit date if available
- `documentationUrl`: Link to docs/ or wiki if exists

**Offset Attributes:**
- `start_char_doc`: Character offset within the file (0 if not found)
- `end_char_doc`: Character offset within the file (0 if not found)
- `context.prefix`: Up to 5 words before mention (empty if not found)
- `context.suffix`: Up to 5 words after mention (empty if not found)
- `path`: Relative file path where entity was found (empty if not found)

**Relations:**
- `contains`: Link to MLS_Implementation entity
- `supports`: Link to Environment entity

**Example:**
```json
{
  "@id": "repo_yousef_younes_radar",
  "@type": "SoftwareRepository",
  "name": "RADAr",
  "url": "https://github.com/yousef-younes/RADAr",
  "owner": "yousef-younes",
  "platform": "GitHub",
  "programmingLanguage": "Python",
  "contains": [{"@id": "impl_radar"}],
  "supports": [{"@id": "env_radar"}],
  "start_char_doc": 245,
  "end_char_doc": 250,
  "context": {
    "prefix": "implementation of the",
    "suffix": "model for hierarchical text"
  },
  "path": "README.md",
  "wasDerivedFrom": "code"
}
```

### MLS_Implementation

**Required Attributes:**
- `@id`: Format as `impl_{repo_name}`
- `identifier`: Descriptive name
- `codeRepository`: Same as SoftwareRepository URL
- `framework`: Detected framework (PyTorch, TensorFlow, JAX, etc.)

**Optional Attributes:**
- `entryPoint`: Main script (main.py, train.py, etc.)
- `commitHash`: Latest commit hash
- `branch`: Default branch name
- `executionCommand`: Command to run (from README)
- `entryPointCommand`: Full command with arguments

**Relations:**
- `runsIn`: Link to Environment entity
- `requires`: Link to Dependency entities

**Detection Logic:**
1. Search for entry point files (main.py, train.py, run.py)
2. Detect framework from imports in entry point
3. Extract execution command from README or comments
4. Get commit hash from GitHub API

**Example:**
```json
{
  "@id": "impl_radar",
  "@type": "MLS_Implementation",
  "identifier": "RADAr Implementation",
  "codeRepository": "https://github.com/yousef-younes/RADAr",
  "framework": "PyTorch",
  "entryPoint": "main.py",
  "commitHash": "5cb2b78",
  "executionCommand": "python main.py --config nyt_config.yaml",
  "runsIn": {"@id": "env_radar"},
  "requires": [{"@id": "dep_torch"}, {"@id": "dep_transformers"}]
}
```

### Environment

**Required Attributes:**
- `@id`: Format as `env_{repo_name}`
- `name`: Descriptive environment name
- `framework`: Primary framework with version

**Optional Attributes:**
- `pythonVersion`: From runtime.txt, .python-version, or setup.py
- `os`: From Dockerfile or README
- `hardwareSpecs`: GPU requirements from README
- `requirementsFile`: Path to requirements file
- `isDockerized`: Boolean, true if Dockerfile exists

**Detection Logic:**
1. Check for Dockerfile → extract OS and dependencies
2. Check for environment.yml → extract conda environment
3. Check for requirements.txt → extract pip dependencies
4. Check for .python-version or runtime.txt → extract Python version
5. Search README for hardware requirements

**Example:**
```json
{
  "@id": "env_radar",
  "@type": "Environment",
  "name": "RADAr Training Environment",
  "framework": "PyTorch 2.2.2",
  "pythonVersion": "3.11",
  "requirementsFile": "requirements.txt",
  "isDockerized": false,
  "hardwareSpecs": "CUDA-capable GPU recommended"
}
```

### Dependency

**Required Attributes:**
- `@id`: Format as `dep_{package_name}` (sanitized)
- `packageName`: Package name (e.g., "torch", "transformers")

**Optional Attributes:**
- `version`: Version string (e.g., "2.2.2")
- `dependencyType`: "runtime" or "development"
- `isOptional`: Boolean, true if optional dependency

**Extraction Sources:**
1. **requirements.txt:** Parse line by line
   - Format: `package==version` or `package>=version`
   - Handle comments and extras: `package[extra]==version`
2. **setup.py:** Extract from `install_requires` and `extras_require`
3. **pyproject.toml:** Parse `[project.dependencies]` section
4. **environment.yml:** Extract from `dependencies` section

**Version Handling:**
- Exact version: `torch==2.2.2` → version: "2.2.2"
- Minimum version: `torch>=2.0.0` → version: ">=2.0.0"
- No version: `torch` → version: null

**Example:**
```json
{
  "@id": "dep_torch",
  "@type": "Dependency",
  "packageName": "torch",
  "version": "2.2.2",
  "dependencyType": "runtime",
  "isOptional": false,
  "codeReference": "requirements.txt:176",
  "wasDerivedFrom": "code"
}
```

### MLS_HyperParameter

**Required Attributes:**
- `@id`: Format as `hp_{param_name}` (sanitized)
- `name`: Parameter name (e.g., "learning_rate", "batch_size")
- `hasValue`: Parameter value as string

**Optional Attributes:**
- `codeReference`: File path and line number or key path
- `sourceFile`: Config file name
- `sourceLine`: Line number in file

**Extraction Sources:**
1. **YAML/JSON files:** Parse nested structures, flatten keys with dots
   - `model.hidden_size: 768` → name: "model.hidden_size", value: "768"
2. **Python config files:** Extract from class attributes or dicts
3. **argparse definitions:** Extract from `add_argument()` calls
4. **Dataclasses:** Extract from class attribute annotations

**Value Handling:**
- Numbers: Convert to string representation
- Booleans: "true" or "false"
- Strings: Keep as-is
- Lists: JSON string representation
- Nested dicts: Flatten or JSON string

**Naming Convention:**
- Use original parameter names from code
- For dataset-specific configs, append dataset name: "learning_rate (NYT)"
- For nested parameters, use dot notation: "model.num_layers"

**Example:**
```json
{
  "@id": "hp_learning_rate",
  "@type": "MLS_HyperParameter",
  "name": "enc_lr",
  "hasValue": "5e-5",
  "codeReference": "nyt_config.yaml:144",
  "sourceFile": "nyt_config.yaml",
  "sourceLine": 144,
  "wasDerivedFrom": "code"
}
```

### DataProcessingStep

**Required Attributes:**
- `@id`: Format as `preprocess_{script_name}`
- `identifier`: Descriptive name
- `transformationType`: Type of transformation (tokenization, normalization, etc.)

**Optional Attributes:**
- `description`: What the preprocessing does
- `codeReference`: File path to preprocessing script
- `startedAtTime`: Timestamp if available from logs
- `endedAtTime`: Timestamp if available from logs

**Detection Logic:**
1. Find files matching preprocessing patterns (see file_patterns.md)
2. Analyze imports and function names to determine transformation type
3. Extract description from docstrings or comments

**Transformation Types:**
- "tokenization" - Text tokenization
- "normalization" - Data normalization/standardization
- "augmentation" - Data augmentation
- "cleaning" - Data cleaning/filtering
- "splitting" - Train/val/test splitting
- "feature_extraction" - Feature engineering

**Relations:**
- `inputDataset`: Link to source dataset (if mentioned)
- `outputDataset`: Link to processed dataset (if mentioned)
- `prov-executedBy`: Link to Implementation

**Example:**
```json
{
  "@id": "preprocess_data_preparation",
  "@type": "DataProcessingStep",
  "identifier": "Data Preparation Pipeline",
  "transformationType": "tokenization",
  "description": "Tokenizes text and organizes labels hierarchically",
  "codeReference": "data_preparation/",
  "wasDerivedFrom": "code"
}
```

### TrainingRun

**Required Attributes:**
- `@id`: Format as `training_{repo_name}`
- `runId`: Identifier for the training run
- `description`: What is being trained

**Optional Attributes:**
- `codeReference`: Training script path
- `logFile`: Path to training logs
- `startedAtTime`: Training start time (from logs)
- `endedAtTime`: Training end time (from logs)

**Detection Logic:**
1. Find training files (see file_patterns.md)
2. Extract training configuration from script or config files
3. Look for log files in logs/ directory

**Relations:**
- `prov-executedBy`: Link to Implementation
- `used`: Link to datasets used for training
- `trains`: Link to model being trained

**Example:**
```json
{
  "@id": "training_radar",
  "@type": "TrainingRun",
  "runId": "radar_training",
  "description": "Training RADAr model on HTC datasets",
  "codeReference": "main.py",
  "logFile": "logs/nyt/LOG_FILE.txt",
  "wasDerivedFrom": "code"
}
```

### EvaluationRun

**Required Attributes:**
- `@id`: Format as `evaluation_{repo_name}`
- `runId`: Identifier for the evaluation run
- `description`: What is being evaluated

**Optional Attributes:**
- `split`: Dataset split (train/val/test)
- `codeReference`: Evaluation script path
- `evaluationScript`: Script file name
- `evaluationSplit`: Which split is evaluated
- `metricsFile`: Path to metrics output file

**Detection Logic:**
1. Find evaluation files (see file_patterns.md)
2. Extract evaluation configuration
3. Look for metrics files or result files

**Relations:**
- `prov-executedBy`: Link to Implementation
- `evaluates`: Link to model being evaluated
- `prov-generated`: Link to MLS_Eval entities (metrics)

**Example:**
```json
{
  "@id": "evaluation_radar",
  "@type": "EvaluationRun",
  "runId": "radar_evaluation",
  "description": "Evaluation of RADAr on test sets",
  "split": "test",
  "codeReference": "main.py",
  "evaluationScript": "main.py",
  "metricsFile": "results/nyt/RESULT_FILE.txt",
  "wasDerivedFrom": "code"
}
```

### PredictionSet

**Required Attributes:**
- `@id`: Format as `prediction_{script_name}`
- `identifier`: Descriptive name
- `description`: What predictions are generated

**Optional Attributes:**
- `codeReference`: Prediction script path
- `format`: Output format (JSON, CSV, etc.)
- `predictionFormat`: Specific format details
- `storageLocation`: Where predictions are saved
- `numInstances`: Number of predictions

**Detection Logic:**
1. Find prediction/inference files (see file_patterns.md)
2. Analyze output format from code
3. Determine storage location from script

**Relations:**
- `appliedTo`: Link to dataset being predicted on
- `wasGeneratedBy`: Link to model used for prediction
- `producedBy`: Link to Implementation

**Example:**
```json
{
  "@id": "prediction_inference",
  "@type": "PredictionSet",
  "identifier": "Model Predictions",
  "description": "Predictions generated by trained model",
  "codeReference": "predict.py",
  "predictionFormat": "JSON",
  "storageLocation": "predictions/",
  "wasDerivedFrom": "code"
}
```

## Code Reference Format

All code references should follow this format:

**File only:** `"path/to/file.py"`

**File with line:** `"path/to/file.py:123"`

**File with line range:** `"path/to/file.py:123-145"`

**Config key path:** `"config.yaml:model.hidden_size"`

## Provenance Tracking

All repository-extracted entities must include:

**For entities not found in any file:**
```json
{
  "wasDerivedFrom": "code",
  "codeReference": "path/to/source",
  "start_char_doc": 0,
  "end_char_doc": 0,
  "context": {
    "prefix": "",
    "suffix": ""
  },
  "path": ""
}
```

**For entities found in repository files:**
```json
{
  "wasDerivedFrom": "code",
  "codeReference": "nyt_config.yaml",
  "start_char_doc": 245,
  "end_char_doc": 250,
  "context": {
    "prefix": "implementation of the",
    "suffix": "model for hierarchical text"
  },
  "path": "README.md"
}
```

**Rules:**
- Always use `wasDerivedFrom: "code"` for repository entities
- `path` attribute stores the relative file path where entity was found
- `codeReference` stores the original extraction source (config file, requirements, etc.)
- Calculate offsets using `calculate_offsets.py` script after initial extraction
- Script searches across all repository files (README, docs, source, configs)
- Offsets are relative to the specific file, not the entire repository
- Context should include up to 5 words before and after the mention
- Entities not found in any file use default values (0, 0, empty context, empty path)

## Edge Case Handling

### Missing Entry Points
If no clear entry point is found:
1. Check README for execution instructions
2. Look for `if __name__ == "__main__":` blocks
3. Check setup.py for console_scripts
4. Default to most recently modified .py file in root

### Multiple Config Files
When multiple config files exist (e.g., per dataset):
- Extract hyperparameters from all configs
- Append dataset name to parameter IDs
- Link each config to its specific experiment/run

### Ambiguous File Purposes
When a file could serve multiple purposes (e.g., main.py with train/eval):
- Create multiple provenance entities
- Link them to the same codeReference
- Differentiate by description and relations

### Missing Dependencies
If requirements.txt is missing:
1. Extract imports from Python files
2. Mark as inferred dependencies
3. Version will be null

### Incomplete Metadata
If repository metadata is incomplete:
- Extract what's available
- Set missing fields to null
- Don't skip entity creation
