# Common File Patterns in ML/AI Repositories

This reference documents common file naming and structural patterns found in ML/AI repositories to aid in provenance file detection.

## Training Files

### File Name Patterns
- `train.py`, `trainer.py`, `training.py`
- `main.py` (when contains training loop)
- `run_training.py`, `run_experiment.py`
- `finetune.py`, `pretrain.py`

### Class/Function Indicators
- Classes: `Trainer`, `TrainingPipeline`, `ModelTrainer`
- Functions: `train()`, `train_model()`, `run_training()`, `fit()`

### Import Patterns
- `torch.optim` (PyTorch optimizers)
- `torch.nn.Module` (model definition)
- `tensorflow.keras.optimizers`
- `transformers.Trainer`
- `pytorch_lightning.Trainer`

### Code Patterns
- Training loops: `for epoch in range(num_epochs):`
- Optimizer steps: `optimizer.step()`, `optimizer.zero_grad()`
- Loss computation: `loss.backward()`, `loss.item()`
- Model saving: `torch.save()`, `model.save()`

## Evaluation Files

### File Name Patterns
- `eval.py`, `evaluate.py`, `evaluation.py`
- `test.py`, `testing.py`
- `validate.py`, `validation.py`
- `benchmark.py`, `metrics.py`

### Class/Function Indicators
- Classes: `Evaluator`, `Tester`, `Validator`
- Functions: `evaluate()`, `test()`, `compute_metrics()`, `validate()`

### Import Patterns
- `sklearn.metrics` (evaluation metrics)
- `torch.no_grad()` (inference mode)
- `transformers.EvalPrediction`
- Metric libraries: `torchmetrics`, `evaluate`

### Code Patterns
- Evaluation loops: `with torch.no_grad():`
- Metric computation: `accuracy_score()`, `f1_score()`, `precision_recall_fscore_support()`
- Result logging: `print(f"Accuracy: {acc}")`, `wandb.log()`

## Preprocessing Files

### File Name Patterns
- `preprocess.py`, `preprocessing.py`
- `data_preparation.py`, `prepare_data.py`
- `dataset.py`, `dataloader.py`
- `clean_data.py`, `transform.py`

### Directory Patterns
- `data_preparation/`
- `preprocessing/`
- `data/` (with processing scripts)

### Class/Function Indicators
- Classes: `Preprocessor`, `DataProcessor`, `DataCleaner`, `Dataset`
- Functions: `preprocess()`, `clean_data()`, `transform()`, `load_data()`

### Import Patterns
- `pandas` (data manipulation)
- `torch.utils.data.Dataset`
- `transformers.AutoTokenizer`
- `sklearn.preprocessing`

### Code Patterns
- Data loading: `pd.read_csv()`, `json.load()`
- Tokenization: `tokenizer.encode()`, `tokenizer()`
- Data splitting: `train_test_split()`
- Feature engineering: `StandardScaler()`, `normalize()`

## Prediction/Inference Files

### File Name Patterns
- `predict.py`, `prediction.py`
- `inference.py`, `infer.py`
- `generate.py`, `generation.py`
- `demo.py`, `app.py` (for inference demos)

### Class/Function Indicators
- Classes: `Predictor`, `InferenceEngine`, `Generator`
- Functions: `predict()`, `infer()`, `generate()`, `forward()`

### Import Patterns
- `torch.no_grad()` (inference mode)
- `transformers.pipeline`
- Model loading: `torch.load()`, `model.load_state_dict()`

### Code Patterns
- Model loading: `model = torch.load()`, `model.eval()`
- Batch prediction: `predictions = model(inputs)`
- Output generation: `model.generate()`, `model.predict()`

## Configuration Files

### YAML/JSON Config Files
- `config.yaml`, `config.yml`, `*.yaml`, `*.yml`
- `config.json`, `settings.json`
- `hparams.yaml`, `hyperparameters.yaml`
- Dataset-specific: `nyt_config.yaml`, `wos_config.yaml`

### Python Config Files
- `config.py`, `configuration.py`
- `args.py`, `arguments.py`
- `settings.py`, `options.py`

### Framework-Specific
- Hugging Face: `config.json`, `training_args.json`
- Hydra: `config/` directory with YAML files
- Sacred: `config.py` with `@ex.config`

## Dependency Files

### Python Dependencies
- `requirements.txt` (pip)
- `setup.py`, `setup.cfg` (setuptools)
- `pyproject.toml` (Poetry, PDM, Hatch)
- `Pipfile`, `Pipfile.lock` (Pipenv)
- `environment.yml`, `conda.yml` (Conda)

### Docker/Container
- `Dockerfile`
- `docker-compose.yml`
- `.dockerignore`

### Environment Specifications
- `.python-version` (pyenv)
- `runtime.txt` (Heroku, cloud platforms)

## Entry Point Detection

### Main Entry Points
1. `main.py` (most common)
2. `run.py`, `run_experiment.py`
3. `train.py` (if training is primary function)
4. `__main__.py` (package entry point)
5. `app.py` (for web applications)

### Entry Point Indicators
- `if __name__ == "__main__":`
- `argparse.ArgumentParser()` (CLI arguments)
- `fire.Fire()` (Google Fire CLI)
- `click.command()` (Click CLI)

### setup.py Entry Points
```python
entry_points={
    'console_scripts': [
        'command=package.module:function',
    ],
}
```

## Framework Detection

### PyTorch
- Imports: `import torch`, `import torch.nn`
- Config files: Often YAML-based
- Model files: `*.pt`, `*.pth`, `*.ckpt`

### TensorFlow/Keras
- Imports: `import tensorflow`, `from tensorflow import keras`
- Config files: Often JSON-based
- Model files: `*.h5`, `saved_model/`

### Hugging Face Transformers
- Imports: `from transformers import`
- Config files: `config.json`, `training_args.json`
- Model files: `pytorch_model.bin`, `model.safetensors`

### JAX/Flax
- Imports: `import jax`, `import flax`
- Config files: Often Python dicts or gin-config
- Model files: `*.msgpack`, `*.pkl`

### PyTorch Lightning
- Imports: `import pytorch_lightning`
- Class inheritance: `pl.LightningModule`
- Trainer: `pl.Trainer()`

## Repository Structure Patterns

### Standard ML Project Structure
```
repo/
├── data/              # Data files or data loading scripts
├── models/            # Model definitions
├── configs/           # Configuration files
├── scripts/           # Utility scripts
├── train.py           # Training script
├── eval.py            # Evaluation script
├── requirements.txt   # Dependencies
└── README.md
```

### Research Paper Implementation
```
repo/
├── data_preparation/  # Preprocessing scripts
├── experiments/       # Experiment configurations
├── models/            # Model architectures
├── utils/             # Utility functions
├── main.py            # Main entry point
├── *_config.yaml      # Dataset-specific configs
└── requirements.txt
```

### Hugging Face Style
```
repo/
├── src/               # Source code
│   ├── data/          # Data processing
│   ├── models/        # Model definitions
│   └── training/      # Training logic
├── configs/           # Configuration files
├── run_training.py    # Training script
├── run_evaluation.py  # Evaluation script
└── requirements.txt
```

## Heuristic Priority

When multiple patterns match, prioritize in this order:

1. **Explicit naming:** Files with clear names (train.py > main.py)
2. **Function/class names:** Specific classes like `Trainer` over generic `main()`
3. **Import patterns:** Framework-specific imports indicate purpose
4. **Code patterns:** Actual training/evaluation logic in code
5. **Comments/docstrings:** Explicit descriptions in documentation

## Edge Cases

### Multi-Purpose Files
- `main.py` may contain training, evaluation, and prediction
- Solution: Analyze functions/classes to extract multiple provenance entities

### Notebooks
- `*.ipynb` files may contain entire pipelines
- Solution: Extract cell-level information if possible

### Distributed Code
- Training logic split across multiple files
- Solution: Link related files via imports and create composite entities

### Generated Code
- Auto-generated config files (e.g., from Hydra)
- Solution: Focus on source templates, not generated outputs
