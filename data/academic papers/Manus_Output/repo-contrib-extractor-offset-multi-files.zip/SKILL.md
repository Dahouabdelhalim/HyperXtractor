---
name: repo-contrib-extractor
description: Extract contribution-related entities from ML/AI software repositories in JSON-LD format. Extracts hyperparameters, dependencies, provenance files (training, preprocessing, evaluation, prediction), implementation details, and environment specifications. Use when given a GitHub repository URL to analyze ML/AI code contributions.
---

# Repository Contribution Extractor

Extract comprehensive contribution-related entities from ML/AI software repositories following the MLS ontology schema.

## Usage

Invoke this skill when the user provides a GitHub repository URL for analysis:

```
/repo-contrib-extractor <repository-url>
```

**Example:**
```
/repo-contrib-extractor https://github.com/yousef-younes/RADAr
```

## Extraction Process

Follow these steps in order:

### 1. Access Repository

Navigate to the repository URL using browser tools to:
- Verify repository exists and is accessible
- Identify primary programming language
- Locate key files (README, requirements, config files)
- Note repository metadata (owner, stars, last commit)

### 2. Identify Repository Structure

Examine the repository to find:
- **Entry points:** main.py, train.py, run.py, __main__.py
- **Config files:** *.yaml, *.yml, *.json, config.py, args.py
- **Dependency files:** requirements.txt, setup.py, pyproject.toml, environment.yml
- **Provenance files:** Files matching patterns in `references/file_patterns.md`

When repository structure is unclear, read `references/file_patterns.md` for common patterns.

### 3. Clone Repository

Clone the repository locally to enable multi-file search:

```bash
git clone <repository-url> /path/to/local-repo
```

This allows the offset calculation script to search across all repository files.

### 4. Extract Entities

Run the main extraction script:

```bash
python3 /home/ubuntu/skills/repo-contrib-extractor/scripts/extract_repo_entities.py \
  --repo-url <repository-url> \
  --repo-path <local-repo-path> \
  --readme-path <readme-file-path> \
  --output <output-path>
```

The script automatically:
- Parses config files for hyperparameters
- Extracts dependencies with versions
- Detects provenance files (training, evaluation, preprocessing, prediction)
- Builds JSON-LD entities following the schema
- Links entities with proper relations

### 5. Calculate Offsets

Search for entity mentions across all repository files and calculate offsets:

```bash
python3 /home/ubuntu/skills/repo-contrib-extractor/scripts/calculate_offsets.py \
  --repo-path <local-repo-path> \
  --entities-file <output-path> \
  --output <output-path>
```

This script:
- Searches across all repository files (README, docs, source code, config files)
- Calculates file-specific character offsets for each mention
- Extracts surrounding context (up to 5 words before and after)
- Adds a `path` attribute with the relative file path
- Keeps `wasDerivedFrom` as "code" to reflect the source type

Added attributes:
- **start_char_doc:** Character offset within the file where mention starts
- **end_char_doc:** Character offset within the file where mention ends
- **context.prefix:** Up to 5 words before the mention
- **context.suffix:** Up to 5 words after the mention
- **path:** Relative file path where the entity was found

### 6. Validate and Deliver

Validate the output and deliver to user:

```bash
python3 -c "import json; json.load(open('<output-path>'))"
```

Send the JSON-LD file to the user via message tool.

## Entity Types Extracted

The skill extracts these entity types:

| Entity Type | Description | Source |
|------------|-------------|---------|
| SoftwareRepository | Repository metadata | GitHub API / README |
| MLS_Implementation | Implementation details | Entry points, framework detection |
| Environment | Execution environment | Dockerfile, conda.yml, Python version |
| Dependency | Package dependencies | requirements.txt, setup.py, pyproject.toml |
| MLS_HyperParameter | Training/model hyperparameters | Config files (YAML/JSON/Python) |
| DataProcessingStep | Preprocessing scripts | Files matching preprocessing patterns |
| TrainingRun | Training execution | Files matching training patterns |
| EvaluationRun | Evaluation execution | Files matching evaluation patterns |
| PredictionSet | Prediction/inference | Files matching prediction patterns |

## Configuration File Formats

The skill supports multiple config formats:

**YAML/JSON:** Direct parsing of nested structures
```yaml
learning_rate: 0.001
batch_size: 32
model:
  hidden_size: 768
  num_layers: 12
```

**Python argparse:** Extract from ArgumentParser definitions
```python
parser.add_argument('--learning-rate', type=float, default=0.001)
```

**Python dataclasses/config classes:** Extract from class attributes
```python
@dataclass
class Config:
    learning_rate: float = 0.001
    batch_size: int = 32
```

**Hugging Face TrainingArguments:** Extract from transformers library usage

## Provenance File Detection

Files are classified by analyzing:
1. **File names:** train.py, eval.py, preprocess.py, predict.py
2. **Function/class names:** Trainer, Evaluator, Preprocessor, DataLoader
3. **Import patterns:** torch.optim (training), sklearn.metrics (evaluation)
4. **Comments/docstrings:** "training script", "evaluation pipeline"

For detailed patterns, read `references/file_patterns.md`.

## Output Format

The output is a JSON-LD file with structure:

```json
{
  "@context": { ... },
  "@graph": [
    {
      "@id": "repo_id",
      "@type": "SoftwareRepository",
      "name": "Repository Name",
      "url": "https://github.com/...",
      "programmingLanguage": "Python",
      "contains": [{"@id": "impl_id"}],
      "supports": [{"@id": "env_id"}]
    },
    {
      "@id": "impl_id",
      "@type": "MLS_Implementation",
      "codeRepository": "https://github.com/...",
      "framework": "PyTorch",
      "entryPoint": "main.py",
      "runsIn": {"@id": "env_id"},
      "requires": [{"@id": "dep_1"}, {"@id": "dep_2"}]
    },
    ...
  ]
}
```

All entities include:
- **codeReference:** File path or URL where entity was originally extracted
- **wasDerivedFrom:** Always "code" for repository entities
- **path:** Relative file path where entity mention was found (if found)
- **start_char_doc:** Character offset within the file (0 if not found)
- **end_char_doc:** Character offset within the file (0 if not found)
- **context:** Prefix and suffix words surrounding the mention
- **Relations:** Proper links to related entities

## Schema Reference

For complete entity schemas and attribute definitions, read:
```
/home/ubuntu/skills/repo-contrib-extractor/references/output_schema.md
```

## Extraction Policy

For detailed rules on entity extraction and edge cases, read:
```
/home/ubuntu/skills/repo-contrib-extractor/references/extraction_policy.md
```

## Limitations

- Requires public GitHub repositories or authenticated access
- Best results with well-structured ML/AI projects
- Config parsing may miss dynamically generated parameters
- Provenance file detection uses heuristics (may have false positives/negatives)
