# Entity Extraction Policy (Repository Entities)

This document defines rules and policies for extracting the nine in-scope entities from ML/AI software repositories and formatting them as JSON-LD.

---

## General Principles

### Completeness
Extract all identifiable entities even if some attributes are missing. Use `null` for unavailable fields rather than omitting entities entirely.

### Precision
Prefer precise code references (file paths, line numbers) over vague descriptions. Every entity must be traceable to its source file.

### Consistency
Apply the same extraction rules across all repositories. Entity IDs must follow the naming patterns defined below.

### Provenance
All repository-extracted entities use `"wasDerivedFrom": "code"`. Never use `"paper"`. The `path` attribute stores the relative file path where the entity was found; `codeReference` stores the original extraction source with optional line annotation.

### Offset Calculation
For every entity found in a repository file, calculate `start_char_doc` and `end_char_doc` character offsets within that specific file and extract `prefix` / `suffix` context (up to 5 words each). Entities not found in any file use default values (`0`, `0`, empty context, empty `path`).

---

## Entity Extraction Rules

### SoftwareRepository

**ID format:** `repo_{owner}_{name}` (lowercase, underscores replacing hyphens and spaces)

**Required attributes:**
- `name` — repository name from the URL
- `url` — full GitHub (or equivalent) URL
- `programmingLanguage` — detected from file extensions or GitHub language stats

**Optional attributes:**
- `owner` — GitHub username or organisation
- `platform` — always `"GitHub"` for this skill
- `version` — latest release tag if present
- `license` — from LICENSE file or GitHub metadata
- `dateModified` — last commit date if available
- `documentationUrl` — link to docs/ or wiki if present

**Relations:** `contains` → MLS_Implementation; `supports` → Environment

**Example:**
```json
{
  "@id":                "repo_yousef_younes_radar",
  "@type":              "SoftwareRepository",
  "name":               "RADAr",
  "url":                "https://github.com/yousef-younes/RADAr",
  "owner":              "yousef-younes",
  "platform":           "GitHub",
  "programmingLanguage": "Python",
  "license":            null,
  "dateModified":       null,
  "documentationUrl":   null,
  "contains":           [ { "@id": "impl_radar" } ],
  "supports":           [ { "@id": "env_radar"  } ],
  "wasDerivedFrom":     "code",
  "codeReference":      "README.md",
  "path":               "README.md",
  "start_char_doc":     245,
  "end_char_doc":       250,
  "context":            { "prefix": "implementation of the", "suffix": "model for hierarchical text" }
}
```

---

### MLS_Implementation

**ID format:** `impl_{repo_name}`

**Required attributes:**
- `identifier` — descriptive name
- `codeRepository` — same URL as SoftwareRepository
- `framework` — detected from imports (PyTorch, TensorFlow, JAX, etc.)

**Optional attributes:**
- `entryPoint` — main script (main.py, train.py, etc.)
- `entryPointCommand` — full command with arguments from README
- `executionCommand` — short command if documented separately
- `commitHash` — latest commit hash
- `branch` — default branch name
- `dependenciesHash` — hash of dependency file if available

**Relations:** `runsIn` → Environment; `requires` → Dependency

**Detection logic:**
1. Search for entry point files: `main.py`, `train.py`, `run.py`, `__main__.py`
2. Detect framework from imports in the entry point file
3. Extract execution command from README or inline comments
4. Retrieve commit hash from GitHub API or `.git/` metadata

**Example:**
```json
{
  "@id":               "impl_radar",
  "@type":             "MLS_Implementation",
  "identifier":        "RADAr Implementation",
  "codeRepository":    "https://github.com/yousef-younes/RADAr",
  "framework":         "PyTorch",
  "entryPoint":        "main.py",
  "entryPointCommand": "python main.py --config nyt_config.yaml",
  "commitHash":        "5cb2b78",
  "branch":            null,
  "dependenciesHash":  null,
  "runsIn":            { "@id": "env_radar" },
  "requires":          [ { "@id": "dep_torch" }, { "@id": "dep_transformers" } ],
  "wasDerivedFrom":    "code",
  "codeReference":     "main.py",
  "path":              "main.py",
  "start_char_doc":    0,
  "end_char_doc":      0,
  "context":           { "prefix": "", "suffix": "" }
}
```

---

### Environment

**ID format:** `env_{repo_name}`

**Required attributes:**
- `name` — descriptive environment name
- `framework` — primary framework with version (e.g. `"PyTorch 2.2.2"`)

**Optional attributes:**
- `pythonVersion` — from `runtime.txt`, `.python-version`, or `setup.py`
- `os` — from Dockerfile or README
- `hardwareSpecs` — GPU requirements from README
- `requirementsFile` — relative path to requirements file
- `isDockerized` — `true` if a Dockerfile exists

**Detection logic:**
1. Dockerfile → extract base image (OS) and pinned dependency versions
2. `environment.yml` → extract conda environment name and packages
3. `requirements.txt` → confirm pip dependencies
4. `.python-version` / `runtime.txt` → extract Python version
5. README → scan for hardware requirements (GPU, CUDA version)

**Example:**
```json
{
  "@id":              "env_radar",
  "@type":            "Environment",
  "name":             "RADAr Training Environment",
  "framework":        "PyTorch 2.2.2",
  "pythonVersion":    "3.11",
  "os":               null,
  "hardwareSpecs":    "CUDA-capable GPU recommended",
  "requirementsFile": "requirements.txt",
  "isDockerized":     false,
  "wasDerivedFrom":   "code",
  "codeReference":    "requirements.txt",
  "path":             "requirements.txt",
  "start_char_doc":   0,
  "end_char_doc":     0,
  "context":          { "prefix": "", "suffix": "" }
}
```

---

### Dependency

**ID format:** `dep_{package_name}` (lowercase, sanitised)

**Required attributes:**
- `packageName` — package name (e.g. `"torch"`, `"transformers"`)

**Optional attributes:**
- `version` — version string (see version handling below)
- `dependencyType` — `"runtime"` or `"development"`
- `isOptional` — `true` if optional

**Extraction sources:**
1. `requirements.txt` — parse line by line; handle `package==version`, `package>=version`, `package[extra]==version`
2. `setup.py` — `install_requires` and `extras_require`
3. `pyproject.toml` — `[project.dependencies]`
4. `environment.yml` — `dependencies` section

**Version handling:**
- Exact: `torch==2.2.2` → `"version": "2.2.2"`
- Minimum: `torch>=2.0.0` → `"version": ">=2.0.0"`
- Absent: `torch` → `"version": null`

**Example:**
```json
{
  "@id":            "dep_torch",
  "@type":          "Dependency",
  "packageName":    "torch",
  "version":        "2.2.2",
  "dependencyType": "runtime",
  "isOptional":     false,
  "wasDerivedFrom": "code",
  "codeReference":  "requirements.txt:176",
  "path":           "requirements.txt",
  "start_char_doc": 0,
  "end_char_doc":   0,
  "context":        { "prefix": "", "suffix": "" }
}
```

---

### MLS_HyperParameter

**ID format:** `hp_{param_name}` — append dataset/run context for multi-value parameters (e.g. `hp_learning_rate_nyt`)

**Required attributes:**
- `name` — parameter name as it appears in code; use dot notation for nested keys (e.g. `"model.num_layers"`) and append dataset label for multi-value (e.g. `"learning_rate (NYT)"`)
- `hasValue` — parameter value as a string
- `hpCategory` — one of `HP_Optimization`, `HP_Training`, `HP_Architecture`, `HP_Data`
- `hpType` — exact leaf class name from the taxonomy (e.g. `LearningRate`, `BatchSize`, `NumLayers`); set to the best-fit category string if no leaf matches and add `"uncertain": true`

**Optional attributes:**
- `sourceFile` — config file name
- `sourceLine` — line number within the file
- `uncertain` — `true` when leaf classification is ambiguous

**Extraction sources:**
1. YAML/JSON config files — flatten nested keys with dot notation
2. Python argparse — `add_argument()` default values
3. Dataclasses / config classes — class attribute annotations and defaults
4. Hugging Face `TrainingArguments` — field values
5. README / inline comments — explicit numeric assignments

**Multi-value rule:** When the same parameter name has different values per dataset or experiment, create one entity per value. Append the context to the `@id` and `name` (e.g. `hp_lr_nyt`, `hp_lr_wos`).

**Example:**
```json
{
  "@id":            "hp_learning_rate",
  "@type":          "MLS_HyperParameter",
  "name":           "enc_lr",
  "hasValue":       "5e-5",
  "hpCategory":     "HP_Optimization",
  "hpType":         "LearningRate",
  "uncertain":      false,
  "sourceFile":     "nyt_config.yaml",
  "sourceLine":     144,
  "wasDerivedFrom": "code",
  "codeReference":  "nyt_config.yaml:144",
  "path":           "nyt_config.yaml",
  "start_char_doc": 0,
  "end_char_doc":   0,
  "context":        { "prefix": "", "suffix": "" }
}
```

---

### DataProcessingStep

**ID format:** `preprocess_{script_name}`

**Required attributes:**
- `identifier` — descriptive name
- `transformationType` — one of: `tokenization`, `normalization`, `augmentation`, `cleaning`, `splitting`, `feature_extraction`

**Optional attributes:**
- `description` — what the preprocessing does
- `startedAtTime` / `endedAtTime` — ISO 8601 timestamps if available from logs
- `inputDataset` / `outputDataset` — links to source/processed dataset entities if mentioned

**Relations:** `prov-executedBy` → MLS_Implementation

**Detection logic:**
1. Match file names against preprocessing patterns (see `file_patterns.md`)
2. Analyse imports (`pandas`, `AutoTokenizer`, `sklearn.preprocessing`) and function names (`preprocess()`, `clean_data()`, `transform()`)
3. Extract description from docstrings or inline comments

**Example:**
```json
{
  "@id":               "preprocess_data_preparation",
  "@type":             "DataProcessingStep",
  "identifier":        "Data Preparation Pipeline",
  "description":       "Tokenizes text and organises labels hierarchically",
  "transformationType": "tokenization",
  "startedAtTime":     null,
  "endedAtTime":       null,
  "inputDataset":      null,
  "outputDataset":     null,
  "prov-executedBy":   { "@id": "impl_radar" },
  "wasDerivedFrom":    "code",
  "codeReference":     "data_preparation/",
  "path":              "data_preparation/",
  "start_char_doc":    0,
  "end_char_doc":      0,
  "context":           { "prefix": "", "suffix": "" }
}
```

---

### TrainingRun

**ID format:** `training_{repo_name}` (append dataset label for multi-run repos, e.g. `training_radar_nyt`)

**Required attributes:**
- `runId` — identifier for the training run
- `description` — what is being trained

**Optional attributes:**
- `logFile` — relative path to training log
- `artifactsLocation` — relative path to saved model checkpoints
- `startedAtTime` / `endedAtTime` — ISO 8601 timestamps from logs

**Relations:** `prov-executedBy` → MLS_Implementation; `used` → dataset entities; `trains` → model entity if identifiable

**Detection logic:**
1. Match file names against training patterns (see `file_patterns.md`)
2. Look for training loops (`for epoch in range(...)`), optimizer steps, loss computation
3. Scan for log files in `logs/` and checkpoint directories

**Example:**
```json
{
  "@id":              "training_radar",
  "@type":            "TrainingRun",
  "runId":            "radar_training",
  "description":      "Training RADAr model on HTC datasets",
  "logFile":          "logs/nyt/LOG_FILE.txt",
  "artifactsLocation": null,
  "startedAtTime":    null,
  "endedAtTime":      null,
  "prov-executedBy":  { "@id": "impl_radar" },
  "used":             [],
  "trains":           null,
  "wasDerivedFrom":   "code",
  "codeReference":    "main.py",
  "path":             "main.py",
  "start_char_doc":   0,
  "end_char_doc":     0,
  "context":          { "prefix": "", "suffix": "" }
}
```

---

### EvaluationRun

**ID format:** `evaluation_{repo_name}` (append dataset label for multi-run repos)

**Required attributes:**
- `runId` — identifier for the evaluation run
- `description` — what is being evaluated

**Optional attributes:**
- `split` — dataset split (e.g. `"test"`, `"validation"`)
- `evaluationScript` — script file name
- `metricsFile` — relative path to metrics output
- `startedAtTime` / `endedAtTime` — ISO 8601 timestamps from logs

**Relations:** `prov-executedBy` → MLS_Implementation; `evaluates` → model/method entity; `prov-generated` → PredictionSet entities

**Detection logic:**
1. Match file names against evaluation patterns (see `file_patterns.md`)
2. Look for metric computation (`accuracy_score`, `f1_score`, `evaluate.load`) and `torch.no_grad()` blocks
3. Scan for result or metrics files in `results/` or `outputs/`

**Example:**
```json
{
  "@id":              "evaluation_radar",
  "@type":            "EvaluationRun",
  "runId":            "radar_evaluation",
  "description":      "Evaluation of RADAr on test sets",
  "split":            "test",
  "evaluationScript": "main.py",
  "metricsFile":      "results/nyt/RESULT_FILE.txt",
  "startedAtTime":    null,
  "endedAtTime":      null,
  "prov-executedBy":  { "@id": "impl_radar" },
  "evaluates":        null,
  "prov-generated":   [],
  "wasDerivedFrom":   "code",
  "codeReference":    "main.py",
  "path":             "main.py",
  "start_char_doc":   0,
  "end_char_doc":     0,
  "context":          { "prefix": "", "suffix": "" }
}
```

---

### PredictionSet

**ID format:** `prediction_{script_name}`

**Required attributes:**
- `identifier` — descriptive name
- `description` — what predictions are generated

**Optional attributes:**
- `predictionFormat` — output format (JSON, CSV, etc.)
- `storageLocation` — relative path where predictions are saved
- `numInstances` — number of predictions if stated
- `onDatasetSplit` — which split was predicted on

**Relations:** `appliedTo` → dataset entity; `wasGeneratedBy` → model entity; `producedBy` → MLS_Implementation

**Detection logic:**
1. Match file names against prediction/inference patterns (see `file_patterns.md`)
2. Look for model loading (`model.eval()`, `torch.load()`) and generation calls (`model.generate()`, `pipeline(...)`)
3. Determine storage path from `open(...)` or output-directory arguments

**Example:**
```json
{
  "@id":              "prediction_inference",
  "@type":            "PredictionSet",
  "identifier":       "Model Predictions",
  "description":      "Predictions generated by the trained RADAr model",
  "predictionFormat": "JSON",
  "storageLocation":  "predictions/",
  "numInstances":     null,
  "onDatasetSplit":   "test",
  "appliedTo":        null,
  "wasGeneratedBy":   null,
  "producedBy":       { "@id": "impl_radar" },
  "wasDerivedFrom":   "code",
  "codeReference":    "predict.py",
  "path":             "predict.py",
  "start_char_doc":   0,
  "end_char_doc":     0,
  "context":          { "prefix": "", "suffix": "" }
}
```

---

## Provenance Block Reference

### Entity found in a repository file
```json
{
  "wasDerivedFrom": "code",
  "codeReference":  "nyt_config.yaml:144",
  "path":           "nyt_config.yaml",
  "start_char_doc": 245,
  "end_char_doc":   252,
  "context":        { "prefix": "five words before mention", "suffix": "five words after mention" }
}
```

### Entity not found in any file (default)
```json
{
  "wasDerivedFrom": "code",
  "codeReference":  "",
  "path":           "",
  "start_char_doc": 0,
  "end_char_doc":   0,
  "context":        { "prefix": "", "suffix": "" }
}
```

**Rules:**
- `wasDerivedFrom` is always `"code"` — never `"paper"`.
- `path` holds the relative file path within the repository.
- `codeReference` holds the extraction source with optional line annotation (`file.py:42`).
- Offsets are relative to the individual file, not the entire repository.
- Context contains up to 5 words before and after the mention.

---

## Edge Case Handling

### Missing Entry Points
If no clear entry point is found: check README for execution instructions → look for `if __name__ == "__main__":` blocks → check `setup.py` for `console_scripts` → default to the most recently modified `.py` file in the root.

### Multiple Config Files
When multiple dataset-specific configs exist (e.g. `nyt_config.yaml`, `wos_config.yaml`): extract hyperparameters from each file, append the dataset label to entity IDs and `name` values, and link each config to its corresponding experiment run.

### Ambiguous File Purposes
When a file serves multiple purposes (e.g. `main.py` containing both training and evaluation): create one entity per role (TrainingRun, EvaluationRun), link both to the same `codeReference`, and differentiate via `description` and relations.

### Missing Dependency File
If `requirements.txt` is absent: extract imports from Python source files, mark them as inferred dependencies, and set `version` to `null`.

### Incomplete Metadata
If repository metadata is incomplete: extract all available attributes, set missing fields to `null`, and do not skip entity creation.
